from pathlib import Path
import hashlib, json, tarfile
root=Path.cwd(); run=root/'runs/pelican-coast-v2-20261014'; out=root/'docs/lean-pilot/pelican-v7-pressure-20261020/evidence'
files=[]
for file in (run/'evidence/v7-pressure').rglob('*'):
 if file.is_file() and file.suffix in {'.json','.txt','.md','.log','.png','.mjs','.py'}: files.append(file)
for file in (run/'attempts/attempt-9').rglob('*'):
 if file.is_file() and file.suffix in {'.json','.png','.mjs','.log'}: files.append(file)
for attempt, shot in ((7,'missed-merge-merging.png'),(8,'layout-320x568-merging.png')):
 folder=run/f'attempts/attempt-{attempt}/traffic-pressure-chromium'
 files.extend([folder/'report.json',folder/shot,folder/'driver-source.mjs',run/f'attempts/attempt-{attempt}/fix-evidence.json'])
files += [run/'build-receipt.json',run/'repair-state.json',run/'workspace/game/index.html']
for f in ('main.js','coast-ui.mjs','adventure.mjs','levels.mjs','safety.mjs','feel.mjs','coast.css'):
 files.append(run/'workspace/source/pelican-bike/src'/f)
files=sorted(set(files))
archive=out/'review-bundle.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for file in files: tar.add(file,arcname=str(file.relative_to(run)),recursive=False)
entries=[{'path':str(f.relative_to(run)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files]
with tarfile.open(archive) as tar:
 for entry in entries:
  assert hashlib.sha256(tar.extractfile(entry['path']).read()).hexdigest()==entry['sha256']
# Remove only copies made by this turn; authoritative run evidence is retained.
for file in list(out.glob('*.log'))+[out/'chromium-normal-input.json',out/'webkit-normal-input.json']:
 file.unlink(missing_ok=True)
for file in (out/'preserved-failures').glob('*-report.json'): file.unlink(missing_ok=True)
public=[]
for file in sorted(out.parent.rglob('*')):
 if file.is_file() and file.name!='manifest.json':
  public.append({'path':str(file.relative_to(out.parent)),'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
manifest={'schemaVersion':1,'targetGame':'鹈鹕海岸冒险 V7','workspace':str(run/'workspace'),'status':'INTERNAL_FIRST_LEVEL_EXPERIMENT','releaseApproved':False,'buildHash':json.loads((run/'build-receipt.json').read_text())['buildHash'],'archive':{'path':'evidence/review-bundle.tar.gz','sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'entries':entries},'files':public,'notes':['Videos are raw normal-input capture, not humans and have no audio track.','Archive paths are relative to the exact target run; contains prior failed attempts and current schema-bound review.','Unrelated baseline factory test failures and unrun platform/human/device checks remain release blockers.']}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'archiveFiles':len(files),'publicFiles':len(public),'archiveBytes':archive.stat().st_size,'sha256':manifest['archive']['sha256']}))
