#!/usr/bin/env python3
"""Build provenance-bound, full-frame media for the current Pelican V3 build.

This script intentionally refuses to run until the canonical build receipt and
every report for that receipt's attempt are present and agree on the exact
target, workspace, attempt, and H5 build hash. It never falls back to older runs.

Gameplay frames are decoded directly from original videos. Contact sheets and
triptych videos are derived layouts; no crop, avatar-centering, interpolation,
generated gameplay frame, or speed change is applied.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

from PIL import Image, ImageDraw, ImageFont


REPO_ROOT = Path("/Users/kker/.codex/worktrees/pelican-feel-v3/妖怪夜市")
RUN_ROOT = REPO_ROOT / "runs/pelican-coast-v2-20261014"
WORKSPACE = RUN_ROOT / "workspace"
DOCS_EVIDENCE = REPO_ROOT / "docs/lean-pilot/pelican-feel-v3-20261014/evidence-media"
TARGET_GAME = "鹈鹕海岸冒险"
FFMPEG = Path(
    "/Users/kker/.codex/pelican-v3-continuation/media-tools/"
    "imageio_ffmpeg/binaries/ffmpeg-macos-aarch64-v7.1"
)
PYTHON = Path(
    "/Users/kker/.cache/codex-runtimes/codex-primary-runtime/"
    "dependencies/python/bin/python3"
)

ENGINES = ("chromium", "webkit")
VARIANTS = ("PR10", "PR13", "V3")
FRAME_TIMES_MS = (820, 1000, 1320, 1520, 1750, 2480)
TEMPORAL_POST_TOUCH_START_MS = 100
TEMPORAL_STEP_MS = 70
TEMPORAL_COUNT = 42
MATCHED_CLIP_SECONDS = 5.0
TRIPTYCH_PRE_TOUCH_SECONDS = 0.6
TRIPTYCH_SECONDS_CAP = 3.9
TRIPTYCH_SECONDS_MIN = 3.7
MAX_FILE_BYTES = 90 * 1024 * 1024

def report_paths(attempt: int) -> dict[str, str]:
    return {
        f"{kind}:{engine}": f"attempts/attempt-{attempt}/{folder}-{engine}/report.json"
        for kind, folder in (
            ("experience", "experience"),
            ("comparison", "feel-comparison"),
            ("feel-state", "feel-state"),
            ("risk", "risk"),
            ("head", "head"),
        )
        for engine in ENGINES
    }


class MediaError(RuntimeError):
    pass


@dataclass(frozen=True)
class Report:
    key: str
    relative_path: str
    path: Path
    data: dict[str, Any]
    sha256: str


@dataclass(frozen=True)
class SourceRef:
    relative_path: str
    path: Path
    sha256: str
    size_bytes: int
    mime: str


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def repo_relative(path: Path) -> str:
    try:
        return path.resolve().relative_to(REPO_ROOT.resolve()).as_posix()
    except ValueError as exc:
        raise MediaError(f"path escapes target repository: {path}") from exc


def resolve_run_artifact_path(relative: str) -> Path:
    """Resolve report artifact refs, which are relative to RUN_ROOT.

    Some producers may already supply a repository-relative `runs/<run-id>/...`
    path. Both forms are accepted only when they resolve inside this exact run's
    `attempts/` tree; absolute paths, traversal, and other runs/games are rejected.
    """
    if not isinstance(relative, str) or not relative or "\x00" in relative:
        raise MediaError(f"invalid run artifact path: {relative!r}")
    raw = Path(relative)
    if raw.is_absolute() or ".." in raw.parts:
        raise MediaError(f"absolute or traversing artifact path is forbidden: {relative}")
    if raw.parts and raw.parts[0] == "runs":
        candidate = (REPO_ROOT / raw).resolve()
    else:
        candidate = (RUN_ROOT / raw).resolve()
    try:
        candidate.relative_to((RUN_ROOT / "attempts").resolve())
    except ValueError as exc:
        raise MediaError(f"artifact path is outside this run's attempts tree: {relative}") from exc
    return candidate


def comparison_source_hash(data: dict[str, Any], relative: str) -> str:
    """Read the source binding as named by the actual comparison report schema."""
    values = [
        (field, data.get(field))
        for field in ("sourceHash", "sourceHtmlSha256")
        if isinstance(data.get(field), str) and data.get(field)
    ]
    if not values:
        raise MediaError(f"{relative}: comparison source hash is missing")
    if len({value for _, value in values}) != 1:
        raise MediaError(f"{relative}: sourceHash and sourceHtmlSha256 disagree")
    value = values[0][1]
    if re.fullmatch(r"[0-9a-f]{64}", value) is None:
        raise MediaError(f"{relative}: comparison source hash is malformed")
    return value


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise MediaError(f"cannot read JSON {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise MediaError(f"expected JSON object: {path}")
    return value


def check_report_identity(
    report: Report, *, attempt: int, build_hash: str, nested_variant: bool = False
) -> None:
    data = report.data
    if nested_variant:
        return
    checks = {
        "targetGame": TARGET_GAME,
        "workspace": str(WORKSPACE),
        "buildHash": build_hash,
    }
    for key, expected in checks.items():
        if data.get(key) != expected:
            raise MediaError(
                f"{report.relative_path}: {key}={data.get(key)!r}, expected {expected!r}"
            )
    if data.get("attempt") not in (None, attempt):
        raise MediaError(
            f"{report.relative_path}: attempt={data.get('attempt')!r}, expected {attempt}"
        )
    if data.get("normalInputOnly") is not True:
        raise MediaError(f"{report.relative_path}: normalInputOnly must be true")
    if data.get("stateInjection") is not False:
        raise MediaError(f"{report.relative_path}: stateInjection must be false")
    if data.get("passed") is False:
        raise MediaError(f"{report.relative_path}: report has passed=false")
    if data.get("errors"):
        raise MediaError(f"{report.relative_path}: report contains errors")
    if "passed" in data and data.get("passed") is not True:
        raise MediaError(f"{report.relative_path}: report is not an explicit pass")


def preflight_reports() -> tuple[dict[str, Report], dict[str, Any], int, str]:
    receipt_path = RUN_ROOT / "build-receipt.json"
    if not receipt_path.is_file():
        raise MediaError(f"latest build receipt is missing: {receipt_path}")
    receipt = read_json(receipt_path)
    attempt = receipt.get("attempt")
    if not isinstance(attempt, int) or isinstance(attempt, bool) or attempt < 1:
        raise MediaError(f"latest build receipt has invalid attempt: {attempt!r}")
    if receipt.get("workspace") != str(WORKSPACE):
        raise MediaError("latest build receipt names a different workspace")
    build_hash = receipt.get("buildHash")
    if not isinstance(build_hash, str) or re.fullmatch(r"[0-9a-f]{64}", build_hash) is None:
        raise MediaError("latest build receipt has an invalid H5 buildHash")
    if receipt.get("targetGame") not in (None, TARGET_GAME):
        raise MediaError("latest build receipt names a different target game")

    # Report paths are repository-relative, so resolve them from the target repo root.
    paths = report_paths(attempt)
    missing = [rel for rel in paths.values() if not resolve_run_artifact_path(rel).is_file()]
    if missing:
        raise MediaError(
            f"current attempt-{attempt} report set is incomplete; no outputs were created. Missing: "
            + ", ".join(missing)
        )

    reports: dict[str, Report] = {}
    for key, relative in paths.items():
        path = resolve_run_artifact_path(relative)
        report = Report(key, repo_relative(path), path, read_json(path), sha256_file(path))
        check_report_identity(report, attempt=attempt, build_hash=build_hash)
        if key.split(":", 1)[0] != "comparison" and report.data.get("passed") is not True:
            raise MediaError(f"{relative}: current browser gate is not an explicit pass")
        reports[key] = report

    # Variant reports are required in addition to the aggregate, so every video
    # is explicitly tied to the exact current aggregate and its named variant.
    for engine in ENGINES:
        aggregate = reports[f"comparison:{engine}"]
        results = aggregate.data.get("results")
        if not isinstance(results, list):
            raise MediaError(f"{aggregate.relative_path}: missing results list")
        for variant in VARIANTS:
            child_rel = f"attempts/attempt-{attempt}/feel-comparison-{engine}/{variant}/report.json"
            child_path = resolve_run_artifact_path(child_rel)
            if not child_path.is_file():
                raise MediaError(f"current attempt-{attempt} variant report is missing: {child_rel}")
            child = Report(
                f"comparison:{engine}:{variant}", repo_relative(child_path), child_path,
                read_json(child_path), sha256_file(child_path)
            )
            if child.data.get("engine") != engine or child.data.get("variant") != variant:
                raise MediaError(f"{child_rel}: engine/variant identity mismatch")
            if child.data.get("attempt") not in (None, attempt):
                raise MediaError(f"{child_rel}: attempt does not match the current receipt")
            if child.data.get("normalInputOnly") is not True or child.data.get("stateInjection") is not False:
                raise MediaError(f"{child_rel}: input provenance is not normal-input-only")
            if child.data.get("errors"):
                raise MediaError(f"{child_rel}: report contains errors")
            source_hash = comparison_source_hash(child.data, child.relative_path)
            if variant == "V3" and source_hash != build_hash:
                raise MediaError(f"{child_rel}: V3 source HTML does not match the current H5 hash")
            matches = [item for item in results if item.get("variant") == variant]
            if len(matches) != 1 or matches[0].get("video") != child.data.get("video"):
                raise MediaError(f"{child_rel}: aggregate video binding is missing or mismatched")
            if comparison_source_hash(matches[0], child.relative_path) != source_hash:
                raise MediaError(f"{child_rel}: aggregate source binding is missing or mismatched")
            reports[child.key] = child

    validate_current_media_bindings(reports)

    return reports, receipt, attempt, build_hash


def source_ref(ref: Any, *, expected_mime: str | None = None) -> SourceRef:
    if not isinstance(ref, dict):
        raise MediaError("expected an artifact reference object")
    relative = ref.get("path")
    reported_hash = ref.get("sha256")
    if not isinstance(relative, str) or not isinstance(reported_hash, str):
        raise MediaError(f"artifact reference must include path and sha256: {ref!r}")
    path = resolve_run_artifact_path(relative)
    if not path.is_file():
        raise MediaError(f"reported artifact is missing: {relative}")
    actual_hash = sha256_file(path)
    if actual_hash != reported_hash:
        raise MediaError(f"reported SHA-256 mismatch for {relative}")
    mime = expected_mime or mime_for(path)
    return SourceRef(repo_relative(path), path, actual_hash, path.stat().st_size, mime)


def mime_for(path: Path) -> str:
    suffix = path.suffix.lower()
    return {
        ".webm": "video/webm",
        ".mp4": "video/mp4",
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".json": "application/json",
    }.get(suffix, "application/octet-stream")


def get_video(report: Report) -> SourceRef:
    return source_ref(report.data.get("video"), expected_mime="video/webm")


def get_variant_video(reports: dict[str, Report], engine: str, variant: str) -> SourceRef:
    child = reports[f"comparison:{engine}:{variant}"]
    return source_ref(child.data.get("video"), expected_mime="video/webm")


def report_action_time_ms(report: Report) -> float:
    actions = report.data.get("actions")
    if not isinstance(actions, list):
        raise MediaError(f"{report.relative_path}: actions list is missing")
    for action in actions:
        if action.get("type") == "trusted-touch-press" and isinstance(action.get("actualMs"), (int, float)):
            return float(action["actualMs"])
    raise MediaError(f"{report.relative_path}: first trusted touch timestamp is missing")


def capture_alignment(report: Report, duration_seconds: float) -> dict[str, Any]:
    """Map the report's post-start capture clock to the newPage-started video PTS.

    Current reports do not carry an absolute recorder marker, so the fallback
    estimates the offset from the encoded duration and the last RAF sample. The
    final recorder tail is not measured; uncertainty therefore remains explicit
    and unquantified rather than being presented as a precise synchronization.
    """
    samples = report.data.get("samples")
    if not isinstance(samples, list) or len(samples) < 2:
        raise MediaError(f"{report.relative_path}: at least two capture-clock samples are required")
    clocks: list[float] = []
    for sample in samples:
        if not isinstance(sample, dict) or not isinstance(sample.get("ms"), (int, float)):
            raise MediaError(f"{report.relative_path}: malformed capture-clock sample")
        value = float(sample["ms"])
        if not math.isfinite(value):
            raise MediaError(f"{report.relative_path}: non-finite capture-clock sample")
        clocks.append(value)
    if any(later < earlier for earlier, later in zip(clocks, clocks[1:])):
        raise MediaError(f"{report.relative_path}: capture-clock samples are not chronological")

    explicit_offset: Any = report.data.get("videoCaptureOffsetSeconds")
    offset_field = "videoCaptureOffsetSeconds"
    video_meta = report.data.get("video")
    if explicit_offset is None:
        explicit_offset = report.data.get("captureOffsetSeconds")
        offset_field = "captureOffsetSeconds"
    if explicit_offset is None and isinstance(video_meta, dict):
        explicit_offset = video_meta.get("captureOffsetSeconds")
        offset_field = "video.captureOffsetSeconds"

    if explicit_offset is not None:
        if not isinstance(explicit_offset, (int, float)) or not math.isfinite(float(explicit_offset)):
            raise MediaError(f"{report.relative_path}: invalid explicit video capture offset")
        offset = float(explicit_offset)
        method = f"reported absolute offset from {offset_field}"
    else:
        offset = duration_seconds - clocks[-1] / 1000
        method = "approximate: encoded video duration minus final post-#start RAF capture-clock sample"

    action_ms = report_action_time_ms(report)
    last_interval = clocks[-1] - clocks[-2]
    sample_start_pts = offset + clocks[0] / 1000
    sample_end_pts = offset + clocks[-1] / 1000
    first_touch_pts = offset + action_ms / 1000
    uncertainty = {
        "status": "unquantified",
        "reason": "the report does not measure the recording tail after its final RAF sample",
        "lastObservedRafIntervalMs": last_interval,
        "inputTimingMaxErrorMs": report.data.get("inputTimingMaxErrorMs"),
    }
    if method.startswith("reported absolute"):
        uncertainty = {
            "status": "reported-marker; residual error not supplied",
            "reason": "the report provides an offset but no residual synchronization error bound",
            "lastObservedRafIntervalMs": last_interval,
            "inputTimingMaxErrorMs": report.data.get("inputTimingMaxErrorMs"),
        }
    if sample_start_pts < -0.05 or sample_end_pts > duration_seconds + 0.05:
        raise MediaError(
            f"{report.relative_path}: capture offset maps sample window outside encoded video"
        )
    if first_touch_pts < 0 or first_touch_pts >= duration_seconds:
        raise MediaError(f"{report.relative_path}: first-touch PTS falls outside encoded video")
    return {
        "offsetSeconds": offset,
        "method": method,
        "uncertainty": uncertainty,
        "captureClockSampleRangeMs": [clocks[0], clocks[-1]],
        # Retained for existing consumers; this is not a game elapsed clock.
        "gameClockSampleRangeMs": [clocks[0], clocks[-1]],
        "sourcePtsSampleRangeSeconds": [sample_start_pts, sample_end_pts],
        "firstTouchCaptureClockMs": action_ms,
        "firstTouchActualMs": action_ms,
        "firstTouchSourcePtsSeconds": first_touch_pts,
        "clockDefinition": "samples.ms/actions.actualMs are capture wall-clock elapsed from after #start, not game elapsed time",
    }


def source_pts_for_clock(alignment: dict[str, Any], capture_clock_ms: float, duration: float) -> float:
    pts = float(alignment["offsetSeconds"]) + float(capture_clock_ms) / 1000
    start, end = alignment["sourcePtsSampleRangeSeconds"]
    clock_range = alignment.get("captureClockSampleRangeMs", alignment["gameClockSampleRangeMs"])
    if capture_clock_ms < clock_range[0] or capture_clock_ms > clock_range[1]:
        raise MediaError(f"requested capture-clock time {capture_clock_ms:.1f} ms is outside recorded RAF samples")
    if pts < 0 or pts >= duration or pts < start - 0.05 or pts > end + 0.05:
        raise MediaError(f"mapped source PTS {pts:.3f}s is outside the sampled recording window")
    return pts


def run_ffmpeg(args: list[str], *, description: str) -> str:
    if not FFMPEG.is_file():
        raise MediaError(f"bundled ffmpeg is missing: {FFMPEG}")
    completed = subprocess.run(
        [str(FFMPEG), "-hide_banner", "-nostdin", *args],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
    )
    if completed.returncode != 0:
        tail = completed.stderr[-5000:]
        raise MediaError(f"ffmpeg failed ({description}, exit {completed.returncode}):\n{tail}")
    return completed.stderr


def probe_video(path: Path) -> dict[str, Any]:
    # Asking ffmpeg for a zero-duration null output reads container metadata and
    # at most the first packet; it does not transcode or scan the full recording.
    proc = subprocess.run(
        [str(FFMPEG), "-hide_banner", "-nostdin", "-i", str(path), "-t", "0", "-f", "null", "-"],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
    )
    text = proc.stderr
    duration_match = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", text)
    stream_match = re.search(r"Video:.*?,\s*(\d{2,5})x(\d{2,5})(?:[\s,]|$)", text)
    if not duration_match or not stream_match:
        raise MediaError(f"ffmpeg could not read duration/dimensions for {path}: {text[-1500:]}")
    hh, mm, ss = duration_match.groups()
    duration = int(hh) * 3600 + int(mm) * 60 + float(ss)
    return {"durationSeconds": duration, "width": int(stream_match.group(1)), "height": int(stream_match.group(2))}


def extract_frame(source: SourceRef, seconds: float, output: Path) -> dict[str, Any]:
    if seconds < 0:
        raise MediaError(f"negative source timestamp requested for {source.relative_path}")
    output.parent.mkdir(parents=True, exist_ok=True)
    log = run_ffmpeg(
        [
            "-loglevel", "info", "-i", str(source.path), "-vf",
            f"select='gte(t,{seconds:.6f})',showinfo", "-frames:v", "1",
            "-fps_mode", "passthrough", "-compression_level", "6", str(output),
        ],
        description=f"full-frame extraction at {seconds:.3f}s from {source.relative_path}",
    )
    if not output.is_file() or output.stat().st_size == 0:
        raise MediaError(f"no decoded source frame at {seconds:.3f}s in {source.relative_path}")
    match = re.findall(r"pts_time:([0-9.]+)", log)
    if not match:
        raise MediaError(f"ffmpeg did not report the decoded frame PTS for {source.relative_path}")
    actual_seconds = float(match[-1])
    with Image.open(output) as image:
        image.verify()
    return {"requestedSeconds": seconds, "actualSourcePtsSeconds": actual_seconds}


def font(size: int = 22) -> ImageFont.ImageFont:
    try:
        return ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial Unicode.ttf", size)
    except OSError:
        return ImageFont.load_default()


def make_contact_sheet(
    cells: list[tuple[str, Path]],
    output: Path,
    *,
    columns: int,
    target_width: int | None = None,
) -> None:
    if not cells or columns < 1:
        raise MediaError("cannot make an empty contact sheet")
    rows = math.ceil(len(cells) / columns)
    padding, label_h = 10, 36
    images: list[tuple[str, Image.Image]] = []
    max_w = max_h = 0
    for label, path in cells:
        im = Image.open(path).convert("RGB")
        if target_width and im.width > target_width:
            new_h = round(im.height * target_width / im.width)
            im = im.resize((target_width, new_h), Image.Resampling.LANCZOS)
        images.append((label, im))
        max_w, max_h = max(max_w, im.width), max(max_h, im.height)
    cell_w = max_w + padding * 2
    cell_h = max_h + label_h + padding * 2
    sheet = Image.new("RGB", (columns * cell_w, rows * cell_h), (24, 28, 35))
    draw = ImageDraw.Draw(sheet)
    label_font = font(22)
    for index, (label, im) in enumerate(images):
        row, col = divmod(index, columns)
        x, y = col * cell_w + padding, row * cell_h + padding
        draw.text((x, y), label, fill=(245, 244, 238), font=label_font)
        # Every image is kept whole and uniformly scaled. Label pixels sit above it.
        sheet.paste(im, (x, y + label_h))
        im.close()
    output.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(output, format="PNG", optimize=True)
    sheet.close()


def encode_mp4(
    source: SourceRef,
    output: Path,
    *,
    start_seconds: float = 0.0,
    duration_seconds: float | None = None,
    scale_height: int | None = None,
) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    base = ["-y", "-loglevel", "error", "-i", str(source.path), "-map", "0:v:0", "-map", "0:a?"]
    if start_seconds > 0:
        base += ["-ss", f"{start_seconds:.6f}"]
    if duration_seconds is not None:
        base += ["-t", f"{duration_seconds:.3f}"]
    if scale_height:
        base += ["-vf", f"scale=-2:{scale_height}:flags=lanczos,setsar=1"]
    args = base + [
        "-fps_mode", "passthrough",
        "-c:v", "libx264", "-preset", "medium", "-crf", "23", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "96k", "-movflags", "+faststart", str(output),
    ]
    run_ffmpeg(args, description=f"full-record MP4 transcode of {source.relative_path}")
    if output.stat().st_size > MAX_FILE_BYTES:
        duration = duration_seconds
        if duration is None:
            duration = probe_video(source.path)["durationSeconds"]
        target_kbps = max(350, min(6000, int((MAX_FILE_BYTES * 8 / max(duration, 1)) / 1000 * 0.72)))
        args = base + [
            "-fps_mode", "passthrough",
            "-c:v", "libx264", "-preset", "medium", "-b:v", f"{target_kbps}k",
            "-maxrate", f"{target_kbps}k", "-bufsize", f"{target_kbps * 2}k",
            "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "96k",
            "-movflags", "+faststart", str(output),
        ]
        run_ffmpeg(args, description=f"size-bounded MP4 transcode of {source.relative_path}")
    if output.stat().st_size > MAX_FILE_BYTES:
        raise MediaError(f"derived MP4 exceeds 90 MiB after bitrate adjustment: {output}")


def encode_triptych(
    inputs: list[tuple[SourceRef, float]], output: Path, duration_seconds: float
) -> None:
    if len(inputs) != 3:
        raise MediaError("triptych requires PR10, PR13, and V3 source videos")
    output.parent.mkdir(parents=True, exist_ok=True)
    filters: list[str] = []
    labels: list[str] = []
    args = ["-y", "-loglevel", "error"]
    for index, (source, source_start_seconds) in enumerate(inputs):
        args += ["-i", str(source.path)]
        filters.append(
            f"[{index}:v]trim=start={source_start_seconds:.6f}:duration={duration_seconds:.3f},"
            f"setpts=PTS-STARTPTS,scale=-2:720:flags=lanczos,setsar=1[v{index}]"
        )
        labels.append(f"[v{index}]")
    filters.append(f"{''.join(labels)}hstack=inputs=3:shortest=1[vout]")
    args += [
        "-filter_complex", ";".join(filters), "-map", "[vout]", "-an",
        "-fps_mode", "passthrough", "-c:v", "libx264", "-preset", "medium",
        "-crf", "24", "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(output),
    ]
    run_ffmpeg(args, description="approximate first-touch-referenced three-column full-frame comparison")
    if output.stat().st_size > MAX_FILE_BYTES:
        raise MediaError(f"triptych MP4 exceeds 90 MiB: {output}")


def screenshot_ref(report: Report, *, basename: str, width: int | None = None) -> dict[str, Any]:
    entries: list[dict[str, Any]] = []
    for block in report.data.get("reports", []) if isinstance(report.data.get("reports"), list) else []:
        viewport = block.get("viewport", {})
        if width is not None and viewport.get("width") != width:
            continue
        entries.extend(item for item in block.get("screenshots", []) if isinstance(item, dict))
    entries.extend(item for item in report.data.get("screenshots", []) if isinstance(item, dict))
    matches = [item for item in entries if Path(item.get("path", "")).name == basename]
    if len(matches) != 1:
        raise MediaError(f"{report.relative_path}: expected one screenshot {basename}, found {len(matches)}")
    return matches[0]


def choose_risk_level(report: Report) -> tuple[int, str]:
    levels = report.data.get("levels")
    if not isinstance(levels, list):
        raise MediaError(f"{report.relative_path}: levels list is missing")
    candidates = []
    for item in levels:
        level_id = item.get("id", item.get("levelId"))
        if level_id in (4, 5):
            weather = str(item.get("weather", "unknown"))
            is_risk = weather.lower() not in ("clear", "sunny", "none", "unknown", "")
            candidates.append((level_id, weather, is_risk))
    risky = [item for item in candidates if item[2]]
    if risky:
        chosen = max(risky, key=lambda item: item[0])
        return chosen[0], chosen[1]
    stage5 = [item for item in candidates if item[0] == 5]
    if stage5:
        return stage5[0][0], stage5[0][1]
    if candidates:
        chosen = max(candidates, key=lambda item: item[0])
        return chosen[0], chosen[1]
    raise MediaError(f"{report.relative_path}: no level 4/5 risk stage exists")


def risk_video(report: Report, level_id: int) -> SourceRef:
    levels = report.data["levels"]
    matches = [item for item in levels if item.get("id", item.get("levelId")) == level_id]
    if len(matches) != 1:
        raise MediaError(f"{report.relative_path}: expected level {level_id} video record")
    level_ref = matches[0].get("video")
    video_list = report.data.get("videos", [])
    refs = [item for item in video_list if item.get("levelId") == level_id]
    if len(refs) != 1:
        raise MediaError(f"{report.relative_path}: report videos list lacks level {level_id}")
    list_ref = refs[0]
    if not isinstance(level_ref, dict):
        level_ref = list_ref
    if level_ref.get("levelId", level_id) != level_id or list_ref.get("levelId") != level_id:
        raise MediaError(f"{report.relative_path}: level video ref identity mismatch")
    if level_ref.get("path") != list_ref.get("path") or level_ref.get("sha256") != list_ref.get("sha256"):
        raise MediaError(f"{report.relative_path}: level record and videos list disagree for level {level_id}")
    return source_ref(level_ref, expected_mime="video/webm")


def risk_screenshot(report: Report, level_id: int, kind: str) -> dict[str, Any]:
    screenshots = report.data.get("screenshots", [])
    matches = [
        item for item in screenshots
        if item.get("levelId") == level_id and item.get("kind") == kind
    ]
    if not matches and kind == "barrier-cleared":
        matches = [
            item for item in screenshots
            if item.get("levelId") == level_id and item.get("kind") == "jump-input"
        ]
    if not matches:
        raise MediaError(f"{report.relative_path}: level-{level_id} {kind} screenshot is missing")
    if any(not isinstance(item.get("at"), str) for item in matches):
        raise MediaError(f"{report.relative_path}: {kind} candidates lack actual report timestamps")
    # Level 5 contains multiple ordered hazard beats; retain the last observed
    # beat in the chosen risk level instead of assuming a single row exists.
    return max(matches, key=lambda item: item["at"])


def validate_current_media_bindings(reports: dict[str, Report]) -> None:
    """Read and SHA-check every raw input the generator will publish or transcode."""
    for engine in ENGINES:
        source_ref(reports[f"experience:{engine}"].data.get("video"), expected_mime="video/webm")
        source_ref(reports[f"feel-state:{engine}"].data.get("video"), expected_mime="video/webm")
        for variant in VARIANTS:
            report = reports[f"comparison:{engine}:{variant}"]
            source_ref(report.data.get("video"), expected_mime="video/webm")

        head_report = reports[f"head:{engine}"]
        for width, basename in ((390, "390-fish-catch.png"), (320, "320-fish-catch.png")):
            source_ref(screenshot_ref(head_report, basename=basename, width=width), expected_mime="image/png")
        experience_report = reports[f"experience:{engine}"]
        source_ref(
            screenshot_ref(experience_report, basename="small-phone-route-menu.png"),
            expected_mime="image/png",
        )

        risk_report = reports[f"risk:{engine}"]
        level_id, _ = choose_risk_level(risk_report)
        risk_video(risk_report, level_id)
        for kind in ("reward-approach", "barrier-cleared"):
            source_ref(risk_screenshot(risk_report, level_id, kind), expected_mime="image/png")
        source_ref(
            risk_screenshot(risk_report, level_id, "terminal-settlement"),
            expected_mime="image/png",
        )


def add_media_record(
    entries: list[dict[str, Any]], *, stage_path: Path, run_output: str | None,
    docs_output: str | None, mime: str, source: SourceRef, source_report: Report,
    metadata: dict[str, Any], derived: bool, source_build_hash: str,
) -> None:
    if not stage_path.is_file():
        raise MediaError(f"staged output is missing: {stage_path}")
    size = stage_path.stat().st_size
    if size > MAX_FILE_BYTES:
        raise MediaError(f"output exceeds 90 MiB: {stage_path}")
    digest = sha256_file(stage_path)
    entries.append({
        "sourceReport": {
            "path": source_report.relative_path,
            "sha256": source_report.sha256,
        },
        "sourceInput": {
            "path": source.relative_path,
            "sha256": source.sha256,
            "bytes": source.size_bytes,
            "mime": source.mime,
        },
        "runOutput": ({"path": run_output, "sha256": digest, "bytes": size, "mime": mime}
                       if run_output else None),
        "docsOutput": ({"path": docs_output, "sha256": digest, "bytes": size, "mime": mime}
                        if docs_output else None),
        "sourceBuildHash": source_build_hash,
        "derivedFromRaw": derived,
        **metadata,
    })


def write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def stage_outputs(
    reports: dict[str, Report], receipt: dict[str, Any], attempt: int,
    build_hash: str, stage: Path,
) -> tuple[list[tuple[Path, Path]], dict[str, Any]]:
    attempt_frames_rel = f"runs/pelican-coast-v2-20261014/attempts/attempt-{attempt}/comparison-frames"
    attempt_media_rel = f"runs/pelican-coast-v2-20261014/attempts/attempt-{attempt}/key-media"
    docs_rel = "docs/lean-pilot/pelican-feel-v3-20261014/evidence-media"
    frame_stage = stage / "comparison-frames"
    run_media_stage = stage / "run-key-media"
    docs_stage = stage / "docs-evidence-media"
    public_docs_stage = docs_stage / "key-png"
    docs_video_stage = docs_stage / "videos"
    docs_sheet_stage = docs_stage / "comparison-sheets"

    frame_records: list[dict[str, Any]] = []
    media_records: list[dict[str, Any]] = []
    staged_targets: list[tuple[Path, Path]] = []
    source_videos: dict[tuple[str, str], SourceRef] = {}
    comparison_descriptors: dict[tuple[str, str], dict[str, Any]] = {}

    # The 36 primary comparison frames retain their full decoded source pixels.
    for engine in ENGINES:
        for variant in VARIANTS:
            report = reports[f"comparison:{engine}:{variant}"]
            source = get_variant_video(reports, engine, variant)
            video_info = probe_video(source.path)
            touch_ms = report_action_time_ms(report)
            alignment = capture_alignment(report, video_info["durationSeconds"])
            if abs(alignment["firstTouchActualMs"] - touch_ms) > 0.001:
                raise MediaError(f"{report.relative_path}: first-touch alignment metadata is inconsistent")
            frames: list[dict[str, Any]] = []
            for time_ms in FRAME_TIMES_MS:
                source_pts = source_pts_for_clock(alignment, time_ms, video_info["durationSeconds"])
                output_name = f"{engine}-{variant}-{time_ms:04d}.png"
                output = frame_stage / output_name
                timestamp = extract_frame(source, source_pts, output)
                with Image.open(output) as frame:
                    if frame.size != (video_info["width"], video_info["height"]):
                        raise MediaError(f"frame dimensions changed during extraction: {output_name}")
                record = {
                    "path": f"{attempt_frames_rel}/{output_name}",
                    "sha256": sha256_file(output),
                    "bytes": output.stat().st_size,
                    "mime": "image/png",
                    "requestedInputClockMs": time_ms,
                    "requestedCaptureClockMs": time_ms,
                    "clockDefinition": alignment["clockDefinition"],
                    "requestedSourcePtsSeconds": source_pts,
                    "actualSourcePtsSeconds": timestamp["actualSourcePtsSeconds"],
                }
                frames.append(record)
                frame_records.append({
                    "engine": engine,
                    "variant": variant,
                    "targetGame": TARGET_GAME,
                    "workspace": str(WORKSPACE),
                    "sourceBuildHash": build_hash,
                    "sourceReport": {"path": report.relative_path, "sha256": report.sha256},
                    "sourceVideo": {
                        "path": source.relative_path,
                        "sha256": source.sha256,
                        "bytes": source.size_bytes,
                        "mime": source.mime,
                    },
                    "sourceHash": comparison_source_hash(report.data, report.relative_path),
                    "cameraMode": report.data.get("cameraMode"),
                    "inputSemantics": (
                        "side-view; held steering" if variant == "PR10" else
                        "rear-view; one-lane steering"
                    ),
                    "captureOffsetSeconds": alignment["offsetSeconds"],
                    "captureOffsetMethod": alignment["method"],
                    "captureOffsetUncertainty": alignment["uncertainty"],
                    "touchAlignmentActualMs": touch_ms,
                    "touchAlignmentCaptureClockMs": touch_ms,
                    "touchAlignmentSourcePtsSeconds": alignment["firstTouchSourcePtsSeconds"],
                    "frame": record,
                    "extraction": "first original decoded frame at or after requested source PTS; full frame, no crop or generated pixels",
                })
                staged_targets.append((output, REPO_ROOT / record["path"]))
            source_videos[(engine, variant)] = source
            comparison_descriptors[(engine, variant)] = {
                "report": report,
                "source": source,
                "duration": video_info["durationSeconds"],
                "touchMs": touch_ms,
                "alignment": alignment,
                "frames": frames,
            }

    # 84 dense V3 frames, sampled after each report's first-touch capture time.
    for engine in ENGINES:
        report = reports[f"comparison:{engine}:V3"]
        source = source_videos[(engine, "V3")]
        video_info = probe_video(source.path)
        descriptor = comparison_descriptors[(engine, "V3")]
        alignment = descriptor["alignment"]
        first_capture_clock_ms = round(
            alignment["firstTouchCaptureClockMs"] + TEMPORAL_POST_TOUCH_START_MS
        )
        temporal_times_ms = [
            first_capture_clock_ms + index * TEMPORAL_STEP_MS
            for index in range(TEMPORAL_COUNT)
        ]
        if temporal_times_ms[-1] > alignment["captureClockSampleRangeMs"][1]:
            raise MediaError(f"{report.relative_path}: temporal V3 schedule leaves the captured ride window")
        temporal: list[dict[str, Any]] = []
        for index, time_ms in enumerate(temporal_times_ms):
            source_pts = source_pts_for_clock(alignment, time_ms, video_info["durationSeconds"])
            output_name = f"{engine}-V3-temporal-{index:02d}.png"
            output = frame_stage / output_name
            timestamp = extract_frame(source, source_pts, output)
            with Image.open(output) as frame:
                if frame.size != (video_info["width"], video_info["height"]):
                    raise MediaError(f"temporal frame dimensions changed: {output_name}")
            record = {
                "path": f"{attempt_frames_rel}/{output_name}",
                "sha256": sha256_file(output),
                "bytes": output.stat().st_size,
                "mime": "image/png",
                "sampleIndex": index,
                "requestedInputClockMs": time_ms,
                "requestedCaptureClockMs": time_ms,
                "clockDefinition": alignment["clockDefinition"],
                "requestedSourcePtsSeconds": source_pts,
                "actualSourcePtsSeconds": timestamp["actualSourcePtsSeconds"],
            }
            temporal.append(record)
            frame_records.append({
                "engine": engine,
                "variant": "V3",
                "targetGame": TARGET_GAME,
                "workspace": str(WORKSPACE),
                "sourceBuildHash": build_hash,
                "sourceReport": {"path": report.relative_path, "sha256": report.sha256},
                "sourceVideo": {
                    "path": source.relative_path,
                    "sha256": source.sha256,
                    "bytes": source.size_bytes,
                    "mime": source.mime,
                },
                "sourceHash": comparison_source_hash(report.data, report.relative_path),
                "cameraMode": report.data.get("cameraMode"),
                "inputSemantics": "rear-view; one-lane steering",
                "captureOffsetSeconds": alignment["offsetSeconds"],
                "captureOffsetMethod": alignment["method"],
                "captureOffsetUncertainty": alignment["uncertainty"],
                "touchAlignmentActualMs": alignment["firstTouchActualMs"],
                "touchAlignmentCaptureClockMs": alignment["firstTouchCaptureClockMs"],
                "touchAlignmentSourcePtsSeconds": alignment["firstTouchSourcePtsSeconds"],
                "frame": record,
                "extraction": "first original decoded frame at or after requested source PTS; full frame, no crop or generated pixels",
            })
            staged_targets.append((output, REPO_ROOT / record["path"]))
        comparison_descriptors[(engine, "V3")]["temporalFrames"] = temporal
        comparison_descriptors[(engine, "V3")]["temporalScheduleMs"] = temporal_times_ms

    # Two readable comparison strips (one per engine), 6 rows × 3 full-frame columns.
    sheet_outputs: list[tuple[str, Path, str, dict[str, Any]]] = []
    for engine in ENGINES:
        cells: list[tuple[str, Path]] = []
        for time_ms in FRAME_TIMES_MS:
            for variant in VARIANTS:
                name = f"{engine}-{variant}-{time_ms:04d}.png"
                cells.append((f"{variant} | capture t+{time_ms / 1000:.2f}s", frame_stage / name))
        output = frame_stage / f"comparison-strip-{engine}.png"
        make_contact_sheet(cells, output, columns=3, target_width=390)
        sheet_outputs.append((engine, output, "comparison-strip", {
            "engine": engine,
            "layout": "six sampled timestamps by three native variants; labels outside full-frame pixels",
            "clockDefinition": "labels are post-#start capture wall-clock offsets, not game elapsed seconds",
            "cameraCaveat": "PR10 side-view/held steering; PR13 and V3 rear-view/one-lane steering; descriptive, not controlled same-camera evidence",
        }))
        temporal_cells = []
        temporal_schedule = comparison_descriptors[(engine, "V3")]["temporalScheduleMs"]
        for index, ms in enumerate(temporal_schedule):
            name = f"{engine}-V3-temporal-{index:02d}.png"
            temporal_cells.append((f"V3 | capture t+{ms / 1000:.2f}s", frame_stage / name))
        temporal_output = frame_stage / f"temporal-grid-{engine}-V3.png"
        make_contact_sheet(temporal_cells, temporal_output, columns=7, target_width=260)
        sheet_outputs.append((engine, temporal_output, "temporal-grid", {
            "engine": engine,
            "variant": "V3",
            "layout": "42 source frames in seven columns; full-frame proportional reductions only",
                "clockDefinition": "labels are post-#start capture wall-clock offsets, not game elapsed seconds",
        }))

    # Resolve public PNG sources only from this receipt's report set.
    for engine in ENGINES:
        head_report = reports[f"head:{engine}"]
        experience_report = reports[f"experience:{engine}"]
        risk_report = reports[f"risk:{engine}"]
        for role, width, basename, source_report in (
            ("head", 390, "390-fish-catch.png", head_report),
            ("compact", 320, "320-fish-catch.png", head_report),
            ("menu", None, "small-phone-route-menu.png", experience_report),
        ):
            ref = screenshot_ref(source_report, basename=basename, width=width)
            source = source_ref(ref, expected_mime="image/png")
            staged = public_docs_stage / f"{role}-{engine}.png"
            staged.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source.path, staged)
            if sha256_file(staged) != source.sha256:
                raise MediaError(f"byte-preserving PNG copy failed: {source.relative_path}")
            run_output = f"{attempt_media_rel}/key-png/{role}-{engine}.png"
            docs_output = f"{docs_rel}/key-png/{role}-{engine}.png"
            run_stage = run_media_stage / "key-png" / f"{role}-{engine}.png"
            run_stage.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(staged, run_stage)
            add_media_record(
                media_records, stage_path=staged, run_output=run_output, docs_output=docs_output,
                mime="image/png", source=source, source_report=source_report,
                metadata={"assetRole": role, "actualTimestamp": None, "copyBytesOnly": True},
                derived=False, source_build_hash=build_hash,
            )
            staged_targets.extend([(run_stage, REPO_ROOT / run_output), (staged, REPO_ROOT / docs_output)])

        level_id, weather = choose_risk_level(risk_report)
        for role, kind in (("hazard-approach", "reward-approach"), ("hazard-clear", "barrier-cleared")):
            ref = risk_screenshot(risk_report, level_id, kind)
            source = source_ref(ref, expected_mime="image/png")
            filename = f"{role}-level-{level_id}-{engine}.png"
            staged = public_docs_stage / filename
            staged.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source.path, staged)
            if sha256_file(staged) != source.sha256:
                raise MediaError(f"byte-preserving PNG copy failed: {source.relative_path}")
            run_output = f"{attempt_media_rel}/key-png/{filename}"
            docs_output = f"{docs_rel}/key-png/{filename}"
            run_stage = run_media_stage / "key-png" / filename
            run_stage.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(staged, run_stage)
            add_media_record(
                media_records, stage_path=staged, run_output=run_output, docs_output=docs_output,
                mime="image/png", source=source, source_report=risk_report,
                metadata={"assetRole": role, "riskLevel": level_id, "weather": weather,
                          "targetBarrierId": ref.get("targetBarrierId"),
                          "actualTimestamp": ref.get("at"), "copyBytesOnly": True},
                derived=False, source_build_hash=build_hash,
            )
            staged_targets.extend([(run_stage, REPO_ROOT / run_output), (staged, REPO_ROOT / docs_output)])

        ref = risk_screenshot(risk_report, level_id, "terminal-settlement")
        source = source_ref(ref, expected_mime="image/png")
        filename = f"settlement-level-{level_id}-{engine}.png"
        staged = public_docs_stage / filename
        staged.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source.path, staged)
        if sha256_file(staged) != source.sha256:
            raise MediaError(f"byte-preserving PNG copy failed: {source.relative_path}")
        run_output = f"{attempt_media_rel}/key-png/{filename}"
        docs_output = f"{docs_rel}/key-png/{filename}"
        run_stage = run_media_stage / "key-png" / filename
        run_stage.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(staged, run_stage)
        add_media_record(
            media_records, stage_path=staged, run_output=run_output, docs_output=docs_output,
            mime="image/png", source=source, source_report=risk_report,
            metadata={"assetRole": "settlement", "riskLevel": level_id, "weather": weather,
                      "targetBarrierId": ref.get("targetBarrierId"),
                      "actualTimestamp": ref.get("at"), "copyBytesOnly": True},
            derived=False, source_build_hash=build_hash,
        )
        staged_targets.extend([(run_stage, REPO_ROOT / run_output), (staged, REPO_ROOT / docs_output)])

    # Six clips start at the approximate report-clock zero and retain the
    # original recording rate; the available source duration may be under 5 s.
    for engine in ENGINES:
        for variant in VARIANTS:
            descriptor = comparison_descriptors[(engine, variant)]
            source = descriptor["source"]
            alignment = descriptor["alignment"]
            clip_start = max(0.0, alignment["offsetSeconds"])
            clip_duration = min(MATCHED_CLIP_SECONDS, descriptor["duration"] - clip_start)
            if clip_duration <= 0:
                raise MediaError(f"matched-touch source has no duration after capture start: {source.relative_path}")
            filename = f"matched-touch-{engine}-{variant}.mp4"
            staged = run_media_stage / filename
            encode_mp4(
                source, staged, start_seconds=clip_start,
                duration_seconds=clip_duration, scale_height=720,
            )
            report = descriptor["report"]
            run_output = f"{attempt_media_rel}/{filename}"
            docs_output = f"{docs_rel}/videos/{filename}"
            docs_copy = docs_video_stage / filename
            docs_copy.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(staged, docs_copy)
            add_media_record(
                media_records, stage_path=staged, run_output=run_output, docs_output=docs_output,
                mime="video/mp4", source=source, source_report=report,
                metadata={
                    "assetRole": "matched-touch-clip",
                    "engine": engine,
                    "variant": variant,
                    "durationSeconds": clip_duration,
                    "requestedMaxDurationSeconds": MATCHED_CLIP_SECONDS,
                    "sourceStartPtsSeconds": clip_start,
                    "firstTouchActualMs": descriptor["touchMs"],
                    "firstTouchCaptureClockMs": alignment["firstTouchCaptureClockMs"],
                    "firstTouchSourcePtsSeconds": alignment["firstTouchSourcePtsSeconds"],
                    "firstTouchClipTimeSeconds": alignment["firstTouchSourcePtsSeconds"] - clip_start,
                    "clockDefinition": alignment["clockDefinition"],
                    "captureOffsetSeconds": alignment["offsetSeconds"],
                    "captureOffsetMethod": alignment["method"],
                    "captureOffsetUncertainty": alignment["uncertainty"],
                    "alignmentQuality": "approximate; recorder-tail uncertainty is unquantified",
                    "cameraMode": report.data.get("cameraMode"),
                    "inputSemantics": "side-view/held steering" if variant == "PR10" else "rear-view/one-lane steering",
                    "comparisonClaim": "descriptive matched-input evidence; approximate capture-start mapping; not a controlled same-camera comparison",
                    "transcode": "H.264, full-frame proportional scale to 720px high, original playback timing, capture-start prefix retained",
                }, derived=True, source_build_hash=build_hash,
            )
            staged_targets.extend([(staged, REPO_ROOT / run_output), (docs_copy, REPO_ROOT / docs_output)])

    # Two three-column clips align approximately at the actual first-touch
    # events, with a lead-in when the source has enough pre-touch footage.
    for engine in ENGINES:
        triptych_inputs = []
        for variant in VARIANTS:
            descriptor = comparison_descriptors[(engine, variant)]
            alignment = descriptor["alignment"]
            touch_pts = alignment["firstTouchSourcePtsSeconds"]
            source_start = max(0.0, touch_pts - TRIPTYCH_PRE_TOUCH_SECONDS)
            triptych_inputs.append({
                "source": descriptor["source"],
                "sourceStartPtsSeconds": source_start,
                "firstTouchSourcePtsSeconds": touch_pts,
                "firstTouchActualMs": descriptor["touchMs"],
                "firstTouchCaptureClockMs": alignment["firstTouchCaptureClockMs"],
                "firstTouchClipTimeSeconds": touch_pts - source_start,
                "alignment": alignment,
            })
        common = min(
            TRIPTYCH_SECONDS_CAP,
            *(comparison_descriptors[(engine, variant)]["duration"] -
              triptych_inputs[index]["sourceStartPtsSeconds"]
              for index, variant in enumerate(VARIANTS)),
        )
        if common < TRIPTYCH_SECONDS_MIN:
            raise MediaError(f"{engine} common full-frame clip is only {common:.3f}s")
        filename = f"first-touch-triptych-{engine}.mp4"
        staged = run_media_stage / filename
        encode_triptych(
            [(item["source"], item["sourceStartPtsSeconds"]) for item in triptych_inputs],
            staged, common,
        )
        docs_copy = docs_video_stage / filename
        docs_copy.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(staged, docs_copy)
        report = reports[f"comparison:{engine}"]
        for output_path, dest_rel in (
            (staged, f"{attempt_media_rel}/{filename}"),
            (docs_copy, f"{docs_rel}/videos/{filename}"),
        ):
            media_records.append({
                "sourceReport": {"path": report.relative_path, "sha256": report.sha256},
                "sourceInputs": [
                    {
                        "path": comparison_descriptors[(engine, variant)]["source"].relative_path,
                        "sha256": comparison_descriptors[(engine, variant)]["source"].sha256,
                        "bytes": comparison_descriptors[(engine, variant)]["source"].size_bytes,
                        "mime": "video/webm",
                        "variant": variant,
                        "firstTouchActualMs": triptych_inputs[index]["firstTouchActualMs"],
                        "firstTouchCaptureClockMs": triptych_inputs[index]["firstTouchCaptureClockMs"],
                        "sourceStartPtsSeconds": triptych_inputs[index]["sourceStartPtsSeconds"],
                        "firstTouchSourcePtsSeconds": triptych_inputs[index]["firstTouchSourcePtsSeconds"],
                        "firstTouchClipTimeSeconds": triptych_inputs[index]["firstTouchClipTimeSeconds"],
                        "captureOffsetSeconds": triptych_inputs[index]["alignment"]["offsetSeconds"],
                        "captureOffsetMethod": triptych_inputs[index]["alignment"]["method"],
                        "captureOffsetUncertainty": triptych_inputs[index]["alignment"]["uncertainty"],
                    }
                    for index, variant in enumerate(VARIANTS)
                ],
                "output": {
                    "path": dest_rel,
                    "sha256": sha256_file(output_path),
                    "bytes": output_path.stat().st_size,
                    "mime": "video/mp4",
                },
                "sourceBuildHash": build_hash,
                "derivedFromRaw": True,
                "assetRole": "first-touch-triptych",
                "engine": engine,
                "columnOrder": list(VARIANTS),
                "durationSeconds": common,
                "clockDefinition": "per-engine report capture-clock values start after #start; labels are not game elapsed times",
                "alignmentQuality": "approximate first-touch reference only; not perfectly synchronized; recorder-tail uncertainty is unquantified",
                "comparisonClaim": "descriptive only; camera/input semantics differ and timing is approximate",
                "alignment": {
                    "method": "estimated source PTS = capture offset + post-#start capture-clock timestamp; each clip starts up to 0.6 s before that estimate",
                    "clockDefinition": "actions.actualMs and samples.ms are post-#start capture wall-clock offsets, not game elapsed time",
                    "preTouchLeadRequestedSeconds": TRIPTYCH_PRE_TOUCH_SECONDS,
                    "firstTouchClipTimesSeconds": [item["firstTouchClipTimeSeconds"] for item in triptych_inputs],
                    "captureOffsetUncertainty": "unquantified recorder-tail uncertainty; see per-sourceInputs",
                },
                "cameraCaveat": "PR10 side-view/held steering; PR13 and V3 rear-view/one-lane steering; no ranking or same-camera claim",
                "transcode": "H.264, three full-frame proportional 720px-high columns, original playback speed, no audio",
            })
        staged_targets.extend([
            (staged, REPO_ROOT / f"{attempt_media_rel}/{filename}"),
            (docs_copy, REPO_ROOT / f"{docs_rel}/videos/{filename}"),
        ])

    # Long records: 2 experience, 2 feel-state, and one level-4/5 risk run per engine.
    long_videos: list[tuple[str, str, Report, SourceRef, dict[str, Any]]] = []
    for engine in ENGINES:
        exp_report = reports[f"experience:{engine}"]
        long_videos.append((f"experience-{engine}", "experience-full-record", exp_report,
                            get_video(exp_report), {"engine": engine}))
        feel_report = reports[f"feel-state:{engine}"]
        long_videos.append((f"feel-state-{engine}", "feel-state-full-record", feel_report,
                            get_video(feel_report), {"engine": engine}))
        risk_report = reports[f"risk:{engine}"]
        level_id, weather = choose_risk_level(risk_report)
        long_videos.append((f"risk-level-{level_id}-{engine}", "risk-full-record", risk_report,
                            risk_video(risk_report, level_id),
                            {"engine": engine, "riskLevel": level_id, "weather": weather,
                             "selectionReason": "highest available non-clear level among 4/5, otherwise level 5"}))

    for slug, role, report, source, extra in long_videos:
        info = probe_video(source.path)
        filename = f"{slug}.mp4"
        staged = run_media_stage / filename
        encode_mp4(source, staged)
        docs_copy = docs_video_stage / filename
        docs_copy.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(staged, docs_copy)
        run_output = f"{attempt_media_rel}/{filename}"
        docs_output = f"{docs_rel}/videos/{filename}"
        add_media_record(
            media_records, stage_path=staged, run_output=run_output, docs_output=docs_output,
            mime="video/mp4", source=source, source_report=report,
            metadata={
                "assetRole": role,
                **extra,
                "durationSeconds": info["durationSeconds"],
                "sourceDimensions": [info["width"], info["height"]],
                "transcode": "full recording, full frame, H.264 MP4; no trimming or speed change; audio converted only when present",
            }, derived=True, source_build_hash=build_hash,
        )
        staged_targets.extend([(staged, REPO_ROOT / run_output), (docs_copy, REPO_ROOT / docs_output)])

    # Deliver contact sheets to docs as copies of the run evidence sheets.
    for engine, sheet, role, metadata in sheet_outputs:
        filename = sheet.name
        run_output = f"{attempt_frames_rel}/{filename}"
        docs_output = f"{docs_rel}/comparison-sheets/{filename}"
        docs_copy = docs_sheet_stage / filename
        docs_copy.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(sheet, docs_copy)
        source_descriptor = comparison_descriptors[(engine, "V3")]
        source = source_descriptor["source"]
        report = source_descriptor["report"]
        add_media_record(
            media_records, stage_path=sheet, run_output=run_output, docs_output=docs_output,
            mime="image/png", source=source, source_report=report,
            metadata={"assetRole": role, **metadata, "actualTimestamp": None,
                      "copyDocsBytesOnly": True},
            derived=True, source_build_hash=build_hash,
        )
        staged_targets.extend([(sheet, REPO_ROOT / run_output), (docs_copy, REPO_ROOT / docs_output)])

    comparison_provenance = {
        "schemaVersion": 2,
        "targetGame": TARGET_GAME,
        "workspace": str(WORKSPACE),
        "sourceBuildHash": build_hash,
        "attempt": attempt,
        "receipt": {
            "path": repo_relative(RUN_ROOT / "build-receipt.json"),
            "sha256": sha256_file(RUN_ROOT / "build-receipt.json"),
            "attempt": receipt.get("attempt"),
            "buildHash": receipt.get("buildHash"),
        },
        "method": "Original decoded full frames only. No crop, avatar-centering, generated gameplay frame, interpolation, or speed changes. Contact sheets use proportional full-frame reduction and labels outside each frame.",
        "clockDefinition": {
            "reportClock": "actions.actualMs and samples.ms are capture wall-clock elapsed after #start; they are not game elapsed seconds",
            "legacyFields": {
                "requestedInputClockMs": "post-#start capture wall-clock milliseconds; see requestedCaptureClockMs",
                "gameClockSampleRangeMs": "legacy name for the post-#start capture-clock sample range; not game time",
                "firstTouchActualMs": "actual report input timestamp on the post-#start capture clock; see firstTouchCaptureClockMs",
                "touchAlignmentActualMs": "actual report input timestamp on the post-#start capture clock; see touchAlignmentCaptureClockMs",
                "comparisonFrameGameClockMs": "legacy name for the post-#start capture-clock frame schedule; not game time",
                "temporalV3ScheduleGameClockMsByEngine": "legacy name for post-#start capture-clock schedules; not game time",
            },
            "sourceVideo": "video recording starts at newPage, before the report capture clock begins",
        },
        "captureOffsetDefinition": "Approximate source PTS = encoded video duration minus the final samples.ms value, then add the report capture-clock timestamp. Recorder tail after the final sample is not measured; residual timing uncertainty is unquantified.",
        "alignmentQuality": "approximate/descriptive only; first-touch-referenced clips are not perfectly synchronized",
        "alignmentCaveat": "PR10 is side-view with held steering; PR13 and V3 are rear-view with one-lane steering. The report clock begins after #start while video begins at newPage. Every capture offset derived from duration minus final RAF sample is approximate, with unquantified recorder-tail uncertainty; no exact game-time or perfect synchronization claim is made.",
        "comparisonFrameGameClockMs": list(FRAME_TIMES_MS),
        "comparisonFrameCaptureClockMs": list(FRAME_TIMES_MS),
        "temporalV3ScheduleGameClockMsByEngine": {
            engine: comparison_descriptors[(engine, "V3")]["temporalScheduleMs"]
            for engine in ENGINES
        },
        "temporalV3ScheduleCaptureClockMsByEngine": {
            engine: comparison_descriptors[(engine, "V3")]["temporalScheduleMs"]
            for engine in ENGINES
        },
        "records": frame_records,
        "sources": [
            {
                "engine": engine,
                "variant": variant,
                "sourceReport": {
                    "path": comparison_descriptors[(engine, variant)]["report"].relative_path,
                    "sha256": comparison_descriptors[(engine, variant)]["report"].sha256,
                },
                "video": {
                    "path": comparison_descriptors[(engine, variant)]["source"].relative_path,
                    "sha256": comparison_descriptors[(engine, variant)]["source"].sha256,
                    "bytes": comparison_descriptors[(engine, variant)]["source"].size_bytes,
                    "mime": comparison_descriptors[(engine, variant)]["source"].mime,
                },
                "sourceHash": comparison_source_hash(
                    comparison_descriptors[(engine, variant)]["report"].data,
                    comparison_descriptors[(engine, variant)]["report"].relative_path,
                ),
                "cameraMode": comparison_descriptors[(engine, variant)]["report"].data.get("cameraMode"),
                "firstTouchActualMs": comparison_descriptors[(engine, variant)]["touchMs"],
                "firstTouchCaptureClockMs": comparison_descriptors[(engine, variant)]["alignment"]["firstTouchCaptureClockMs"],
                "captureAlignment": comparison_descriptors[(engine, variant)]["alignment"],
                "encodedDurationSeconds": comparison_descriptors[(engine, variant)]["duration"],
                "alignment": "approximate source PTS = capture offset + report post-#start capture clock; residual recorder-tail uncertainty is unquantified",
                "frames": comparison_descriptors[(engine, variant)]["frames"],
                **({"temporalFrames": comparison_descriptors[(engine, variant)]["temporalFrames"]}
                   if variant == "V3" else {}),
            }
            for engine in ENGINES for variant in VARIANTS
        ],
        "contactSheets": [
            {"path": f"{attempt_frames_rel}/{sheet.name}", "sha256": sha256_file(sheet),
             "bytes": sheet.stat().st_size, "mime": "image/png", "role": role, **metadata}
            for _, sheet, role, metadata in sheet_outputs
        ],
    }
    prov_stage = frame_stage / "provenance.json"
    write_json(prov_stage, comparison_provenance)
    staged_targets.append((prov_stage, REPO_ROOT / f"{attempt_frames_rel}/provenance.json"))

    media_manifest = {
        "schemaVersion": 1,
        "targetGame": TARGET_GAME,
        "workspace": str(WORKSPACE),
        "sourceBuildHash": build_hash,
        "attempt": attempt,
        "sourceReceipt": {
            "path": repo_relative(RUN_ROOT / "build-receipt.json"),
            "sha256": sha256_file(RUN_ROOT / "build-receipt.json"),
        },
        "timing": {
            "reportClock": "actions.actualMs and samples.ms are capture wall-clock elapsed after #start, not game elapsed time",
            "sourceVideoStart": "newPage, before the report capture clock starts",
            "sourcePtsMapping": "approximate: encoded duration minus last RAF capture-clock sample, plus the report capture-clock timestamp",
            "residualUncertainty": "recorder tail after the final RAF sample is unquantified; first-touch triptychs are approximate/descriptive, not perfectly synchronized",
        },
        "tooling": {
            "python": str(PYTHON),
            "pillow": Image.__version__ if hasattr(Image, "__version__") else "bundled Pillow",
            "ffmpeg": str(FFMPEG),
            "ffmpegSha256": sha256_file(FFMPEG),
        },
        "rules": {
            "inputReportsMustMatchCurrentBuild": True,
            "priorAttemptFallbackAllowed": False,
            "maxFileBytes": MAX_FILE_BYTES,
            "preserveOriginalVideos": True,
            "copyPublicPngBytesOnly": True,
            "gameplayFrameTransformations": "none",
        },
        "media": media_records,
        "comparisonProvenancePath": f"{attempt_frames_rel}/provenance.json",
    }
    media_manifest_run = run_media_stage / "media-manifest.json"
    media_manifest_docs = docs_stage / "media-manifest.json"
    write_json(media_manifest_run, media_manifest)
    write_json(media_manifest_docs, media_manifest)
    staged_targets.extend([
        (media_manifest_run, REPO_ROOT / f"{attempt_media_rel}/media-manifest.json"),
        (media_manifest_docs, REPO_ROOT / f"{docs_rel}/media-manifest.json"),
    ])
    return staged_targets, {"comparison": comparison_provenance, "media": media_manifest}


def publish(staged_targets: list[tuple[Path, Path]]) -> None:
    # Check all collisions before creating any destination directories.
    for staged, destination in staged_targets:
        if not staged.is_file():
            raise MediaError(f"staged file missing before publish: {staged}")
        if staged.stat().st_size > MAX_FILE_BYTES:
            raise MediaError(f"output exceeds 90 MiB: {staged}")
        if destination.exists() and sha256_file(destination) != sha256_file(staged):
            raise MediaError(f"refusing to replace a different existing output: {destination}")
    for staged, destination in staged_targets:
        if destination.exists():
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(staged, destination)
        if sha256_file(destination) != sha256_file(staged):
            raise MediaError(f"published file hash mismatch: {destination}")


def validate_published_frames(
    records: list[dict[str, Any]], *, attempt: int, build_hash: str
) -> dict[str, int]:
    """Confirm every expected raw frame exists at its manifest path and matches bytes."""
    expected_prefix = (
        f"runs/pelican-coast-v2-20261014/attempts/attempt-{attempt}/comparison-frames/"
    )
    expected_paths = {
        f"{expected_prefix}{engine}-{variant}-{time_ms:04d}.png"
        for engine in ENGINES for variant in VARIANTS for time_ms in FRAME_TIMES_MS
    }
    expected_paths.update(
        f"{expected_prefix}{engine}-V3-temporal-{index:02d}.png"
        for engine in ENGINES for index in range(TEMPORAL_COUNT)
    )
    if len(records) != len(expected_paths):
        raise MediaError(
            f"comparison provenance has {len(records)} frames; expected {len(expected_paths)}"
        )

    observed: set[str] = set()
    failures: list[str] = []
    for record in records:
        frame = record.get("frame")
        if not isinstance(frame, dict):
            failures.append("frame record missing nested frame object")
            continue
        relative = frame.get("path")
        if not isinstance(relative, str) or relative not in expected_paths:
            failures.append(f"unexpected frame manifest path: {relative!r}")
            continue
        if relative in observed:
            failures.append(f"duplicate frame manifest path: {relative}")
            continue
        observed.add(relative)
        if (
            record.get("targetGame") != TARGET_GAME
            or record.get("workspace") != str(WORKSPACE)
            or record.get("sourceBuildHash") != build_hash
        ):
            failures.append(f"frame identity/build binding mismatch: {relative}")
            continue
        if frame.get("mime") != "image/png":
            failures.append(f"frame MIME mismatch: {relative}")
            continue
        try:
            destination = resolve_run_artifact_path(relative)
        except MediaError as exc:
            failures.append(str(exc))
            continue
        if not destination.is_file():
            failures.append(f"published frame is missing: {relative}")
            continue
        expected_size = frame.get("bytes")
        if not isinstance(expected_size, int) or destination.stat().st_size != expected_size:
            failures.append(f"published frame size mismatch: {relative}")
            continue
        expected_hash = frame.get("sha256")
        if not isinstance(expected_hash, str) or sha256_file(destination) != expected_hash:
            failures.append(f"published frame SHA-256 mismatch: {relative}")

    missing_records = expected_paths - observed
    if missing_records:
        failures.append(f"{len(missing_records)} expected frame paths are absent from provenance")
    if failures:
        preview = "; ".join(failures[:8])
        suffix = f"; and {len(failures) - 8} more" if len(failures) > 8 else ""
        raise MediaError(f"post-publish frame verification failed: {preview}{suffix}")
    return {"expected": len(expected_paths), "validated": len(observed)}


def main() -> int:
    try:
        reports, receipt, attempt, build_hash = preflight_reports()
        # Confirm fixed workspace identity before staging any output.
        if not WORKSPACE.is_dir() or repo_relative(WORKSPACE) != "runs/pelican-coast-v2-20261014/workspace":
            raise MediaError("authorized target workspace path does not match repository state")
        with tempfile.TemporaryDirectory(prefix="pelican-v3-media-") as tmp:
            staged_targets, manifests = stage_outputs(
                reports, receipt, attempt, build_hash, Path(tmp)
            )
            publish(staged_targets)
            frame_validation = validate_published_frames(
                manifests["comparison"]["records"], attempt=attempt, build_hash=build_hash
            )
        print(json.dumps({
            "status": "generated",
            "targetGame": TARGET_GAME,
            "workspace": str(WORKSPACE),
            "attempt": attempt,
            "buildHash": build_hash,
            "outputFiles": len(staged_targets),
            "comparisonFrameCount": len(manifests["comparison"]["records"]),
            "publishedFrameValidation": frame_validation,
            "mediaCount": len(manifests["media"]["media"]),
            "comparisonManifest": f"runs/pelican-coast-v2-20261014/attempts/attempt-{attempt}/comparison-frames/provenance.json",
            "keyMediaManifest": f"runs/pelican-coast-v2-20261014/attempts/attempt-{attempt}/key-media/media-manifest.json",
            "docsMediaManifest": "docs/lean-pilot/pelican-feel-v3-20261014/evidence-media/media-manifest.json",
        }, ensure_ascii=False, indent=2))
        return 0
    except MediaError as exc:
        print(json.dumps({"status": "blocked", "reason": str(exc)}, ensure_ascii=False, indent=2), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
