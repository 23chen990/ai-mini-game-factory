#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const REPO = '/Users/kker/.codex/worktrees/pelican-feel-v3/妖怪夜市';
const RUN_REL = 'runs/pelican-coast-v2-20261014';
const RUN = path.join(REPO, RUN_REL);
const SCRATCH = '/Users/kker/.codex/pelican-v3-continuation/experience';
const OUT_DIR = path.join(SCRATCH, 'updated-audit');
const INPUT = path.join(SCRATCH, 'pelican-attempt20-experience-audit2.json');
const OUTPUT = path.join(OUT_DIR, 'pelican-attempt20-experience-audit3.json');
const VALIDATION = path.join(OUT_DIR, 'pelican-attempt20-experience-audit3.validation.json');
const HASH = /^[0-9a-f]{64}$/u;
const BUILD_HASH = '3fd08a0a3a4b4f4a9fa644d6984a896e0114411d21952adbc5dc47999e9408c1';
const WORKSPACE = `${REPO}/${RUN_REL}/workspace`;
const sha = (bytes) => crypto.createHash('sha256').update(bytes).digest('hex');
const fileSha = (file) => sha(fs.readFileSync(file));
const repoPath = (relative) => path.join(REPO, relative);
const absRun = (relative) => path.join(RUN, relative);
const relRun = (relative) => `${RUN_REL}/${relative}`;
const requireFile = (file, label) => {
  if (!fs.existsSync(file)) throw new Error(`${label} is missing or not a regular file: ${file}`);
  const stat = fs.lstatSync(file);
  if (stat.isSymbolicLink() || !stat.isFile()) throw new Error(`${label} is missing or not a regular file: ${file}`);
  return file;
};
const readJson = (file, label) => {
  requireFile(file, label);
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch (error) { throw new Error(`${label} is invalid JSON: ${error.message}`); }
};
fs.mkdirSync(OUT_DIR, { recursive: true });
const report = readJson(INPUT, 'audit2 input');
const originalAudit2Sha = fileSha(INPUT);
if (report.schemaVersion !== 2 || report.attempt !== 20 || report.buildHash !== BUILD_HASH) throw new Error('audit2 input identity mismatch');

const buildReceiptPath = absRun('build-receipt.json');
const buildReceipt = readJson(buildReceiptPath, 'attempt20 build receipt');
if (buildReceipt.attempt !== 20 || buildReceipt.workspace !== WORKSPACE || buildReceipt.buildHash !== BUILD_HASH) throw new Error('attempt20 build receipt identity mismatch');

const summaryPath = absRun('qa-summary-v3.json');
const qaSummary = readJson(summaryPath, 'current attempt20 QA summary snapshot');
if (qaSummary.targetGame !== '鹈鹕海岸冒险' || qaSummary.workspace !== WORKSPACE || qaSummary.attempt !== 20 || qaSummary.buildHash !== BUILD_HASH) throw new Error('attempt20 QA summary identity mismatch');

const provenanceRel = 'attempts/attempt-20/comparison-frames/provenance.json';
const provenancePath = absRun(provenanceRel);
const provenance = readJson(provenancePath, 'attempt20 comparison frame provenance');
if (provenance.targetGame !== '鹈鹕海岸冒险' || provenance.workspace !== WORKSPACE || provenance.attempt !== 20 || provenance.sourceBuildHash !== BUILD_HASH) throw new Error('attempt20 comparison provenance identity mismatch');
if (provenance.records?.length !== 120) throw new Error(`Expected 120 provenance frame records, got ${provenance.records?.length ?? 0}`);

const originalArchiveMapRel = 'evidence/attempt20-capture-binding-first-failed/path-map.json';
const originalArchiveMapPath = absRun(originalArchiveMapRel);
const originalArchiveMap = readJson(originalArchiveMapPath, 'initial capture binding path map');
if (originalArchiveMap.targetGame !== '鹈鹕海岸冒险' || originalArchiveMap.workspace !== WORKSPACE || originalArchiveMap.buildHash !== BUILD_HASH) throw new Error('initial capture binding path map identity mismatch');

const timeoutArchiveRel = 'evidence/attempt20-capture-isolation-reload-timeout';
const timeoutMapRel = `${timeoutArchiveRel}/path-map.json`;
const timeoutMapPath = absRun(`${timeoutArchiveRel}/path-map.json`);
const timeoutMap = readJson(timeoutMapPath, 'local reload-timeout path map');
if (timeoutMap.targetGame !== '鹈鹕海岸冒险' || timeoutMap.workspace !== WORKSPACE || timeoutMap.buildHash !== BUILD_HASH) throw new Error('local reload-timeout path map identity mismatch');
const expectedTimeoutMoves = new Map(['webkit', 'chromium'].map((engine) => [`attempts/attempt-20/qa-all-${engine}`, `${timeoutArchiveRel}/qa-all-${engine}`]));
const recordedTimeoutMoves = new Map((timeoutMap.moved ?? []).map((entry) => [entry.from, entry.to]));
if (recordedTimeoutMoves.size !== expectedTimeoutMoves.size || [...expectedTimeoutMoves].some(([from, to]) => recordedTimeoutMoves.get(from) !== to)) throw new Error('local reload-timeout path map does not bind the exact archived engine directories');

const archiveDirectory = 'evidence/attempt20-capture-binding-first-failed';
const mappings = [
  ['attempts/attempt-20/qa-campaign-webkit/report.json', `${archiveDirectory}/qa-campaign-webkit/report.json`, 'archived attempt20 campaign WebKit report; historical diagnostic only; its L3 screenshot binding is invalid'],
  ['attempts/attempt-20/qa-campaign-chromium/report.json', `${archiveDirectory}/qa-campaign-chromium/report.json`, 'archived attempt20 campaign Chromium report; historical diagnostic only; its L3 screenshot binding is invalid'],
  ['attempts/attempt-20/qa-all-webkit/report.json', `${archiveDirectory}/qa-all-webkit/report.json`, 'archived initial attempt20 broad QA WebKit report; historical diagnostic only; not the latest exact-path retest'],
  ['attempts/attempt-20/qa-all-chromium/report.json', `${archiveDirectory}/qa-all-chromium/report.json`, 'archived initial attempt20 broad QA Chromium report; historical diagnostic only; not the latest exact-path retest'],
  ['attempts/attempt-20/qa-all-webkit/level-4-hazard.png', `${archiveDirectory}/qa-all-webkit/level-4-hazard.png`, 'archived attempt20 WebKit rain screenshot; descriptive historical diagnostic only, not a current QA pass'],
  ['attempts/attempt-20/qa-all-webkit/level-4-terminal.png', `${archiveDirectory}/qa-all-webkit/level-4-terminal.png`, 'archived attempt20 WebKit L4 terminal screenshot; descriptive historical diagnostic only, not a current QA pass'],
  ['attempts/attempt-20/qa-all-webkit/level-5-hazard.png', `${archiveDirectory}/qa-all-webkit/level-5-hazard.png`, 'archived attempt20 WebKit dusk screenshot; descriptive historical diagnostic only, not a current QA pass'],
  ['attempts/attempt-20/qa-all-webkit/level-5-terminal.png', `${archiveDirectory}/qa-all-webkit/level-5-terminal.png`, 'archived attempt20 WebKit L5 terminal screenshot; descriptive historical diagnostic only, not a current QA pass'],
];
const expectedArchiveMoves = new Map((originalArchiveMap.moved ?? []).map((entry) => [entry.originalRunPath, entry.preservedRunPath]));
const mappedSources = [];
for (const [oldRunPath, archivedRunPath, role] of mappings) {
  const move = [...expectedArchiveMoves.entries()].sort((a, b) => b[0].length - a[0].length).find(([originalPrefix]) => oldRunPath === originalPrefix || oldRunPath.startsWith(`${originalPrefix}/`));
  const expectedArchivedPath = move ? `${move[1]}${oldRunPath.slice(move[0].length)}` : null;
  if (expectedArchivedPath !== archivedRunPath) throw new Error(`Archive map does not authorize expected path mapping: ${oldRunPath}`);
  const oldAbs = absRun(oldRunPath);
  const archiveAbs = absRun(archivedRunPath);
  const item = report.sourceArtifacts.find((source) => source.path === oldAbs);
  if (!item) throw new Error(`audit2 source artifact missing for archived QA family path: ${oldAbs}`);
  requireFile(archiveAbs, 'archived QA family artifact');
  const archivedHash = fileSha(archiveAbs);
  if (archivedHash !== item.sha256) throw new Error(`Archived QA artifact SHA changed for ${oldRunPath}: expected ${item.sha256}, got ${archivedHash}`);
  item.path = archiveAbs;
  item.role = role;
  mappedSources.push({ originalPath: oldAbs, archivedPath: archiveAbs, sha256: archivedHash, role });
}

const engineCaptureBindings = [];
const overwrittenPngs = [];
for (const engine of ['webkit', 'chromium']) {
  const campaignRunPath = `${archiveDirectory}/qa-campaign-${engine}/report.json`;
  const allRunPath = `${archiveDirectory}/qa-all-${engine}/report.json`;
  const campaignPath = absRun(`evidence/attempt20-capture-binding-first-failed/qa-campaign-${engine}/report.json`);
  const allPath = absRun(`evidence/attempt20-capture-binding-first-failed/qa-all-${engine}/report.json`);
  const campaign = readJson(campaignPath, `archived campaign ${engine} report`);
  const all = readJson(allPath, `archived broad QA ${engine} report`);
  const expectedPngPath = `attempts/attempt-20/qa-all-${engine}/level-3-hazard.png`;
  const screenshotRecord = campaign.screenshots?.find((entry) => entry.path === expectedPngPath);
  if (!screenshotRecord || !HASH.test(screenshotRecord.sha256 ?? '')) throw new Error(`Archived ${engine} campaign report has no exact L3 hazard screenshot SHA`);
  const replacementRel = `evidence/attempt20-capture-binding-first-failed/qa-all-${engine}/level-3-hazard.png`;
  const replacementPath = absRun(replacementRel);
  requireFile(replacementPath, `archived ${engine} replacement screenshot`);
  const replacementHash = fileSha(replacementPath);
  if (replacementHash === screenshotRecord.sha256) throw new Error(`Expected known overwritten L3 screenshot mismatch for ${engine}, but the hashes unexpectedly match`);
  overwrittenPngs.push({ engine, path: replacementPath, sha256: replacementHash, role: `overwritten ${engine} safety capture retained only to diagnose the L3 screenshot mismatch; not usable as the original QA capture` });
  engineCaptureBindings.push({
    engine,
    archivedCampaignReport: { path: campaignPath, sha256: fileSha(campaignPath), reportPassed: campaign.passed === true },
    archivedBroadQaReport: { path: allPath, sha256: fileSha(allPath), reportPassed: all.passed === true },
    expectedScreenshot: { runRelativePath: expectedPngPath, expectedSha256: screenshotRecord.sha256, originalBytesStatus: 'UNAVAILABLE_OVERWRITTEN', usableAsEvidence: false },
    archivedReplacementScreenshot: { path: replacementPath, sha256: replacementHash, usableAsEvidence: false },
  });
}

const localRetestEngines = [];
for (const engine of ['webkit', 'chromium']) {
  const reportRel = `${timeoutArchiveRel}/qa-all-${engine}/report.json`;
  const driverProvenanceRel = `${timeoutArchiveRel}/qa-all-${engine}/driver-provenance.json`;
  const driverSourceRel = `${timeoutArchiveRel}/qa-all-${engine}/driver-source.mjs`;
  const reportPath = absRun(reportRel);
  const driverProvenancePath = absRun(driverProvenanceRel);
  const driverSourcePath = absRun(driverSourceRel);
  const qa = readJson(reportPath, `previous archived local ${engine} qa-all reload-timeout run`);
  const driverProvenance = readJson(driverProvenancePath, `latest local ${engine} QA driver provenance`);
  if (qa.targetGame !== '鹈鹕海岸冒险' || qa.workspace !== WORKSPACE || qa.attempt !== 20 || qa.buildHash !== BUILD_HASH || qa.mode !== 'all' || qa.normalInputOnly !== true || qa.stateInjection !== false) throw new Error(`Archived prior ${engine} QA run identity/input mismatch`);
  if (qa.passed !== false || !Array.isArray(qa.errors) || !qa.errors.some((error) => /page\.reload: Timeout 30000ms exceeded/iu.test(error))) throw new Error(`Archived prior ${engine} QA run no longer matches the recorded reload-timeout outcome`);
  const checkMap = new Map((qa.checks ?? []).map((check) => [check.name, check]));
  const levelChecks = [];
  for (let stage = 1; stage <= 5; stage += 1) {
    for (const prefix of ['natural-level', 'no-full-page-reload-level']) {
      const name = `${prefix}-${stage}`;
      const check = checkMap.get(name);
      if (check?.passed !== true) throw new Error(`Archived prior ${engine} QA run does not prove ${name}`);
      levelChecks.push(name);
    }
  }
  for (const required of ['locked-new-save', 'pause-freezes-world-and-timer', 'in-memory-replay']) {
    if (checkMap.get(required)?.passed !== true) throw new Error(`Archived prior ${engine} QA run does not prove ${required}`);
  }
  if (driverProvenance.buildHash !== BUILD_HASH || driverProvenance.normalInputOnly !== true || driverProvenance.sha256 !== fileSha(driverSourcePath)) throw new Error(`Latest local ${engine} QA driver provenance mismatch`);
  localRetestEngines.push({
    engine,
    report: { path: reportPath, sha256: fileSha(reportPath), passed: qa.passed, checkCount: qa.checks.length, passedCheckCount: qa.checks.filter((check) => check.passed === true).length, failedCheckCount: qa.checks.filter((check) => check.passed !== true).length, normalInputOnly: qa.normalInputOnly, stateInjection: qa.stateInjection, levelChecks },
    driverProvenance: { path: driverProvenancePath, sha256: fileSha(driverProvenancePath), driverSourcePath, driverSourceSha256: fileSha(driverSourcePath), buildHash: driverProvenance.buildHash },
    errors: qa.errors,
    disposition: 'HISTORICAL PRE-RERUN FAILURE: five level journeys and in-memory replay passed, but page.reload waited for load and timed out after 30000 ms; superseded by the exact-path current QA report recorded separately.',
  });
}

const currentBroadQaEngines = [];
const currentBroadQaScreenshotBindings = [];
const currentBroadScreenshotPaths = new Map();
const expectedCampaignChecks = [
  'locked-new-save', 'first-seconds-objective-and-fish', 'renderer-composer-resolution', 'pause-freezes-world-and-timer',
  ...Array.from({ length: 5 }, (_, index) => [`natural-level-${index + 1}`, `no-full-page-reload-level-${index + 1}`]).flat(),
  'unintegrated-ad-honest-no-block', 'in-memory-replay', 'refresh-keeps-five-unlocked', 'restored-selected-level-label',
];
const expectedCollisionChecks = [
  'accident-visible-before-settlement', 'car-ends-round', 'crash-freezes-score', 'failure-replay-without-navigation',
  'pedestrian-stops-but-countdown-runs', 'pedestrian-recovers-once', 'visible-barrier-jump-clears', 'authored-barrier-prize-caught', 'one-touch-one-lane',
];
const expectedSafetyChecks = [
  'van-target-distance-reached', 'van-ends-round', 'car-not-jumpable', 'distance-and-fish-jointly-required',
  'tab-blur-pauses', 'background-manual-resume', 'replay-resources-plateau',
];
const expectedBackgroundFailures = ['background-manual-resume', 'tab-blur-pauses'];
for (const engine of ['webkit', 'chromium']) {
  const reportRel = `attempts/attempt-20/qa-all-${engine}/report.json`;
  const reportPath = absRun(reportRel);
  const qa = readJson(reportPath, `current exact-path ${engine} qa-all report`);
  if (qa.targetGame !== '鹈鹕海岸冒险' || qa.workspace !== WORKSPACE || qa.attempt !== 20 || qa.buildHash !== BUILD_HASH || qa.mode !== 'all' || qa.normalInputOnly !== true || qa.stateInjection !== false) throw new Error(`Current exact-path ${engine} QA identity/input mismatch`);
  if (qa.passed !== false || !Array.isArray(qa.errors) || qa.errors.length !== 0 || !Array.isArray(qa.checks) || qa.checks.length !== 34) throw new Error(`Current exact-path ${engine} QA report status/check count is unexpected`);
  const checkMap = new Map(qa.checks.map((check) => [check.name, check]));
  if (checkMap.size !== qa.checks.length) throw new Error(`Current exact-path ${engine} QA has duplicate check names`);
  const names = qa.checks.map((check) => check.name);
  if (JSON.stringify(names.slice(0, 18)) !== JSON.stringify(expectedCampaignChecks) || JSON.stringify(names.slice(18, 27)) !== JSON.stringify(expectedCollisionChecks) || JSON.stringify(names.slice(27)) !== JSON.stringify(expectedSafetyChecks)) throw new Error(`Current exact-path ${engine} QA campaign/collision/safety check groups are incomplete or reordered`);
  const failures = qa.checks.filter((check) => check.passed !== true).map((check) => check.name).sort();
  if (JSON.stringify(failures) !== JSON.stringify(expectedBackgroundFailures)) throw new Error(`Current exact-path ${engine} QA has unexpected failures: ${failures.join(', ')}`);
  for (const check of qa.checks) {
    if (check.passed !== true && !expectedBackgroundFailures.includes(check.name)) throw new Error(`Current exact-path ${engine} QA required check failed: ${check.name}`);
  }
  if (!Array.isArray(qa.levels) || qa.levels.length !== 5) throw new Error(`Current exact-path ${engine} QA lacks five natural campaign settlements`);
  const levelEvidence = qa.levels.map((level, index) => {
    if (level.level !== index + 1 || level.reason !== 'complete' || level.jumpedBarriers !== 0 || level.save?.completed?.[index] !== true || level.save?.unlocked < Math.min(index + 2, 5)) throw new Error(`Current exact-path ${engine} no-jump campaign settlement is invalid for level ${index + 1}`);
    return { level: level.level, reason: level.reason, fish: level.count, gold: level.gold, jumps: level.jumpedBarriers, elapsedSeconds: level.elapsed, earned: level.save.completed[index] === true, unlockedThrough: level.save.unlocked };
  });
  if (!Array.isArray(qa.screenshots) || qa.screenshots.length !== 36) throw new Error(`Current exact-path ${engine} QA must bind exactly 36 nested screenshots`);
  const screenshots = [];
  for (const screenshot of qa.screenshots) {
    const rel = screenshot.path;
    const expectedPrefix = `attempts/attempt-20/qa-all-${engine}/`;
    if (typeof rel !== 'string' || path.isAbsolute(rel) || rel.includes('..') || !rel.startsWith(expectedPrefix) || path.extname(rel) !== '.png' || !HASH.test(screenshot.sha256 ?? '')) throw new Error(`Current exact-path ${engine} QA screenshot path/hash is invalid: ${rel}`);
    const runPath = absRun(rel);
    requireFile(runPath, `current exact-path ${engine} QA screenshot`);
    const actual = fileSha(runPath);
    if (actual !== screenshot.sha256 || currentBroadScreenshotPaths.has(rel)) throw new Error(`Current exact-path ${engine} QA screenshot is mismatched or reused: ${rel}`);
    currentBroadScreenshotPaths.set(rel, actual);
    const binding = { path: relRun(rel), sha256: actual, engine };
    screenshots.push(binding);
    currentBroadQaScreenshotBindings.push(binding);
  }
  currentBroadQaEngines.push({
    engine,
    report: { path: reportPath, sha256: fileSha(reportPath), passed: qa.passed, checkCount: qa.checks.length, passedCheckCount: qa.checks.filter((check) => check.passed === true).length, failedCheckCount: failures.length, normalInputOnly: qa.normalInputOnly, stateInjection: qa.stateInjection, campaignChecks: 18, campaignPassed: 18, collisionChecks: 9, collisionPassed: 9, safetyChecks: 7, safetyPassed: 5, errors: qa.errors, screenshotCount: screenshots.length, levelSettlements: levelEvidence },
    failedChecks: failures,
    screenshots,
    disposition: 'BOUNDED_ENVIRONMENT_BLOCKED: all 18 campaign checks and nine collision checks pass with five earned levels; 32/34 checks pass and the only two false checks are desktop background signals, classified by the paired lifecycle/safety capability evidence. This is not a global QA PASS or a production claim.',
  });
}
if (currentBroadQaEngines.length !== 2 || currentBroadQaScreenshotBindings.length !== 72 || currentBroadScreenshotPaths.size !== 72) throw new Error('Current exact-path QA must bind both engines and 72 unique screenshots');
const latestBroadQaFinishedAt = Math.max(...currentBroadQaEngines.map((entry) => Date.parse(readJson(entry.report.path, `current ${entry.engine} QA report snapshot`).finishedAt)));
if (!Number.isFinite(latestBroadQaFinishedAt) || !Number.isFinite(Date.parse(qaSummary.createdAt)) || Date.parse(qaSummary.createdAt) < latestBroadQaFinishedAt) throw new Error('Current QA summary has not yet been refreshed after the exact-path broad QA reports');
if (qaSummary.scriptedCoreJourneyPassed !== true || qaSummary.desktopBrowserEvidencePassed !== true || qaSummary.lifecycleSupportedChecksPassed !== true || qaSummary.desktopBackgroundEvidence !== 'BLOCKED_ENVIRONMENT_SIGNAL_UNAVAILABLE' || qaSummary.independentPerceptualPassed !== true || qaSummary.runtimeProductJourneyPassed !== true || qaSummary.readiness?.h5DevicePlaytestCandidate !== true || qaSummary.releaseReady !== false || qaSummary.productionReady !== false) throw new Error('Current finalized summary does not preserve the bounded H5 candidate / environment-blocked desktop lifecycle / production-blocked split');
const lifecycleRows = qaSummary.reports?.filter((entry) => entry.kind === 'lifecycle') ?? [];
if (lifecycleRows.length !== 1 || lifecycleRows[0].engine !== 'webkit+chromium' || lifecycleRows[0].status !== 'BLOCKED' || lifecycleRows[0].path !== 'attempts/attempt-20/lifecycle/report.json') throw new Error('Finalized QA summary lacks the exact current bounded lifecycle classification');
const lifecyclePath = absRun(lifecycleRows[0].path);
const lifecycle = readJson(lifecyclePath, 'current lifecycle capability report');
if (fileSha(lifecyclePath) !== lifecycleRows[0].sha256 || lifecycle.targetGame !== '鹈鹕海岸冒险' || lifecycle.workspace !== WORKSPACE || (lifecycle.attempt !== undefined && lifecycle.attempt !== 20) || lifecycle.buildHash !== BUILD_HASH || !Array.isArray(lifecycle.errors) || lifecycle.errors.length !== 0) throw new Error('Current lifecycle report identity, SHA, or errors mismatch');
const expectedSupportedLifecycleChecks = ['portrait-to-landscape-live-resize', 'all-quality-presets-keep-composer-size', 'offline-single-html-normal-touch-catch', 'engineering-context-loss-pauses', 'engineering-context-restored-manual-resume'];
const expectedBlockedLifecycleChecks = ['actual-window-background-pauses', 'background-countdown-stays-paused', 'background-requires-manual-resume'];
const lifecycleCheckMap = new Map((lifecycle.checks ?? []).map((check) => [check.name, check]));
if (lifecycle.passed !== false || lifecycle.checks?.length !== 8 || lifecycleCheckMap.size !== 8 || expectedSupportedLifecycleChecks.some((name) => lifecycleCheckMap.get(name)?.passed !== true) || expectedBlockedLifecycleChecks.some((name) => lifecycleCheckMap.get(name)?.passed === true) || JSON.stringify(lifecycle.checks.filter((check) => check.passed !== true).map((check) => check.name).sort()) !== JSON.stringify([...expectedBlockedLifecycleChecks].sort())) throw new Error('Current lifecycle supported checks/background capability checks are incomplete or the blocked outcomes are overstated');
const lifecycleDiagnostics = new Map((lifecycle.diagnostics ?? []).map((diagnostic) => [diagnostic.name, diagnostic]));
for (const engine of ['webkit', 'chromium']) {
  const diagnostic = lifecycleDiagnostics.get(`headless-${engine}-tab-capability`);
  if (diagnostic?.classification !== 'NO_BACKGROUND_SIGNAL_FROM_HEADLESS_TABS' || !Array.isArray(diagnostic.observation?.away?.events) || diagnostic.observation.away.events.length !== 0 || diagnostic.observation?.away?.visibility !== 'visible' || diagnostic.observation?.away?.focus !== true) throw new Error(`Current lifecycle/${engine} does not prove the bounded no-background-signal classification`);
}
for (const kind of ['campaign', 'collision']) {
  for (const engine of ['webkit', 'chromium']) {
    const rows = qaSummary.reports?.filter((entry) => entry.kind === kind && entry.engine === engine) ?? [];
    if (rows.length !== 1 || rows[0].status !== 'PASS' || !rows[0].path.startsWith('attempts/attempt-20/')) throw new Error(`Current finalized summary lacks exactly one passing ${kind}/${engine} report`);
    const boundPath = absRun(rows[0].path);
    if (fileSha(boundPath) !== rows[0].sha256) throw new Error(`Current finalized ${kind}/${engine} report SHA mismatch`);
    const boundReport = readJson(boundPath, `finalized ${kind}/${engine} report`);
    if (boundReport.passed !== true) throw new Error(`Finalized ${kind}/${engine} report is not passing`);
  }
}
const currentSafetyRows = qaSummary.reports?.filter((entry) => entry.kind === 'safety') ?? [];
if (currentSafetyRows.length !== 2) throw new Error('Finalized QA summary must retain both bounded safety classifications');
const currentSafetyReportBindings = [];
for (const engine of ['webkit', 'chromium']) {
  const row = currentSafetyRows.find((entry) => entry.engine === engine);
  const environment = row?.classification?.environmentalEvidence;
  if (row?.status !== 'BLOCKED' || row.classification?.supportedChecksPassed !== true || JSON.stringify([...(row.classification.environmentBlockedChecks ?? [])].sort()) !== JSON.stringify(expectedBackgroundFailures) || environment?.passed !== true || environment.classification !== 'NO_BACKGROUND_SIGNAL_FROM_HEADLESS_TABS') throw new Error(`Finalized safety/${engine} does not preserve the exact supported-check/environment limitation classification`);
  const expectedSafetyCheckResults = [...expectedSafetyChecks.map((name) => ({ name, status: expectedBackgroundFailures.includes(name) ? 'BLOCKED' : 'PASS' }))];
  const checkResults = row.classification.checkResults ?? [];
  if (checkResults.length !== expectedSafetyCheckResults.length || expectedSafetyCheckResults.some((expected) => !checkResults.some((actual) => actual.name === expected.name && actual.status === expected.status))) throw new Error(`Finalized safety/${engine} classification lacks exact supported/background check outcomes`);
  const expectedSafetyPath = `attempts/attempt-20/qa-safety-${engine}/report.json`;
  if (row.path !== expectedSafetyPath || !HASH.test(row.sha256 ?? '')) throw new Error(`Finalized safety/${engine} does not bind its exact current safety report`);
  const safetyPath = absRun(expectedSafetyPath);
  const safety = readJson(safetyPath, `current safety/${engine} report`);
  if (fileSha(safetyPath) !== row.sha256 || safety.targetGame !== '鹈鹕海岸冒险' || safety.workspace !== WORKSPACE || safety.attempt !== 20 || safety.buildHash !== BUILD_HASH || safety.mode !== 'safety' || safety.normalInputOnly !== true || safety.stateInjection !== false || safety.passed !== false || !Array.isArray(safety.errors) || safety.errors.length !== 0) throw new Error(`Current safety/${engine} report identity, SHA, or bounded status mismatch`);
  const safetyCheckMap = new Map((safety.checks ?? []).map((check) => [check.name, check]));
  if (safety.checks?.length !== 7 || safetyCheckMap.size !== 7 || expectedSafetyChecks.some((name) => safetyCheckMap.has(name) !== true) || expectedSafetyChecks.some((name) => safetyCheckMap.get(name)?.passed !== !expectedBackgroundFailures.includes(name))) throw new Error(`Current safety/${engine} raw check outcomes disagree with the bounded summary classification`);
  if (!Array.isArray(safety.screenshots) || safety.screenshots.length !== 7) throw new Error(`Current safety/${engine} screenshots are incomplete`);
  const safetyScreenshots = [];
  for (const screenshot of safety.screenshots) {
    if (currentBroadScreenshotPaths.get(screenshot.path) !== screenshot.sha256) throw new Error(`Current safety/${engine} screenshot is not hash-bound by the exact current broad QA capture: ${screenshot.path}`);
    safetyScreenshots.push({ path: relRun(screenshot.path), sha256: screenshot.sha256 });
  }
  currentSafetyReportBindings.push({ engine, path: safetyPath, sha256: row.sha256, passed: safety.passed, checkCount: safety.checks.length, passedCheckCount: safety.checks.filter((check) => check.passed === true).length, failedCheckCount: safety.checks.filter((check) => check.passed !== true).length, errors: safety.errors, screenshots: safetyScreenshots });
}

const frameBindings = [];
const uniqueFramePaths = new Set();
const perEngineVariantCounts = {};
for (const engine of ['webkit', 'chromium']) {
  const rows = provenance.records.filter((record) => record.engine === engine);
  perEngineVariantCounts[engine] = Object.fromEntries(['PR10', 'PR13', 'V3'].map((variant) => [variant, rows.filter((record) => record.variant === variant).length]));
  if (rows.length !== 60 || perEngineVariantCounts[engine].PR10 !== 6 || perEngineVariantCounts[engine].PR13 !== 6 || perEngineVariantCounts[engine].V3 !== 48) throw new Error(`Current ${engine} provenance must bind 6 PR10, 6 PR13 and 48 V3 source frames`);
}
for (const record of provenance.records) {
  const rel = record.frame?.path;
  if (typeof rel !== 'string' || path.isAbsolute(rel) || rel.includes('..') || !rel.startsWith(`${RUN_REL}/attempts/attempt-20/comparison-frames/`) || path.extname(rel) !== '.png') throw new Error(`Invalid current comparison frame path: ${rel}`);
  if (!HASH.test(record.frame?.sha256 ?? '') || !Number.isInteger(record.frame?.bytes) || record.frame.bytes <= 0 || record.frame.mime !== 'image/png') throw new Error(`Incomplete current comparison frame binding: ${rel}`);
  if (uniqueFramePaths.has(rel)) throw new Error(`Duplicate physical comparison frame path in provenance: ${rel}`);
  uniqueFramePaths.add(rel);
  const full = repoPath(rel);
  requireFile(full, 'provenance-referenced original decoded full frame');
  const bytes = fs.readFileSync(full);
  if (bytes.length !== record.frame.bytes || sha(bytes) !== record.frame.sha256) throw new Error(`Original decoded full frame bytes/SHA mismatch: ${rel}`);
  const captureOffsetMs = Number.isFinite(record.captureOffsetSeconds) ? record.captureOffsetSeconds * 1000 : null;
  frameBindings.push({ path: rel, sha256: record.frame.sha256, bytes: record.frame.bytes, engine: record.engine, variant: record.variant, captureOffsetMs });
}
if (uniqueFramePaths.size !== 120) throw new Error(`Expected 120 unique published decoded PNG frames, got ${uniqueFramePaths.size}`);
if (!/capture wall-clock elapsed/iu.test(provenance.clockDefinition?.reportClock ?? '') || !/not game elapsed/iu.test(provenance.clockDefinition?.reportClock ?? '')) throw new Error('Current comparison provenance must label its capture clock, not game elapsed time');
if (!/approximate/iu.test(provenance.captureOffsetDefinition ?? '') || !/unquantified/iu.test(provenance.alignmentCaveat ?? '') || !/approx/iu.test(provenance.alignmentQuality ?? '')) throw new Error('Current comparison provenance must retain approximate first-touch/source timing and unquantified recorder-tail limits');
if (!/original decoded full frames only/iu.test(provenance.method ?? '') || !/no crop/iu.test(provenance.method ?? '') || !/proportional full-frame reduction/iu.test(provenance.method ?? '')) throw new Error('Current comparison provenance must preserve original full-frame-only/contact-sheet method');

for (const [oldPath, archivedPath, role] of mappings) {
  const oldAbs = absRun(oldPath);
  const archivedAbs = absRun(archivedPath);
  const observation = report.perceptualObservations?.find((item) => item.artifactPath === oldAbs);
  if (observation) {
    observation.artifactPath = archivedAbs;
    observation.evidenceMode = 'archived-historical-diagnostic-not-current-qa-pass';
    observation.limitation = `${observation.limitation ?? ''} 该文件来自已归档的初始 QA capture bundle；L3 hazard 原 PNG 丢失并被另一张 safety 图覆盖，所以本图只能作描述性历史诊断，不能证明当前 QA 门禁通过。`.trim();
    if (!role.includes('descriptive historical diagnostic')) observation.interpretation = `${observation.interpretation ?? ''} 仅保留历史画面观察；不作为当前 QA PASS。`.trim();
  }
}

const audit3Status = 'attempt20_whole_v3_experience_audit_with_fresh_bounded_qa_and_capture_history';
report.auditStatus = audit3Status;
report.scratchReportPath = OUTPUT;
report.sourceArtifacts.forEach((source) => {
  if (source.path === buildReceiptPath) source.role = `attempt20 build receipt; exact build/workspace identity; receipt qa field remains ${buildReceipt.qa ?? 'unspecified'} and is not a QA verdict`;
  if (source.path === summaryPath) source.role = 'finalized attempt20 QA summary snapshot; fresh campaign/collision bindings and bounded desktop background environment limitation are retained; production remains blocked';
  if (source.path === provenancePath) source.role = 'attempt20 current PNG provenance; 120 exact full decoded source frames and four contact sheets verified separately';
});

const currentLifecycleReportBinding = { path: lifecyclePath, sha256: fileSha(lifecyclePath), passed: lifecycle.passed, errors: lifecycle.errors, lifecycleDiagnostics: ['webkit', 'chromium'].map((engine) => ({ engine, classification: lifecycleDiagnostics.get(`headless-${engine}-tab-capability`).classification, events: lifecycleDiagnostics.get(`headless-${engine}-tab-capability`).observation.away.events, visibility: lifecycleDiagnostics.get(`headless-${engine}-tab-capability`).observation.away.visibility, focus: lifecycleDiagnostics.get(`headless-${engine}-tab-capability`).observation.away.focus })) };
const currentSnapshot = {
  targetGame: qaSummary.targetGame,
  workspace: qaSummary.workspace,
  attempt: qaSummary.attempt,
  buildHash: qaSummary.buildHash,
  capturedAt: new Date().toISOString(),
  buildReceipt: { path: buildReceiptPath, sha256: fileSha(buildReceiptPath), qaField: buildReceipt.qa ?? null },
  qaSummary: { path: summaryPath, sha256: fileSha(summaryPath), createdAt: qaSummary.createdAt, scriptedCoreJourneyPassed: qaSummary.scriptedCoreJourneyPassed, desktopBrowserEvidencePassed: qaSummary.desktopBrowserEvidencePassed, lifecycleSupportedChecksPassed: qaSummary.lifecycleSupportedChecksPassed, desktopBackgroundEvidence: qaSummary.desktopBackgroundEvidence, independentPerceptualPassed: qaSummary.independentPerceptualPassed, runtimeProductJourneyPassed: qaSummary.runtimeProductJourneyPassed, h5DevicePlaytestCandidate: qaSummary.readiness?.h5DevicePlaytestCandidate === true, releaseReady: qaSummary.releaseReady, productionReady: qaSummary.productionReady, campaignRows: qaSummary.reports?.filter((item) => item.kind === 'campaign').map((item) => ({ path: item.path, status: item.status, blockers: item.blockers ?? [] })) ?? [], safetyClassifications: currentSafetyRows.map((item) => ({ engine: item.engine, status: item.status, supportedChecksPassed: item.classification?.supportedChecksPassed === true, environmentBlockedChecks: [...(item.classification?.environmentBlockedChecks ?? [])].sort(), environmentalEvidence: item.classification?.environmentalEvidence ?? null })) },
  comparisonFrameProvenance: { path: provenancePath, sha256: fileSha(provenancePath), frameRecordCount: provenance.records.length, uniqueSourceFrameCount: uniqueFramePaths.size, perEngineVariantCounts, contactSheetCount: provenance.contactSheets?.length ?? 0, reportClock: provenance.clockDefinition.reportClock, captureOffsetDefinition: provenance.captureOffsetDefinition, alignmentCaveat: provenance.alignmentCaveat, alignmentQuality: provenance.alignmentQuality, method: provenance.method },
};

const captureBindingIncident = {
  status: 'HISTORICAL_INVALID_CAPTURE_BINDING',
  pathMap: { path: originalArchiveMapPath, sha256: fileSha(originalArchiveMapPath), classification: originalArchiveMap.classification },
  sourceMappings: mappedSources,
  perEngine: engineCaptureBindings,
  unavailability: 'campaign report JSON bytes and SHA-256 values are preserved. The L3 hazard PNG bytes originally expected by those reports are unavailable: a later safety capture overwrote the active path before archive. The archive retains a different safety PNG, whose SHA differs from each preserved expected SHA. Neither the replacement image nor any nearby screenshot is usable as the original L3 evidence.',
};

const localQaRetest = {
  status: 'BOUNDED_ENVIRONMENT_BLOCKED',
  targetGame: '鹈鹕海岸冒险',
  workspace: WORKSPACE,
  attempt: 20,
  buildHash: BUILD_HASH,
  engines: currentBroadQaEngines,
  uniqueScreenshotCount: currentBroadQaScreenshotBindings.length,
  lifecycleReport: { ...currentLifecycleReportBinding, supportedChecksPassed: true },
  safetyReportBindings: currentSafetyReportBindings,
  priorReloadTimeout: { pathMap: { path: timeoutMapPath, sha256: fileSha(timeoutMapPath), classification: timeoutMap.classification }, engines: localRetestEngines },
  disposition: 'Both exact-path normal-input current reports bind the same attempt20 H5 and all 72 nested screenshot hashes. Each reports 32/34 checks with errors=[]; the only false checks are tab-blur-pauses and background-manual-resume. The parent finalizer classifies those as unsupported desktop background signals, while campaign, collision and supported safety checks pass. No global QA PASS or production readiness is claimed.',
};

report.evidenceHistory = {
  currentSnapshot,
  archivedInitialCaptureBundle: captureBindingIncident,
  currentLocalBroadQaEvidence: localQaRetest,
  currentPngFrameBindings: { provenancePath: provenancePath, provenanceSha256: fileSha(provenancePath), frameCount: frameBindings.length, uniqueFrameCount: uniqueFramePaths.size, frames: frameBindings, contactSheets: provenance.contactSheets.map((sheet) => ({ path: sheet.path, sha256: sheet.sha256, bytes: sheet.bytes, mime: sheet.mime, role: sheet.role, engine: sheet.engine })) },
  interpretationBoundary: 'Exact attempt20 experience/risk/head/feel-state/visual/lifecycle artifacts remain separately bound to the unchanged H5 build. The initial campaign capture bundle is historical and has an unavailable overwritten L3 PNG. Fresh current qa-all reports bind 72 verified nested screenshot files, complete all five levels with campaign and collision checks, and contain only the two background checks blocked by absent desktop signals. Their report.passed=false is preserved; no global QA or production PASS is claimed.',
};

for (const concern of report.concerns) {
  if (concern.id === 'five-stage-operation-fishing-rain-night') {
    const note = '设计范围推断：暮色不额外引入与照明无关的独立操作，以避免功能扩张并保留连续骑行的同一操作节奏；这是范围取舍，不是玩家需求或可玩性结论。';
    if (!concern.inferred.includes(note)) concern.inferred.push(note);
  }
}
if (Array.isArray(report.stageComparison?.designNotes)) {
  const note = '暮色不额外引入与照明无关的独立操作，是避免功能扩张、保留连续骑行节奏的设计范围推断；不代表玩家已验证这种取舍。';
  if (!report.stageComparison.designNotes.includes(note)) report.stageComparison.designNotes.push(note);
}

const archivedQaPaths = new Map(mappings.map(([oldPath, newPath]) => [absRun(oldPath), absRun(newPath)]));
for (const blocker of report.blockers ?? []) {
  blocker.evidencePaths = blocker.evidencePaths.map((item) => archivedQaPaths.get(item) ?? item);
}
report.blockers = report.blockers ?? [];
const backgroundBlocker = report.blockers.find((blocker) => blocker.id === 'attempt20-background-pause-signal');
if (backgroundBlocker) backgroundBlocker.evidencePaths = [
  absRun('attempts/attempt-20/lifecycle/report.json'),
  ...currentBroadQaEngines.map((entry) => entry.report.path),
  summaryPath,
];
report.blockers = report.blockers.filter((blocker) => blocker.id !== 'attempt20-capture-binding-integrity' && blocker.id !== 'attempt20-local-qa-reload-timeout');
report.scopeOfVerdict.evidenceBoundaries = report.scopeOfVerdict.evidenceBoundaries.filter((entry) => !entry.includes('current20体验/risk/campaign报告'));
report.scopeOfVerdict.evidenceBoundaries.push('Attempt20 experience、risk、head、feel-state、visual与lifecycle报告分别以精确H5 SHA绑定；档案中的首轮qa-all/campaign截图包发生L3原PNG被覆盖的hash不匹配，旧报告字节保留但只作历史诊断。');
report.scopeOfVerdict.evidenceBoundaries.push('当前精确attempt20 qa-all两引擎报告均为normalInputOnly=true、stateInjection=false、errors=[]；各自32/34项通过，只有tab-blur-pauses和background-manual-resume两项因未收到桌面后台信号而失败。两引擎共72张嵌套截图逐项SHA校验；campaign 18/18、collision 9/9和五关无跳结算已覆盖。报告保持passed=false，不将环境阻塞或生产门槛宣称为通过。');
report.scopeOfVerdict.notEstablished.push('桌面浏览器无法提供可验证的切后台信号；真实设备后台行为、实体手机验收与真人乐趣/留存仍未建立，故不声称全局QA或生产PASS。');

report.evidenceHistory.archivedInitialCaptureBundle.sourceMappings = mappedSources;

const require = createRequire(path.join(REPO, 'package.json'));
const { z } = require('zod');
const Hash = z.string().regex(HASH);
const Source = z.object({ path: z.string().min(1), sha256: Hash, role: z.string().min(1) }).strict();
const Concern = z.object({ id: z.string().min(1), changes: z.array(z.string().min(1)).min(1), observed: z.array(z.string().min(1)).min(1), inferred: z.array(z.string().min(1)).min(1), unknowns: z.array(z.string().min(1)), acceptanceStatus: z.string().min(1) }).strict();
const EngineQa = z.object({
  engine: z.enum(['webkit', 'chromium']),
  report: z.object({ path: z.string(), sha256: Hash, passed: z.literal(false), checkCount: z.number().int().positive(), passedCheckCount: z.number().int().positive(), failedCheckCount: z.number().int(), normalInputOnly: z.literal(true), stateInjection: z.literal(false), levelChecks: z.array(z.string()).length(10) }).strict(),
  driverProvenance: z.object({ path: z.string(), sha256: Hash, driverSourcePath: z.string(), driverSourceSha256: Hash, buildHash: Hash }).strict(),
  errors: z.array(z.string().min(1)).min(1),
  disposition: z.string().min(1),
}).strict();
const CurrentScreenshot = z.object({ path: z.string(), sha256: Hash, engine: z.enum(['webkit', 'chromium']) }).strict();
const SafetyScreenshot = z.object({ path: z.string(), sha256: Hash }).strict();
const CurrentLevelSettlement = z.object({ level: z.number().int().min(1).max(5), reason: z.literal('complete'), fish: z.number().int().positive(), gold: z.number().int().nonnegative(), jumps: z.literal(0), elapsedSeconds: z.number().finite(), earned: z.literal(true), unlockedThrough: z.number().int().min(1).max(5) }).strict();
const ComparisonFrameBinding = z.object({ path: z.string(), sha256: Hash, bytes: z.number().int().positive(), engine: z.enum(['webkit', 'chromium']), variant: z.enum(['PR10', 'PR13', 'V3']), captureOffsetMs: z.number().finite().nullable() }).strict();
const CurrentBroadQaEngine = z.object({
  engine: z.enum(['webkit', 'chromium']),
  report: z.object({ path: z.string(), sha256: Hash, passed: z.literal(false), checkCount: z.literal(34), passedCheckCount: z.literal(32), failedCheckCount: z.literal(2), normalInputOnly: z.literal(true), stateInjection: z.literal(false), campaignChecks: z.literal(18), campaignPassed: z.literal(18), collisionChecks: z.literal(9), collisionPassed: z.literal(9), safetyChecks: z.literal(7), safetyPassed: z.literal(5), errors: z.array(z.string()).length(0), screenshotCount: z.literal(36), levelSettlements: z.array(CurrentLevelSettlement).length(5) }).strict(),
  failedChecks: z.tuple([z.literal('background-manual-resume'), z.literal('tab-blur-pauses')]),
  screenshots: z.array(CurrentScreenshot).length(36),
  disposition: z.string().min(1),
}).strict();
const SafetyCapability = z.object({ engine: z.enum(['webkit', 'chromium']), status: z.literal('BLOCKED'), supportedChecksPassed: z.literal(true), environmentBlockedChecks: z.tuple([z.literal('background-manual-resume'), z.literal('tab-blur-pauses')]), environmentalEvidence: z.object({ diagnosticName: z.string(), path: z.string(), passed: z.literal(true), classification: z.literal('NO_BACKGROUND_SIGNAL_FROM_HEADLESS_TABS') }).strict() }).strict();
const SafetyReportBinding = z.object({ engine: z.enum(['webkit', 'chromium']), path: z.string(), sha256: Hash, passed: z.literal(false), checkCount: z.literal(7), passedCheckCount: z.literal(5), failedCheckCount: z.literal(2), errors: z.array(z.string()).length(0), screenshots: z.array(SafetyScreenshot).length(7) }).strict();
const LifecycleReportBinding = z.object({ path: z.string(), sha256: Hash, passed: z.literal(false), errors: z.array(z.string()).length(0), lifecycleDiagnostics: z.array(z.object({ engine: z.enum(['webkit', 'chromium']), classification: z.literal('NO_BACKGROUND_SIGNAL_FROM_HEADLESS_TABS'), events: z.array(z.any()).length(0), visibility: z.literal('visible'), focus: z.literal(true) }).strict()).length(2) }).strict();
const ReportSchema = z.object({
  schemaVersion: z.literal(2), targetGame: z.literal('鹈鹕海岸冒险'), workspace: z.literal(WORKSPACE), buildHash: z.literal(BUILD_HASH), attempt: z.literal(20), auditStatus: z.literal(audit3Status), scratchReportPath: z.literal(OUTPUT),
  iterationBaseline: z.object({ authorizedSourceRevision: z.literal('54adc1fb64155f9dd7c1c90ecae7b8185ac540b8'), baselineCommit: z.string(), baselineReceiptPath: z.string(), baselineReceiptSha256: Hash, comparisonMethod: z.string(), observedBaseline: z.string(), observedWholeIterationDelta: z.string(), current20Delta: z.string() }).strict(),
  sourceArtifacts: z.array(Source).length(73),
  concerns: z.tuple([Concern, Concern, Concern, Concern, Concern]).refine((items) => items.map((item) => item.id).join('|') === ['jump-benefit-and-safe-detour', 'first-minute-catch-avoid-success-reward', 'five-stage-operation-fishing-rain-night', 'replay-three-stars-best-fish-routes-feedback', 'pacing-gaps-and-risk-reward'].join('|'), { message: 'five concern IDs/order must stay stable' }),
  stageComparison: z.object({ fishCadenceMeters: z.number(), authoredFishLanePatterns: z.array(z.any()).length(5), routeOperationNotes: z.array(z.any()).length(5), stages: z.array(z.any()).length(5), designNotes: z.array(z.string()).min(1) }).passthrough(),
  firstMinuteMeasurements: z.object({ normalInputOnly: z.literal(true), stateInjection: z.literal(false), engines: z.array(z.any()).length(2), timeline: z.array(z.any()).min(6) }).passthrough(),
  replayMeasurements: z.object({ noJumpFiveStageCampaign: z.any(), jumpRewardRuns: z.any(), feedbackEvidence: z.array(z.string()), bestRecordSemantics: z.string(), starParity: z.string() }).passthrough(),
  perceptualObservations: z.array(z.object({ artifactPath: z.string(), sha256: Hash, observed: z.string(), evidenceMode: z.string().optional() }).passthrough()).min(1),
  blockers: z.array(z.object({ id: z.string(), severity: z.string(), classification: z.string(), evidencePaths: z.array(z.string()).min(1), finding: z.string(), impact: z.string() }).passthrough()).min(1),
  scopeOfVerdict: z.object({ claim: z.string(), evidenceBoundaries: z.array(z.string()).min(1), notEstablished: z.array(z.string()).min(1), finalApproval: z.literal(false) }).passthrough(),
  evidenceHistory: z.object({
    currentSnapshot: z.object({ targetGame: z.literal('鹈鹕海岸冒险'), workspace: z.literal(WORKSPACE), attempt: z.literal(20), buildHash: z.literal(BUILD_HASH), capturedAt: z.string(), buildReceipt: z.object({ path: z.string(), sha256: Hash, qaField: z.string().nullable() }).strict(), qaSummary: z.object({ path: z.string(), sha256: Hash, createdAt: z.string(), scriptedCoreJourneyPassed: z.literal(true), desktopBrowserEvidencePassed: z.literal(true), lifecycleSupportedChecksPassed: z.literal(true), desktopBackgroundEvidence: z.literal('BLOCKED_ENVIRONMENT_SIGNAL_UNAVAILABLE'), independentPerceptualPassed: z.literal(true), runtimeProductJourneyPassed: z.literal(true), h5DevicePlaytestCandidate: z.literal(true), releaseReady: z.literal(false), productionReady: z.literal(false), campaignRows: z.array(z.any()).length(2), safetyClassifications: z.array(SafetyCapability).length(2) }).strict(), comparisonFrameProvenance: z.object({ path: z.string(), sha256: Hash, frameRecordCount: z.literal(120), uniqueSourceFrameCount: z.literal(120), perEngineVariantCounts: z.any(), contactSheetCount: z.literal(4), reportClock: z.string(), captureOffsetDefinition: z.string(), alignmentCaveat: z.string(), alignmentQuality: z.string(), method: z.string() }).strict() }).strict(),
    archivedInitialCaptureBundle: z.object({ status: z.literal('HISTORICAL_INVALID_CAPTURE_BINDING'), pathMap: z.object({ path: z.string(), sha256: Hash, classification: z.string() }).strict(), sourceMappings: z.array(z.object({ originalPath: z.string(), archivedPath: z.string(), sha256: Hash, role: z.string() }).strict()).length(8), perEngine: z.array(z.any()).length(2), unavailability: z.string().min(1) }).strict(),
    currentLocalBroadQaEvidence: z.object({ status: z.literal('BOUNDED_ENVIRONMENT_BLOCKED'), targetGame: z.literal('鹈鹕海岸冒险'), workspace: z.literal(WORKSPACE), attempt: z.literal(20), buildHash: z.literal(BUILD_HASH), engines: z.tuple([CurrentBroadQaEngine, CurrentBroadQaEngine]), uniqueScreenshotCount: z.literal(72), lifecycleReport: LifecycleReportBinding.extend({ supportedChecksPassed: z.literal(true) }).strict(), safetyReportBindings: z.tuple([SafetyReportBinding, SafetyReportBinding]), priorReloadTimeout: z.object({ pathMap: z.object({ path: z.string(), sha256: Hash, classification: z.string() }).strict(), engines: z.tuple([EngineQa, EngineQa]) }).strict(), disposition: z.string().min(1) }).strict(),
    currentPngFrameBindings: z.object({ provenancePath: z.string(), provenanceSha256: Hash, frameCount: z.literal(120), uniqueFrameCount: z.literal(120), frames: z.array(ComparisonFrameBinding).length(120), contactSheets: z.array(z.object({ path: z.string(), sha256: Hash, bytes: z.number().int().positive(), mime: z.literal('image/png'), role: z.string(), engine: z.enum(['webkit', 'chromium']) }).strict()).length(4) }).strict(),
    interpretationBoundary: z.string().min(1),
  }).strict(),
}).passthrough();

const parsed = ReportSchema.safeParse(report);
if (!parsed.success) throw new Error(`audit3 Zod validation failed: ${JSON.stringify(parsed.error.issues)}`);
const sourceProblems = [];
for (const source of report.sourceArtifacts) {
  if (!path.isAbsolute(source.path) || !source.path.startsWith(`${REPO}/`)) { sourceProblems.push({ path: source.path, expected: source.sha256, actual: null, issue: 'outside-repository' }); continue; }
  if (!fs.existsSync(source.path)) { sourceProblems.push({ path: source.path, expected: source.sha256, actual: null, issue: 'missing' }); continue; }
  const actual = fileSha(source.path);
  if (actual !== source.sha256) sourceProblems.push({ path: source.path, expected: source.sha256, actual, issue: 'sha256' });
}
if (sourceProblems.length) throw new Error(`audit3 source provenance mismatch: ${JSON.stringify(sourceProblems)}`);
for (const entry of mappedSources) {
  if (fileSha(entry.archivedPath) !== entry.sha256) throw new Error(`audit3 archive mapping SHA mismatch: ${entry.archivedPath}`);
}
const baseline = readJson(absRun('baseline-receipt.json'), 'baseline receipt');
const mainEntry = baseline.files?.find((file) => file.path === 'pelican-bike/src/main.js');
if (baseline.sourceRevision !== report.iterationBaseline.authorizedSourceRevision || !mainEntry || fileSha(absRun('original-main.js')) !== mainEntry.sha256) throw new Error('authorized baseline source binding mismatch');

const serialized = `${JSON.stringify(report, null, 2)}\n`;
fs.writeFileSync(OUTPUT, serialized, 'utf8');
const scriptPath = fileURLToPath(import.meta.url);
const validation = {
  schemaVersion: 1,
  targetGame: report.targetGame,
  workspace: report.workspace,
  buildHash: report.buildHash,
  attempt: report.attempt,
  artifactPath: OUTPUT,
  artifactSha256: fileSha(OUTPUT),
  validatorScriptPath: scriptPath,
  validatorScriptSha256: fileSha(scriptPath),
  zodVersion: require('zod/package.json').version,
  zodValidation: 'passed',
  checkedConcernIds: report.concerns.map((concern) => concern.id),
  concernCount: report.concerns.length,
  sourceArtifactCount: report.sourceArtifacts.length,
  sourceSha256Validation: 'passed',
  validatedSourceBindings: report.sourceArtifacts.map(({ path: sourcePath, sha256, role }) => ({ path: sourcePath, sha256, role })),
  archivePathMappingCount: mappedSources.length,
  archivePathMappings: mappedSources.map(({ originalPath, archivedPath, sha256 }) => ({ originalPath, archivedPath, sha256 })),
  unavailableOriginalL3HazardPngs: engineCaptureBindings.map(({ engine, expectedScreenshot }) => ({ engine, expectedSha256: expectedScreenshot.expectedSha256, status: expectedScreenshot.originalBytesStatus, usableAsEvidence: expectedScreenshot.usableAsEvidence })),
  localQaRetestStatus: localQaRetest.status,
  currentQaAllReportBindings: currentBroadQaEngines.map(({ engine, report: qaReport, failedChecks }) => ({ engine, path: qaReport.path, sha256: qaReport.sha256, passed: qaReport.passed, checkCount: qaReport.checkCount, passedCheckCount: qaReport.passedCheckCount, failedCheckCount: qaReport.failedCheckCount, failedChecks, errors: qaReport.errors })),
  currentQaAllScreenshotCount: currentBroadQaScreenshotBindings.length,
  currentQaAllScreenshotBindings: currentBroadQaScreenshotBindings,
  priorReloadTimeoutBindings: localRetestEngines.map(({ engine, report: qaReport, errors }) => ({ engine, path: qaReport.path, sha256: qaReport.sha256, passed: qaReport.passed, checkCount: qaReport.checkCount, passedCheckCount: qaReport.passedCheckCount, failedCheckCount: qaReport.failedCheckCount, errors })),
  currentSummarySnapshot: { path: summaryPath, sha256: currentSnapshot.qaSummary.sha256, scriptedCoreJourneyPassed: currentSnapshot.qaSummary.scriptedCoreJourneyPassed, desktopBrowserEvidencePassed: currentSnapshot.qaSummary.desktopBrowserEvidencePassed, lifecycleSupportedChecksPassed: currentSnapshot.qaSummary.lifecycleSupportedChecksPassed, desktopBackgroundEvidence: currentSnapshot.qaSummary.desktopBackgroundEvidence, h5DevicePlaytestCandidate: currentSnapshot.qaSummary.h5DevicePlaytestCandidate, releaseReady: currentSnapshot.qaSummary.releaseReady, productionReady: currentSnapshot.qaSummary.productionReady },
  currentLifecycleReportBinding,
  currentSafetyReportBindings,
  currentComparisonProvenance: { path: provenancePath, sha256: fileSha(provenancePath), frameCount: frameBindings.length, uniqueFramePathCount: uniqueFramePaths.size, perEngineVariantCounts, contactSheetCount: provenance.contactSheets.length, frameBindings },
  baselineSourceRevision: baseline.sourceRevision,
  baselineSnapshotValidation: 'passed',
  originalAudit2Preserved: fileSha(INPUT) === originalAudit2Sha,
  mismatchedSources: [],
};
const ValidationSchema = z.object({
  schemaVersion: z.literal(1),
  targetGame: z.literal('鹈鹕海岸冒险'),
  workspace: z.literal(WORKSPACE),
  buildHash: Hash,
  attempt: z.literal(20),
  artifactPath: z.string(),
  artifactSha256: Hash,
  validatorScriptPath: z.string(),
  validatorScriptSha256: Hash,
  zodVersion: z.string(),
  zodValidation: z.literal('passed'),
  checkedConcernIds: z.array(z.string()).length(5),
  concernCount: z.literal(5),
  sourceArtifactCount: z.literal(73),
  sourceSha256Validation: z.literal('passed'),
  validatedSourceBindings: z.array(z.object({ path: z.string(), sha256: Hash, role: z.string() }).strict()).length(73),
  archivePathMappingCount: z.literal(8),
  archivePathMappings: z.array(z.object({ originalPath: z.string(), archivedPath: z.string(), sha256: Hash }).strict()).length(8),
  unavailableOriginalL3HazardPngs: z.array(z.object({ engine: z.enum(['webkit', 'chromium']), expectedSha256: Hash, status: z.literal('UNAVAILABLE_OVERWRITTEN'), usableAsEvidence: z.literal(false) }).strict()).length(2),
  localQaRetestStatus: z.literal('BOUNDED_ENVIRONMENT_BLOCKED'),
  currentQaAllReportBindings: z.array(z.object({ engine: z.enum(['webkit', 'chromium']), path: z.string(), sha256: Hash, passed: z.literal(false), checkCount: z.literal(34), passedCheckCount: z.literal(32), failedCheckCount: z.literal(2), failedChecks: z.tuple([z.literal('background-manual-resume'), z.literal('tab-blur-pauses')]), errors: z.array(z.string()).length(0) }).strict()).length(2),
  currentQaAllScreenshotCount: z.literal(72),
  currentQaAllScreenshotBindings: z.array(CurrentScreenshot).length(72),
  priorReloadTimeoutBindings: z.array(z.object({ engine: z.enum(['webkit', 'chromium']), path: z.string(), sha256: Hash, passed: z.literal(false), checkCount: z.number().int().positive(), passedCheckCount: z.number().int().positive(), failedCheckCount: z.literal(0), errors: z.array(z.string()).min(1) }).strict()).length(2),
  currentSummarySnapshot: z.object({ path: z.string(), sha256: Hash, scriptedCoreJourneyPassed: z.literal(true), desktopBrowserEvidencePassed: z.literal(true), lifecycleSupportedChecksPassed: z.literal(true), desktopBackgroundEvidence: z.literal('BLOCKED_ENVIRONMENT_SIGNAL_UNAVAILABLE'), h5DevicePlaytestCandidate: z.literal(true), releaseReady: z.literal(false), productionReady: z.literal(false) }).strict(),
  currentLifecycleReportBinding: LifecycleReportBinding,
  currentSafetyReportBindings: z.tuple([SafetyReportBinding, SafetyReportBinding]),
  currentComparisonProvenance: z.object({ path: z.string(), sha256: Hash, frameCount: z.literal(120), uniqueFramePathCount: z.literal(120), perEngineVariantCounts: z.any(), contactSheetCount: z.literal(4), frameBindings: z.array(ComparisonFrameBinding).length(120) }).strict(),
  baselineSourceRevision: z.literal('54adc1fb64155f9dd7c1c90ecae7b8185ac540b8'),
  baselineSnapshotValidation: z.literal('passed'),
  originalAudit2Preserved: z.literal(true),
  mismatchedSources: z.array(z.any()).length(0),
}).strict();
const checkedValidation = ValidationSchema.safeParse(validation);
if (!checkedValidation.success) throw new Error(`audit3 validation evidence Zod validation failed: ${JSON.stringify(checkedValidation.error.issues)}`);
fs.writeFileSync(VALIDATION, `${JSON.stringify(validation, null, 2)}\n`, 'utf8');
console.log(JSON.stringify({ artifactPath: OUTPUT, artifactSha256: validation.artifactSha256, validationPath: VALIDATION, validationSha256: fileSha(VALIDATION), sourceArtifactCount: report.sourceArtifacts.length, archivePathMappingCount: mappedSources.length, uniqueComparisonFrames: uniqueFramePaths.size, contactSheets: provenance.contactSheets.length, localQaRetestStatus: localQaRetest.status, zodValidation: 'passed' }, null, 2));
