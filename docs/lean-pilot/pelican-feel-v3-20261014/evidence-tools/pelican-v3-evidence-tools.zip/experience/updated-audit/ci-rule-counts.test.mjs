import assert from 'node:assert/strict';
import test from 'node:test';
import { summarizeCiRuleCounts } from './ci-rule-counts.mjs';

test('keeps current local rules separate from the immutable dedicated CI snapshot', () => {
  const summary = summarizeCiRuleCounts(
    { passed: 108, total: 108, status: 'PASS' },
    [
      { engine: 'webkit', rules: { passed: 105, total: 105, failed: 0 } },
      { engine: 'chromium', rules: { passed: 105, total: 105, failed: 0 } },
    ],
  );

  assert.deepEqual(summary, {
    local: { passed: 108, total: 108 },
    dedicatedCi: { passed: 105, total: 105 },
    countsMatch: false,
  });
});

test('accepts matching counts without conflating the evidence sources', () => {
  const summary = summarizeCiRuleCounts(
    { passed: 108, total: 108, status: 'PASS' },
    [
      { engine: 'webkit', rules: { passed: 108, total: 108, failed: 0 } },
      { engine: 'chromium', rules: { passed: 108, total: 108, failed: 0 } },
    ],
  );

  assert.deepEqual(summary, {
    local: { passed: 108, total: 108 },
    dedicatedCi: { passed: 108, total: 108 },
    countsMatch: true,
  });
});

test('rejects incomplete dedicated CI rules rather than downgrading the gate', () => {
  assert.throws(() => summarizeCiRuleCounts(
    { passed: 108, total: 108, status: 'PASS' },
    [
      { engine: 'webkit', rules: { passed: 104, total: 105, failed: 1 } },
      { engine: 'chromium', rules: { passed: 105, total: 105, failed: 0 } },
    ],
  ), /dedicated CI rules must be complete and passing/u);
});

test('rejects duplicate engines and per-engine count disagreement', () => {
  const webkit = { engine: 'webkit', rules: { passed: 105, total: 105, failed: 0 } };
  assert.throws(() => summarizeCiRuleCounts(
    { passed: 108, total: 108, status: 'PASS' },
    [webkit, webkit],
  ), /exactly one WebKit and one Chromium record/u);

  assert.throws(() => summarizeCiRuleCounts(
    { passed: 108, total: 108, status: 'PASS' },
    [
      webkit,
      { engine: 'chromium', rules: { passed: 108, total: 108, failed: 0 } },
    ],
  ), /engine records disagree on the dedicated CI rule count/u);
});
