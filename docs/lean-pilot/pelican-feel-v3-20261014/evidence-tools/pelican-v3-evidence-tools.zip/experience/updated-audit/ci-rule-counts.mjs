const ENGINES = new Set(['webkit', 'chromium']);

function validCount(value) {
  return Number.isInteger(value) && value >= 0;
}

export function summarizeCiRuleCounts(localTests, engineRecords) {
  if (
    !localTests ||
    !validCount(localTests.passed) ||
    !validCount(localTests.total) ||
    localTests.total === 0 ||
    localTests.passed !== localTests.total ||
    String(localTests.status).toUpperCase() !== 'PASS'
  ) {
    throw new Error('current local rules must be complete and passing');
  }

  if (!Array.isArray(engineRecords) || engineRecords.length !== 2) {
    throw new Error('dedicated CI must contain exactly one WebKit and one Chromium record');
  }
  const byEngine = new Map();
  for (const record of engineRecords) {
    if (!ENGINES.has(record?.engine) || byEngine.has(record.engine)) {
      throw new Error('dedicated CI must contain exactly one WebKit and one Chromium record');
    }
    byEngine.set(record.engine, record);
  }
  if (!byEngine.has('webkit') || !byEngine.has('chromium')) {
    throw new Error('dedicated CI must contain exactly one WebKit and one Chromium record');
  }

  const engineCounts = [...byEngine.values()].map((record) => record.rules);
  for (const rules of engineCounts) {
    if (
      !rules ||
      !validCount(rules.passed) ||
      !validCount(rules.total) ||
      !validCount(rules.failed) ||
      rules.total === 0 ||
      rules.passed !== rules.total ||
      rules.failed !== 0
    ) {
      throw new Error('dedicated CI rules must be complete and passing');
    }
  }

  const [webkit, chromium] = engineCounts;
  if (webkit.passed !== chromium.passed || webkit.total !== chromium.total) {
    throw new Error('engine records disagree on the dedicated CI rule count');
  }

  return {
    local: { passed: localTests.passed, total: localTests.total },
    dedicatedCi: { passed: webkit.passed, total: webkit.total },
    countsMatch: localTests.passed === webkit.passed && localTests.total === webkit.total,
  };
}
