import assert from 'node:assert/strict';
import test from 'node:test';
import { parseReportOutputArgs, resolveReportOutput } from './output-target.mjs';

test('keeps the canonical report target when no override is supplied', () => {
  assert.deepEqual(parseReportOutputArgs(['/repo']), { repoArg: '/repo', outputOverride: null });
  assert.equal(resolveReportOutput('/repo', 'docs/report.md', null), '/repo/docs/report.md');
});

test('accepts an absolute scratch output outside the repository', () => {
  assert.deepEqual(parseReportOutputArgs(['/repo', '--output', '/scratch/report.md']), {
    repoArg: '/repo',
    outputOverride: '/scratch/report.md',
  });
  assert.equal(resolveReportOutput('/repo', 'docs/report.md', '/scratch/report.md'), '/scratch/report.md');
});

test('rejects malformed CLI options and output paths inside the repository', () => {
  assert.throws(() => parseReportOutputArgs(['/repo', '/scratch/report.md']), /Usage:/u);
  assert.throws(() => parseReportOutputArgs(['/repo', '--output']), /Usage:/u);
  assert.throws(() => resolveReportOutput('/repo', 'docs/report.md', 'relative/report.md'), /absolute path/u);
  assert.throws(() => resolveReportOutput('/repo', 'docs/report.md', '/repo/docs/other.md'), /outside the repository/u);
});
