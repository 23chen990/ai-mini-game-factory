import path from 'node:path';

export function parseReportOutputArgs(args) {
  if (args.length === 1 && args[0]) {
    return { repoArg: args[0], outputOverride: null };
  }
  if (args.length === 3 && args[0] && args[1] === '--output' && args[2]) {
    return { repoArg: args[0], outputOverride: args[2] };
  }
  throw new Error('Usage: node chinese-report.mjs <main-repository-path> [--output <absolute-scratch-path>]');
}

export function resolveReportOutput(repoPath, canonicalReportPath, outputOverride) {
  const repo = path.resolve(repoPath);
  if (outputOverride === null || outputOverride === undefined) {
    return path.resolve(repo, canonicalReportPath);
  }
  if (typeof outputOverride !== 'string' || !path.isAbsolute(outputOverride)) {
    throw new Error('Custom report output must be an absolute path');
  }
  const output = path.resolve(outputOverride);
  const relative = path.relative(repo, output);
  const insideRepository = relative === '' || (relative !== '..' && !relative.startsWith(`..${path.sep}`) && !path.isAbsolute(relative));
  if (insideRepository) {
    throw new Error('Custom report output must be outside the repository');
  }
  return output;
}
