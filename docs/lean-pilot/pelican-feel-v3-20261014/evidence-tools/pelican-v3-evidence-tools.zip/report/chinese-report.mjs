#!/usr/bin/env node
/*
 * Rebuild the Chinese Pelican V3 QA report from the final, hash-bound run
 * artifacts. This generator is intentionally fail-closed and only writes
 * docs/lean-pilot/pelican-feel-v3-20261014/QA_REPORT_ZH.md in the given repo.
 */
import { createHash } from 'node:crypto';
import { lstat, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { summarizeCiRuleCounts } from '../experience/updated-audit/ci-rule-counts.mjs';
import { parseReportOutputArgs, resolveReportOutput } from './output-target.mjs';

const GAME = '鹈鹕海岸冒险';
const RUN_ID = 'pelican-coast-v2-20261014';
const SHA256 = /^[a-f0-9]{64}$/u;
const EXPECTED_REPORT = 'docs/lean-pilot/pelican-feel-v3-20261014/QA_REPORT_ZH.md';
const EXPECTED_CONCERNS = [
  'meaningful-jump-versus-safe-detour',
  'first-30-to-60-seconds',
  'five-stage-differences-rain-and-night',
  'replay-and-mastery',
  'pacing-and-risk-reward',
];

function fail(message) { throw new Error(message); }
function need(ok, message) { if (!ok) fail(message); }
function isObject(value) { return value !== null && typeof value === 'object' && !Array.isArray(value); }
function text(value) { return typeof value === 'string' ? value.trim() : ''; }
function status(value) { return text(value).toUpperCase(); }
function md(value) {
  return String(value ?? '—').replaceAll('|', '\\|').replaceAll('\r', ' ').replaceAll('\n', ' ').replaceAll('`', '\\`');
}
function sha(bytes) { return createHash('sha256').update(bytes).digest('hex'); }
function relSafe(value) {
  const normalized = String(value ?? '').replaceAll('\\', '/').trim();
  need(normalized.length > 0, 'Empty evidence path');
  need(!path.posix.isAbsolute(normalized) && !path.win32.isAbsolute(normalized), `Absolute evidence path rejected: ${normalized}`);
  need(!normalized.split('/').includes('..'), `Path traversal rejected: ${normalized}`);
  need(!/^(?:[a-z]+:)?\/\//iu.test(normalized), `URL evidence path rejected: ${normalized}`);
  return normalized;
}

const { repoArg, outputOverride } = parseReportOutputArgs(process.argv.slice(2));
const REPO = path.resolve(repoArg);
const RUN_REL = `runs/${RUN_ID}`;
const RUN = path.join(REPO, RUN_REL);
const WORKSPACE_REL = `${RUN_REL}/workspace`;
const WORKSPACE = path.join(REPO, WORKSPACE_REL);
const attemptRoot = (attempt) => `${RUN_REL}/attempts/attempt-${attempt}`;
const candidateRel = 'docs/lean-pilot/pelican-feel-v3-20261014/release-candidate';
const candidate = path.join(REPO, candidateRel);

async function assertNoSymlink(relative, finalKind = 'file') {
  const safe = relSafe(relative);
  let current = REPO;
  const parts = safe.split('/');
  for (let i = 0; i < parts.length; i += 1) {
    current = path.join(current, parts[i]);
    let st;
    try { st = await lstat(current); } catch (error) {
      if (error && error.code === 'ENOENT') fail(`Required ${finalKind} is missing: ${safe}`);
      throw error;
    }
    need(!st.isSymbolicLink(), `Symlink is forbidden in evidence path: ${safe}`);
    if (i < parts.length - 1) need(st.isDirectory(), `Evidence parent is not a directory: ${safe}`);
    else need(finalKind === 'directory' ? st.isDirectory() : st.isFile(), `Evidence is not a regular ${finalKind}: ${safe}`);
  }
  return current;
}

async function assertSafeExternalOutput(absolutePath) {
  const resolved = path.resolve(absolutePath);
  const root = path.parse(resolved).root;
  const parts = resolved.slice(root.length).split(path.sep).filter(Boolean);
  let current = root;
  for (let index = 0; index < parts.length; index += 1) {
    current = path.join(current, parts[index]);
    let st;
    try { st = await lstat(current); } catch (error) {
      if (error && error.code === 'ENOENT' && index === parts.length - 1) return resolved;
      if (error && error.code === 'ENOENT') fail(`Scratch output parent is missing: ${path.dirname(resolved)}`);
      throw error;
    }
    need(!st.isSymbolicLink(), `Symlink is forbidden in scratch output path: ${resolved}`);
    if (index < parts.length - 1) need(st.isDirectory(), `Scratch output parent is not a directory: ${current}`);
    else need(st.isFile(), `Scratch output is not a regular file: ${resolved}`);
  }
  return resolved;
}

async function readBytes(relative) {
  const full = await assertNoSymlink(relative, 'file');
  return readFile(full);
}
async function readJson(relative) {
  const bytes = await readBytes(relative);
  try { return { value: JSON.parse(bytes.toString('utf8')), bytes, sha256: sha(bytes) }; }
  catch (error) { fail(`Invalid JSON at ${relative}: ${error.message}`); }
}
async function hashRel(relative) { return sha(await readBytes(relative)); }
async function maybeJson(relative) {
  try { return await readJson(relative); }
  catch (error) { if (/Required file is missing:/u.test(String(error.message))) return null; throw error; }
}
function checkIdentity(value, label, receipt, { targetRequired = true } = {}) {
  if (value.targetGame === undefined && !targetRequired) {
    // BuildReport/BuildReceipt bind the exact workspace but have no targetGame field.
  } else need(value.targetGame === GAME, `${label} targetGame mismatch`);
  need(value.workspace === WORKSPACE, `${label} workspace mismatch`);
  if (value.attempt !== undefined) need(value.attempt === receipt.attempt, `${label} attempt is stale`);
  if (value.buildHash !== undefined) need(value.buildHash === receipt.buildHash, `${label} buildHash is stale`);
}
function checksMap(report) {
  return new Map((Array.isArray(report?.checks) ? report.checks : []).map((check) => [check?.name, check]));
}
function passedCheck(report, name, label) {
  const check = checksMap(report).get(name);
  need(check?.passed === true, `${label} is missing or did not pass: ${name}`);
  return check;
}
function eventList(evidence) { return Array.isArray(evidence?.events) ? evidence.events : []; }
function finiteNumber(value, label) {
  need(typeof value === 'number' && Number.isFinite(value), `Missing finite measurement: ${label}`);
  return value;
}
function fmt(value, digits = 2) {
  return Number.isFinite(value) ? Number(value).toFixed(digits) : '—';
}
function markdownTable(headers, rows) {
  return [
    `| ${headers.map(md).join(' | ')} |`,
    `| ${headers.map(() => '---').join(' | ')} |`,
    ...rows.map((row) => `| ${row.map(md).join(' | ')} |`),
  ].join('\n');
}

const repoStat = await lstat(REPO);
need(repoStat.isDirectory() && !repoStat.isSymbolicLink(), 'Repository path must be a regular directory, not a symlink');
await assertNoSymlink(RUN_REL, 'directory');
await assertNoSymlink(WORKSPACE_REL, 'directory');
const targetWorkspace = path.resolve(WORKSPACE);

const receiptResult = await readJson(`${RUN_REL}/build-receipt.json`);
const receipt = receiptResult.value;
need(isObject(receipt), 'Build receipt must be an object');
checkIdentity(receipt, 'build receipt', { attempt: receipt.attempt, buildHash: receipt.buildHash }, { targetRequired: false });
need(Number.isInteger(receipt.attempt) && receipt.attempt > 0, 'Build receipt attempt is invalid');
need(SHA256.test(receipt.buildHash ?? ''), 'Build receipt buildHash is invalid');
need(receipt.buildExit === 0 && receipt.route === 'formal-fixer', 'Build receipt is not a successful formal-fixer build');
need(text(receipt.threadId).length > 0, 'Build receipt threadId is missing');

const currentAttempt = attemptRoot(receipt.attempt);
const currentAttemptRunRelative = currentAttempt.slice(`${RUN_REL}/`.length);
function isCurrentAttemptPath(value) {
  const safe = relSafe(value);
  return safe.startsWith(`${currentAttemptRunRelative}/`);
}
function requireRepoCurrentAttemptPath(value, label) {
  const safe = relSafe(value);
  const runPrefix = `${RUN_REL}/`;
  need(safe.startsWith(runPrefix), `${label} must be a repository-relative path inside ${RUN_REL}`);
  const runRelative = safe.slice(runPrefix.length);
  need(isCurrentAttemptPath(runRelative), `${label} is outside current attempt ${receipt.attempt}`);
  return { repoRelative: safe, runRelative };
}
function normalizeRunEvidencePath(value, label) {
  const safe = relSafe(value);
  const prefix = `${RUN_REL}/`;
  if (safe.startsWith('runs/')) {
    need(safe.startsWith(prefix), `${label} points into another run or game: ${safe}`);
    return safe;
  }
  return `${RUN_REL}/${safe}`;
}
const fixResult = await readJson(`${currentAttempt}/fix-evidence.json`);
const fixEvidence = fixResult.value;
need(fixEvidence.attempt === receipt.attempt && fixEvidence.route === 'formal-fixer', 'Fix evidence is missing or not from the current formal-fixer attempt');
need(fixEvidence.workspace === WORKSPACE && fixEvidence.buildHash === receipt.buildHash, 'Fix evidence target/build identity mismatch');
need(fixEvidence.threadId === receipt.threadId, 'Build receipt and repair thread do not match');
need(SHA256.test(fixEvidence.codeHash ?? ''), 'Formal-fixer code hash is invalid');
if (receipt.codeHash !== undefined) need(receipt.codeHash === fixEvidence.codeHash, 'Build receipt and formal-fixer code hash do not match');
need(Array.isArray(fixEvidence.contextIntentionallyOmitted), 'Formal-fixer context omission record is missing');

const summaryResult = await readJson(`${RUN_REL}/qa-summary-v3.json`);
const qaResult = await readJson(`${RUN_REL}/qa-report-v3.json`);
const buildReportResult = await readJson(`${RUN_REL}/build-report-v3.json`);
const summary = summaryResult.value;
const qaReport = qaResult.value;
const buildReport = buildReportResult.value;
checkIdentity(summary, 'QA summary', receipt);
checkIdentity(buildReport, 'build report', receipt, { targetRequired: false });
need(summary.runId === RUN_ID && summary.route === 'formal-fixer', 'QA summary run/route mismatch');
need(summary.createdAt && Date.parse(summary.createdAt) >= Date.parse(receipt.at), 'QA summary predates the current build receipt');
need(summary.evidenceManifestPath === 'qa-evidence-manifest-v3.json', 'Unexpected evidence manifest path');
need(summary.scriptedCoreJourneyPassed === true, 'Scripted default journey gate is not PASS');
need(summary.desktopBrowserEvidencePassed === true, 'Desktop browser evidence gate is not PASS');
need(summary.lifecycleSupportedChecksPassed === true, 'Lifecycle checks supported by the current desktop environment are not PASS');
need(summary.desktopBackgroundEvidence === 'BLOCKED_ENVIRONMENT_SIGNAL_UNAVAILABLE', 'Desktop background-signal limitation is missing or has been overstated');
need(summary.independentPerceptualPassed === true, 'Independent perceptual gate is not PASS');
need(summary.runtimeProductJourneyPassed === true, 'Runtime product gate is not PASS');
need(summary.releaseReady === false && summary.productionReady === false, 'QA summary falsely claims release or production readiness');
need(summary.readiness?.h5DevicePlaytestCandidate === true, 'H5 device-playtest candidate gate is not PASS');
need(summary.readiness?.physicalDevice === false && summary.readiness?.liveAds === false && summary.readiness?.nativePackages === false && summary.readiness?.production === false, 'Blocked readiness fields are inconsistent');
need(buildReport.success === true && buildReport.completion?.status === 'RELEASE_BLOCKED', 'Build report is missing the successful H5 / blocked-release split');
need(buildReport.webBuild === path.join(WORKSPACE, 'game/index.html') || buildReport.webBuild === `${WORKSPACE}/game/index.html`, 'Build report points to a different H5 entrypoint');
need(qaReport.schemaVersion === 1 && qaReport.passed === false, 'QA report must remain release-blocked');

const gateSpecs = [
  ['artifacts/perceptual-qa-gate-v3.json', 'perceptual gate', 'perceptual-gate-v3'],
  ['artifacts/runtime-product-gates-v3.json', 'runtime product gate', 'runtime-product-gate-v3'],
  ['artifacts/runtime-wiring-verification-v3.json', 'runtime wiring gate', 'runtime-wiring-v3'],
];
const gates = {};
for (const [name, label] of gateSpecs) {
  const result = await readJson(`${RUN_REL}/${name}`);
  gates[name] = result.value;
  need(gates[name].passed === true, `${label} is missing or blocked`);
  if (gates[name].targetGame !== undefined) need(gates[name].targetGame === GAME, `${label} targetGame mismatch`);
  if (gates[name].workspace !== undefined) need(gates[name].workspace === WORKSPACE, `${label} workspace mismatch`);
  if (gates[name].buildHash !== undefined) need(gates[name].buildHash === receipt.buildHash, `${label} buildHash mismatch`);
}

const manifestResult = await readJson(`${RUN_REL}/${summary.evidenceManifestPath}`);
const manifest = manifestResult.value;
checkIdentity(manifest, 'evidence manifest', receipt);
need(manifest.targetRunId === RUN_ID, 'Evidence manifest run id mismatch');
need(manifest.schemaVersion === 1, 'Evidence manifest schema version mismatch');
need(Array.isArray(manifest.reports) && manifest.reports.length > 0, 'Evidence manifest has no reports');
need(Array.isArray(manifest.naturalTraces) && manifest.naturalTraces.length > 0, 'Evidence manifest has no natural traces');
need(Array.isArray(manifest.copyFiles), 'Evidence manifest copyFiles is missing');

const manifestByPath = new Map();
for (const entry of [...manifest.reports, ...manifest.naturalTraces]) {
  need(isObject(entry) && text(entry.path), 'Malformed evidence manifest entry');
  const p = relSafe(entry.path);
  if (entry.sha256 === '0'.repeat(64)) {
    need(entry.status === 'BLOCKED' || entry.status === 'FAIL', `Evidence with a zero hash is not marked BLOCKED/FAIL: ${p}`);
    continue;
  }
  need(SHA256.test(entry.sha256 ?? ''), `Invalid evidence SHA-256: ${p}`);
  const actual = await hashRel(`${RUN_REL}/${p}`);
  need(actual === entry.sha256, `Evidence file hash mismatch: ${p}`);
  manifestByPath.set(p, entry.sha256);
}
for (const entry of [...manifest.screenshots, ...manifest.copyFiles]) {
  need(isObject(entry) && text(entry.path), 'Malformed screenshot/copy evidence manifest entry');
  const p = relSafe(entry.path);
  need(SHA256.test(entry.sha256 ?? '') && entry.sha256 !== '0'.repeat(64), `Invalid evidence SHA-256: ${p}`);
  const actual = await hashRel(`${RUN_REL}/${p}`);
  need(actual === entry.sha256, `Evidence file hash mismatch: ${p}`);
  manifestByPath.set(p, entry.sha256);
}

const lifecycleRows = summary.reports?.filter((item) => item.kind === 'lifecycle') ?? [];
need(lifecycleRows.length === 1 && lifecycleRows[0].engine === 'webkit+chromium' && lifecycleRows[0].status === 'BLOCKED', 'Current lifecycle summary must retain the desktop background-signal limitation');
need(isCurrentAttemptPath(lifecycleRows[0].path) && manifestByPath.get(lifecycleRows[0].path) === lifecycleRows[0].sha256, 'Current lifecycle report is stale or not manifest-bound');
const lifecycleResult = await readJson(`${RUN_REL}/${lifecycleRows[0].path}`);
checkIdentity(lifecycleResult.value, 'lifecycle report', receipt);
need(lifecycleResult.sha256 === lifecycleRows[0].sha256 && Array.isArray(lifecycleResult.value.errors) && lifecycleResult.value.errors.length === 0, 'Current lifecycle report hash/errors are invalid');
const lifecycleChecks = checksMap(lifecycleResult.value);
for (const name of ['portrait-to-landscape-live-resize', 'all-quality-presets-keep-composer-size', 'offline-single-html-normal-touch-catch', 'engineering-context-loss-pauses', 'engineering-context-restored-manual-resume']) {
  need(lifecycleChecks.get(name)?.passed === true, `Supported lifecycle check is missing or failed: ${name}`);
}
for (const name of ['actual-window-background-pauses', 'background-countdown-stays-paused', 'background-requires-manual-resume']) {
  need(lifecycleChecks.has(name), `Lifecycle background limitation check is missing: ${name}`);
}
const lifecycleDiagnostics = new Map((lifecycleResult.value.diagnostics ?? []).map((item) => [item.name, item]));
for (const engine of ['webkit', 'chromium']) {
  const diagnostic = lifecycleDiagnostics.get(`headless-${engine}-tab-capability`);
  need(diagnostic?.classification === 'NO_BACKGROUND_SIGNAL_FROM_HEADLESS_TABS', `Lifecycle/${engine} lacks the exact headless background-signal classification`);
  const events = diagnostic.observation?.away?.events;
  need(Array.isArray(events) && events.length === 0 && diagnostic.observation?.away?.visibility === 'visible' && diagnostic.observation?.away?.focus === true, `Lifecycle/${engine} diagnostic contains an observed background signal`);
}
const safetySummaryRows = summary.reports?.filter((item) => item.kind === 'safety') ?? [];
need(safetySummaryRows.length === 2, 'Current QA summary must contain both engine safety classifications');
for (const engine of ['webkit', 'chromium']) {
  const row = safetySummaryRows.find((item) => item.engine === engine);
  need(row?.status === 'BLOCKED' && row.classification?.supportedChecksPassed === true, `Safety/${engine} must preserve its supported-check pass and bounded environmental block`);
  need(JSON.stringify([...(row.classification.environmentBlockedChecks ?? [])].sort()) === JSON.stringify(['background-manual-resume', 'tab-blur-pauses']), `Safety/${engine} has an unexpected environment-blocked check set`);
  const evidence = row.classification.environmentalEvidence;
  need(evidence?.passed === true && evidence.classification === 'NO_BACKGROUND_SIGNAL_FROM_HEADLESS_TABS' && evidence.path === lifecycleRows[0].path, `Safety/${engine} lacks current exact lifecycle capability evidence`);
  need(isCurrentAttemptPath(row.path) && manifestByPath.get(row.path) === row.sha256, `Safety/${engine} report is stale or not manifest-bound`);
}

const requiredReportPairs = [
  ['campaign', 'webkit'], ['campaign', 'chromium'], ['collision', 'webkit'], ['collision', 'chromium'],
  ['experience', 'webkit'], ['experience', 'chromium'], ['head', 'webkit'], ['head', 'chromium'],
  ['risk', 'webkit'], ['risk', 'chromium'], ['feel-state', 'webkit'], ['feel-state', 'chromium'], ['visual', 'webkit'],
];
for (const [kind, engine] of requiredReportPairs) {
  const rows = summary.reports?.filter((r) => r.kind === kind && r.engine === engine) ?? [];
  need(rows.length === 1 && rows[0].status === 'PASS', `Current-build ${kind}/${engine} is missing, duplicate, stale, or not PASS`);
  need(isCurrentAttemptPath(rows[0].path), `Current-build ${kind}/${engine} points outside attempt ${receipt.attempt}`);
  need(rows[0].sha256 === manifestByPath.get(rows[0].path), `Current-build ${kind}/${engine} is not hash-bound by the evidence manifest`);
  const manifestRow = manifest.reports.find((r) => r.kind === kind && r.engine === engine);
  need(manifestRow?.path === rows[0].path && manifestRow.sha256 === rows[0].sha256 && manifestRow.status === 'PASS', `Current-build manifest binding mismatch: ${kind}/${engine}`);
}
for (const [file, label, manifestKind] of gateSpecs) {
  const binding = manifest.copyFiles.find((entry) => entry.path === file && entry.kind === manifestKind);
  need(binding?.sha256 === await hashRel(`${RUN_REL}/${file}`), `${label} is not bound by the current evidence manifest as ${manifestKind}`);
}

const currentHtmlRel = `${WORKSPACE_REL}/game/index.html`;
const currentHtmlHash = await hashRel(currentHtmlRel);
need(currentHtmlHash === receipt.buildHash, 'Workspace H5 does not match the current build receipt');
const candidateIndexRel = `${candidateRel}/index.html`;
need(await hashRel(candidateIndexRel) === receipt.buildHash, 'Delivered H5 candidate is missing or stale');
const candidateReceiptResult = await readJson(`${candidateRel}/build-receipt-v3.json`);
checkIdentity(candidateReceiptResult.value, 'delivered build receipt', receipt, { targetRequired: false });
need(candidateReceiptResult.value.attempt === receipt.attempt && candidateReceiptResult.value.buildHash === receipt.buildHash && candidateReceiptResult.value.workspace === WORKSPACE && candidateReceiptResult.value.route === 'formal-fixer', 'Delivered receipt is missing or stale');
const candidateSummary = await readJson(`${candidateRel}/qa-summary-v3.json`);
need(sha(candidateSummary.bytes) === summaryResult.sha256, 'Delivered QA summary differs from the current run summary');
for (const name of ['qa-report-v3.json', 'build-report-v3.json', 'qa-evidence-manifest-v3.json']) {
  const source = await readBytes(`${RUN_REL}/${name}`);
  const delivered = await readBytes(`${candidateRel}/${name}`);
  need(sha(source) === sha(delivered), `Delivered report copy is stale: ${name}`);
}

const downloadResult = await readJson(`${candidateRel}/download-manifest-v3.json`);
const downloadManifest = downloadResult.value;
need(downloadManifest.targetGame === GAME && downloadManifest.workspace === WORKSPACE, 'Download manifest target mismatch');
need(downloadManifest.attempt === receipt.attempt && downloadManifest.buildHash === receipt.buildHash && downloadManifest.releaseReady === false, 'Download manifest identity/readiness mismatch');
const packageResult = await readJson(`${candidateRel}/package-manifest-v3.json`);
const packageManifest = packageResult.value;
need(packageManifest.targetGame === GAME && packageManifest.runId === RUN_ID && packageManifest.attempt === receipt.attempt && packageManifest.buildHash === receipt.buildHash && packageManifest.releaseReady === false && (packageManifest.workspace === undefined || packageManifest.workspace === WORKSPACE), 'Package manifest is stale or falsely release-ready');
need(downloadManifest.packageManifest?.path === 'package-manifest-v3.json' && downloadManifest.packageManifest.sha256 === packageResult.sha256, 'Package manifest hash binding mismatch');
const zipName = text(downloadManifest.archive?.path);
need(zipName && path.basename(zipName) === zipName && zipName.endsWith('.zip'), 'Download manifest archive path is invalid');
const zipRel = `${candidateRel}/${relSafe(zipName)}`;
const zipHash = await hashRel(zipRel);
need(zipHash === downloadManifest.archive.sha256, 'Delivered H5 ZIP hash mismatch');
need(packageManifest.includedFiles?.some((item) => item.path === 'index.html' && item.sha256 === receipt.buildHash), 'ZIP package manifest does not bind the current H5');
need(packageManifest.includedFiles?.some((item) => item.path === 'qa-summary-v3.json' && item.sha256 === summaryResult.sha256), 'ZIP package manifest does not bind the current QA summary');

const factoryPath = `${RUN_REL}/evidence/v3-engineering/factory-checks-final.json`;
const factoryResult = await readJson(factoryPath);
const factoryChecks = factoryResult.value;
checkIdentity(factoryChecks, 'factory checks', receipt);
need(isObject(factoryChecks.pelican?.unitTests) && isObject(factoryChecks.pelican?.lint) && isObject(factoryChecks.pelican?.typecheck), 'Factory Pelican check sections are incomplete');
const unitTests = factoryChecks.pelican.unitTests;
need(Number.isInteger(unitTests.passed) && Number.isInteger(unitTests.total) && unitTests.total > 0 && unitTests.total >= unitTests.passed && text(unitTests.status), 'Factory unit-test counts/status are malformed');
need(unitTests.passed === unitTests.total && status(unitTests.status) === 'PASS', 'Final factory check must show all Pelican rule tests passing');
need(Array.isArray(factoryChecks.fullRepositoryChecks) && factoryChecks.fullRepositoryChecks.length > 0, 'Full-repository checks are missing');
const fullCheckEvidence = [];
for (const item of factoryChecks.fullRepositoryChecks) {
  const rawPath = text(item.path);
  const rawHash = text(item.sha256);
  if (rawPath) {
    const normalizedPath = normalizeRunEvidencePath(rawPath, `Full-repository check ${item.command ?? 'command'} evidence path`);
    const actualHash = await hashRel(normalizedPath);
    if (rawHash) need(SHA256.test(rawHash) && actualHash === rawHash, `Full-repository check evidence hash mismatch: ${normalizedPath}`);
    fullCheckEvidence.push({ command: item.command, path: normalizedPath, sha256: actualHash });
  } else if (rawHash) need(SHA256.test(rawHash), `Invalid full-repository evidence hash without a path: ${rawHash}`);
}
for (const [label, item] of [['lint', factoryChecks.pelican.lint], ['typecheck', factoryChecks.pelican.typecheck]]) need(status(item.status) === 'PASS', `Factory ${label} is not PASS`);

async function currentReport(kind, engine, label = `${kind}/${engine}`) {
  const item = summary.reports.find((r) => r.kind === kind && r.engine === engine);
  need(item && item.status === 'PASS' && isCurrentAttemptPath(item.path), `${label} is not a current passing report`);
  need(manifestByPath.get(item.path) === item.sha256, `${label} is not manifest-bound`);
  const result = await readJson(`${RUN_REL}/${item.path}`);
  need(sha(result.bytes) === item.sha256, `${label} hash mismatch`);
  checkIdentity(result.value, label, receipt);
  return { ...result, item };
}

const experience = {};
for (const engine of ['webkit', 'chromium']) {
  const loaded = await currentReport('experience', engine);
  const report = loaded.value;
  need(report.passed === true && report.normalInputOnly === true && report.stateInjection === false && Array.isArray(report.errors) && report.errors.length === 0, `Experience/${engine} is not natural-input PASS`);
  for (const name of [
    'first-catch-under-three-seconds', 'first-gold-before-ten-seconds', 'jump-gold-route-signalled-with-safe-detour',
    'natural-jump-gold-advances-mastery', 'natural-three-star-settlement', 'real-personal-best-recorded',
    'safe-detour-does-not-require-jump', 'mastery-saved-and-visible-on-route',
  ]) passedCheck(report, name, `Experience/${engine}`);
  experience[engine] = report;
}

const experienceMetrics = {};
for (const engine of ['webkit', 'chromium']) {
  const report = experience[engine];
  const catchEvidence = passedCheck(report, 'first-catch-under-three-seconds', `Experience/${engine}`).evidence;
  const catchEvent = eventList(catchEvidence).find((event) => event.type === 'fish-caught' && event.first === true);
  const catchSeconds = finiteNumber(catchEvent?.at ?? catchEvidence?.elapsed, `${engine} first catch seconds`);
  const goldEvidence = passedCheck(report, 'first-gold-before-ten-seconds', `Experience/${engine}`).evidence;
  const goldSeconds = finiteNumber(goldEvidence?.at ?? eventList(goldEvidence).find((event) => event.type === 'fish-caught' && event.golden === true)?.at, `${engine} first gold seconds`);
  need(catchSeconds < 3 && goldSeconds < 10, `${engine} first catch/gold runtime threshold is false`);
  const jumped = passedCheck(report, 'natural-jump-gold-advances-mastery', `Experience/${engine}`).evidence;
  const jumpedEvents = eventList(jumped);
  const jumpedBarrier = jumpedEvents.find((event) => event.type === 'barrier-cleared' && event.jumped === true);
  const earnedJumpGold = jumpedEvents.find((event) => event.type === 'fish-caught' && event.golden === true && event.bonus === true && event.objectId?.includes('jump-'));
  need(jumpedBarrier && earnedJumpGold && earnedJumpGold.at >= jumpedBarrier.at, `${engine} actual jumped barrier and earned bonus-gold event are not linked`);
  const stars = jumped.save?.stars?.[0];
  need(Number.isInteger(stars) && stars >= 3, `${engine} natural jump route did not record three stars`);
  const bestEvidence = passedCheck(report, 'mastery-saved-and-visible-on-route', `Experience/${engine}`).evidence;
  const recordedBest = passedCheck(report, 'real-personal-best-recorded', `Experience/${engine}`).evidence;
  need(isObject(bestEvidence.best) && Number.isFinite(bestEvidence.best.fish) && Number.isFinite(bestEvidence.best.gold) && Number.isFinite(bestEvidence.best.jumps), `${engine} saved personal-best evidence is missing`);
  need(JSON.stringify(bestEvidence.best) === JSON.stringify(recordedBest) && JSON.stringify(bestEvidence.best) === JSON.stringify(jumped.save?.best?.[0]), `${engine} route card, earned save, and personal-best evidence disagree`);
  const detour = passedCheck(report, 'safe-detour-does-not-require-jump', `Experience/${engine}`).evidence;
  const detourEvents = eventList(detour);
  const detourBonus = detourEvents.find((event) => event.type === 'fish-caught' && event.golden === true && event.bonus === true);
  const detourHasJump = detourEvents.some((event) => event.type === 'jump' || event.type === 'jump-buffered' || (event.type === 'barrier-cleared' && event.jumped === true));
  need(['running', 'finished'].includes(detour.phase) && (detour.phase !== 'finished' || detour.reason === 'complete') && !detourHasJump && detourBonus, `${engine} safe route or non-jump bonus-fish evidence is missing`);
  const atThirty = jumpedEvents.filter((event) => Number.isFinite(event.at) && event.at <= 30);
  const fishAtThirty = atThirty.filter((event) => event.type === 'fish-caught').at(-1)?.count ?? 0;
  const goldAtThirty = atThirty.filter((event) => event.type === 'fish-caught' && event.golden === true).length;
  const jumpsAtThirty = atThirty.filter((event) => event.type === 'barrier-cleared' && event.jumped === true).length;
  need(fishAtThirty > 0 && atThirty.length > 0, `${engine} natural first-30-second event window is missing`);
  const firstStageCompletion = jumpedEvents.find((event) => event.type === 'complete');
  const firstStageSeconds = finiteNumber(firstStageCompletion?.at, `${engine} first-stage completion seconds`);
  need(firstStageSeconds >= 30 && firstStageSeconds <= 60, `${engine} first-stage evidence does not cover the requested 30–60 second window`);
  experienceMetrics[engine] = {
    catchSeconds, goldSeconds, jumpSeconds: earnedJumpGold.at, jumpGoldObject: earnedJumpGold.objectId, stars,
    fish: jumped.count, gold: jumped.gold, jumps: jumped.jumpedBarriers,
    best: bestEvidence.best, safeFish: detour.count, safeGold: detour.gold,
    safeBonusObject: detourBonus.objectId, safeRoutePhase: detour.phase,
    safeRouteCompleted: detour.phase === 'finished' && detour.reason === 'complete',
    fishAtThirty, goldAtThirty, jumpsAtThirty, firstStageSeconds,
  };
}

const riskEvidence = [];
for (const engine of ['webkit', 'chromium']) {
  const item = summary.riskEvidence?.find((entry) => entry.engine === engine);
  need(item && item.status === 'PASS' && item.replayObserved === true && item.targetsByLevel?.length === 5 && item.settlements?.length === 5, `Current ${engine} risk metrics do not cover five levels and replay`);
  need(isCurrentAttemptPath(item.path) && manifestByPath.get(item.path) === item.sha256, `Current ${engine} risk report is stale or unbound`);
  const raw = await currentReport('risk', engine);
  need(raw.item.path === item.path && raw.item.sha256 === item.sha256, `Risk/${engine} summary path/hash mismatch`);
  const report = raw.value;
  need(report.engine === engine && report.passed === true && report.normalInputOnly === true && report.stateInjection === false && report.errors?.length === 0, `Risk/${engine} is not a natural-input pass`);
  need(Array.isArray(report.levels) && report.levels.length === 5, `Risk/${engine} raw report does not contain all five level metric records`);
  const levels = new Set(item.targetsByLevel.map((entry) => entry.level));
  need(levels.size === 5 && [1, 2, 3, 4, 5].every((level) => levels.has(level)), `Risk/${engine} missing a level metric`);
  need(item.settlements.every((settlement) => settlement.status === 'PASS' && settlement.completionEvent === true && settlement.earnedSave === true), `Risk/${engine} settlement evidence is incomplete`);
  const levelMetrics = report.levels.map((level) => {
    const id = level.id;
    need(Number.isInteger(id) && id >= 1 && id <= 5 && Array.isArray(level.targetEpisodes) && level.targetEpisodes.length > 0, `Risk/${engine} level ${id} has no targeted natural-risk episodes`);
    need(level.terminal?.reason === 'complete' && Number.isFinite(level.terminal.count) && Number.isFinite(level.terminal.gold) && Number.isFinite(level.terminal.jumpedBarriers) && Number.isFinite(level.terminal.elapsed), `Risk/${engine} level ${id} is missing natural settlement metrics`);
    need(Number.isInteger(level.terminal.save?.stars?.[id - 1]) && level.terminal.save.stars[id - 1] >= 0, `Risk/${engine} level ${id} is missing its earned star save metric`);
    need(Number.isFinite(level.performance?.frameCount) && Number.isFinite(level.performance?.meanFPS) && Number.isFinite(level.performance?.p95FrameMs), `Risk/${engine} level ${id} is missing desktop browser runtime metrics`);
    return {
      level: id, name: level.name, weather: level.weather, targets: level.targetEpisodes.length,
      fish: level.terminal.count, gold: level.terminal.gold, jumps: level.terminal.jumpedBarriers,
      elapsed: level.terminal.elapsed, stars: level.terminal.save.stars[id - 1],
      meanFPS: level.performance.meanFPS, p95FrameMs: level.performance.p95FrameMs,
    };
  }).sort((a, b) => a.level - b.level);
  need(levelMetrics.length === 5 && levelMetrics.every((metric, index) => metric.level === index + 1), `Risk/${engine} raw metrics do not cover levels 1–5 exactly once`);
  riskEvidence.push({ engine, targetCount: item.targetCount, levels: levelMetrics, settlements: item.settlements, replayObserved: item.replayObserved });
}

const feelReports = {};
let nativePoseFrameCount = 0;
for (const engine of ['webkit', 'chromium']) {
  const loaded = await currentReport('feel-state', engine);
  const report = loaded.value;
  need(report.passed === true && report.normalInputOnly === true && report.stateInjection === false && report.errors?.length === 0, `Feel-state/${engine} is not a natural-input pass`);
  need(Array.isArray(report.frames) && report.frames.length > 0, `Feel-state/${engine} lacks native pose frames`);
  for (const frame of report.frames) {
    const pose = frame.after?.render?.pose;
    need(Array.isArray(pose?.frontSteeringMatrix) && pose.frontSteeringMatrix.length === 16 && pose.frontSteeringMatrix.every(Number.isFinite), `Feel-state/${engine} native fork matrix is missing/non-finite`);
    need(Array.isArray(pose?.headRotation) && pose.headRotation.length === 3 && pose.headRotation.every(Number.isFinite), `Feel-state/${engine} native head rotation is missing/non-finite`);
    need(Array.isArray(pose?.bodyRotation) && pose.bodyRotation.length === 3 && pose.bodyRotation.every(Number.isFinite), `Feel-state/${engine} native body bank is missing/non-finite`);
    need(pose.requested && Number.isFinite(pose.requested.yaw) && Number.isFinite(pose.requested.lean), `Feel-state/${engine} requested yaw/bank is not finite`);
    nativePoseFrameCount += 1;
  }
  feelReports[engine] = report;
}

const comparisonReports = {};
const comparisonNotes = [];
const comparisonVideoEvidence = [];
const comparisonFrameEvidence = [];
const comparisonSheetEvidence = [];
const comparisonProvenanceEvidence = [];
const comparisonSourceReportEvidence = [];
const comparisonInputSemantics = new Map();
const comparisonFramePathsSeen = new Set();
let comparisonTimingCaveat = '';
let comparisonFrameReferenceCount = 0;
for (const engine of ['webkit', 'chromium']) {
  const rel = `${currentAttempt}/feel-comparison-${engine}/report.json`;
  const loaded = await readJson(rel);
  const report = loaded.value;
  checkIdentity(report, `feel comparison/${engine}`, receipt);
  need(report.normalInputOnly === true && report.stateInjection === false, `Feel comparison/${engine} does not use normal input`);
  need(report.buildHash === receipt.buildHash, `Feel comparison/${engine} is not bound to the current H5 build`);
  const variants = new Set((report.results ?? []).filter((item) => item.engine === engine).map((item) => item.variant));
  need(['PR10', 'PR13', 'V3'].every((variant) => variants.has(variant)), `Feel comparison/${engine} does not include PR10, PR13 and V3`);
  const currentResults = report.results.filter((item) => item.engine === engine);
  need(currentResults.length === 3 && variants.size === 3, `Feel comparison/${engine} must have exactly one result per source variant`);
  need(currentResults.every((item) => item.normalInputOnly === true && item.stateInjection === false && Array.isArray(item.errors) && item.errors.length === 0), `Feel comparison/${engine} includes injected state or errors`);
  need(currentResults.every((item) => typeof item.cameraMode === 'string' && item.cameraMode.length > 0), `Feel comparison/${engine} lacks camera semantics`);
  need(/continuous|held/iu.test(report.note ?? '') && /one-lane|single-lane/iu.test(report.note ?? ''), `Feel comparison/${engine} does not document changed control semantics`);
  comparisonNotes.push(report.note);
  const provenanceRel = `${currentAttempt}/comparison-frames/provenance.json`;
  const provenanceLoaded = await readJson(provenanceRel);
  const provenance = provenanceLoaded.value;
  checkIdentity(provenance, 'comparison-frame provenance', receipt);
  need(provenance.sourceBuildHash === receipt.buildHash, `Comparison provenance/${engine} is not bound to the current H5`);
  need(Array.isArray(provenance.records) && provenance.records.length === 120, 'Comparison provenance must contain exactly 120 original decoded frame records');
  need(Array.isArray(provenance.contactSheets) && provenance.contactSheets.length === 4, 'Comparison provenance must contain exactly four hash-bound contact sheets');
  need(/capture wall-clock elapsed/iu.test(provenance.clockDefinition?.reportClock ?? '') && /not game elapsed/iu.test(provenance.clockDefinition?.reportClock ?? ''), 'Comparison provenance does not distinguish capture clock from game time');
  need(/approximate/iu.test(provenance.captureOffsetDefinition ?? '') && /unquantified/iu.test(provenance.alignmentCaveat ?? '') && /approx/iu.test(provenance.alignmentQuality ?? ''), 'Comparison provenance omits approximate alignment or unquantified recorder-tail limitations');
  need(/original decoded full frames only/iu.test(provenance.method ?? '') && /no crop/iu.test(provenance.method ?? '') && /proportional full-frame reduction/iu.test(provenance.method ?? ''), 'Comparison provenance omits the original-frame/contact-sheet method');
  comparisonTimingCaveat = `${provenance.clockDefinition.reportClock} ${provenance.captureOffsetDefinition} ${provenance.alignmentCaveat}`;
  if (!comparisonProvenanceEvidence.some((item) => item.path === `${currentAttempt}/comparison-frames/provenance.json`)) comparisonProvenanceEvidence.push({ path: `${currentAttempt}/comparison-frames/provenance.json`, sha256: provenanceLoaded.sha256 });
  const provRows = provenance.records?.filter((record) => record.engine === engine) ?? [];
  const variantCounts = Object.fromEntries(['PR10', 'PR13', 'V3'].map((variant) => [variant, provRows.filter((record) => record.variant === variant).length]));
  need(provRows.length === 60 && variantCounts.PR10 === 6 && variantCounts.PR13 === 6 && variantCounts.V3 === 48, `Comparison frame provenance/${engine} must contain exactly 6 PR10, 6 PR13 and 48 V3 source frames`);
  const sourceVideosSeen = new Set();
  const sourceReportsSeen = new Set();
  for (const record of provRows) {
    const variant = text(record.variant);
    need(['PR10', 'PR13', 'V3'].includes(variant), `Comparison provenance/${engine} has an unknown variant`);
    const expectedSourceReport = `${currentAttempt}/feel-comparison-${engine}/${variant}/report.json`;
    const sourceReportPath = requireRepoCurrentAttemptPath(record.sourceReport?.path, `Comparison source report ${variant}/${engine}`);
    need(sourceReportPath.repoRelative === expectedSourceReport, `Comparison source report path mismatch for ${variant}/${engine}`);
    const sourceReport = await readJson(sourceReportPath.repoRelative);
    need(sourceReport.sha256 === record.sourceReport.sha256, `Comparison source report hash mismatch for ${variant}/${engine}`);
    need(sourceReport.value.engine === engine && sourceReport.value.variant === variant && sourceReport.value.normalInputOnly === true && sourceReport.value.stateInjection === false && sourceReport.value.errors?.length === 0, `Comparison source report ${variant}/${engine} is not a clean normal-input run`);
    if (variant === 'V3') need(sourceReport.value.sourceHtmlSha256 === receipt.buildHash, `Comparison V3 source report/${engine} is not bound to the current H5`);
    const compositeResult = currentResults.find((item) => item.variant === variant);
    need(compositeResult && compositeResult.cameraMode === sourceReport.value.cameraMode, `Comparison source/composite camera semantics disagree for ${variant}/${engine}`);
    const semantics = text(record.inputSemantics);
    need(semantics.length > 0, `Comparison provenance lacks input semantics for ${variant}/${engine}`);
    comparisonInputSemantics.set(`${variant}/${engine}`, semantics);
    if (!sourceReportsSeen.has(sourceReportPath.repoRelative)) {
      sourceReportsSeen.add(sourceReportPath.repoRelative);
      comparisonSourceReportEvidence.push({ variant, engine, path: sourceReportPath.repoRelative, sha256: sourceReport.sha256 });
    }

    const sourceVideoPath = requireRepoCurrentAttemptPath(record.sourceVideo?.path, `Comparison source video ${variant}/${engine}`);
    need(sourceVideoPath.runRelative.startsWith(`${currentAttemptRunRelative}/feel-comparison-${engine}/${variant}/`) && path.extname(sourceVideoPath.repoRelative) === '.webm', `Comparison source video path has a mismatched engine/variant for ${variant}/${engine}`);
    need(record.sourceVideo.mime === 'video/webm' && Number.isInteger(record.sourceVideo.bytes) && record.sourceVideo.bytes > 0 && SHA256.test(record.sourceVideo.sha256 ?? ''), `Comparison source-video metadata is incomplete for ${variant}/${engine}`);
    const sourceVideoBytes = await readBytes(sourceVideoPath.repoRelative);
    const videoHash = sha(sourceVideoBytes);
    need(videoHash === record.sourceVideo.sha256, `Comparison source video hash mismatch for ${variant}/${engine}`);
    need(sourceVideoBytes.length === record.sourceVideo.bytes, `Comparison source video byte length mismatch for ${variant}/${engine}`);
    if (!sourceVideosSeen.has(sourceVideoPath.repoRelative)) {
      sourceVideosSeen.add(sourceVideoPath.repoRelative);
      comparisonVideoEvidence.push({ variant, engine, path: sourceVideoPath.repoRelative, sha256: videoHash });
    }

    const framePath = requireRepoCurrentAttemptPath(record.frame?.path, `Comparison frame ${variant}/${engine}`);
    need(framePath.runRelative.startsWith(`${currentAttemptRunRelative}/comparison-frames/`) && path.extname(framePath.repoRelative) === '.png', `Comparison frame path is outside current attempt frames for ${variant}/${engine}`);
    need(!comparisonFramePathsSeen.has(framePath.repoRelative), `Comparison frame path is duplicated across the full provenance set: ${framePath.repoRelative}`);
    comparisonFramePathsSeen.add(framePath.repoRelative);
    need(record.frame.mime === 'image/png' && Number.isInteger(record.frame.bytes) && record.frame.bytes > 0 && SHA256.test(record.frame.sha256 ?? ''), `Comparison frame metadata is incomplete for ${variant}/${engine}`);
    comparisonFrameReferenceCount += 1;
    const frameBytes = await readBytes(framePath.repoRelative);
    const frameHash = sha(frameBytes);
    need(frameHash === record.frame.sha256, `Comparison frame hash mismatch for ${variant}/${engine}`);
    if (Number.isInteger(record.frame.bytes)) need(frameBytes.length === record.frame.bytes, `Comparison frame byte length mismatch for ${variant}/${engine}`);
    comparisonFrameEvidence.push({ variant, engine, path: framePath.repoRelative, sha256: frameHash });
    need(record.captureOffsetUncertainty?.status === 'unquantified', `Comparison ${variant}/${engine} must retain the unquantified recorder-tail caveat`);
  }
  const sheets = (provenance.contactSheets ?? []).filter((sheet) => sheet.engine === engine);
  need(sheets.length === 2, `Comparison provenance/${engine} must bind one comparison strip and one V3 temporal grid`);
  for (const [role, expectedName] of [['comparison-strip', `comparison-strip-${engine}.png`], ['temporal-grid', `temporal-grid-${engine}-V3.png`]]) {
    const matches = sheets.filter((sheet) => sheet.role === role);
    need(matches.length === 1, `Comparison provenance/${engine} is missing its ${role} artifact`);
    const sheet = matches[0];
    if (role === 'temporal-grid') need(sheet.variant === 'V3', `Comparison temporal grid/${engine} is not for V3`);
    const sheetPath = requireRepoCurrentAttemptPath(sheet.path, `Comparison ${role}/${engine}`);
    need(sheetPath.runRelative === `${currentAttemptRunRelative}/comparison-frames/${expectedName}`, `Comparison ${role}/${engine} path is not the current engine artifact`);
    need(sheet.mime === 'image/png' && Number.isInteger(sheet.bytes) && SHA256.test(sheet.sha256 ?? ''), `Comparison ${role}/${engine} metadata is incomplete`);
    const sheetBytes = await readBytes(sheetPath.repoRelative);
    need(sha(sheetBytes) === sheet.sha256 && sheetBytes.length === sheet.bytes, `Comparison ${role}/${engine} hash or byte length mismatch`);
    comparisonSheetEvidence.push({ engine, role, path: sheetPath.repoRelative, sha256: sheet.sha256 });
  }
  comparisonReports[engine] = report;
}
need(comparisonFrameReferenceCount === 120 && comparisonFramePathsSeen.size === 120 && comparisonFrameEvidence.length === 120 && comparisonSheetEvidence.length === 4, 'Comparison visual evidence must include all 120 unique source frames plus four hash-bound contact sheets');
const comparisonNote = [...new Set(comparisonNotes)].join(' ');
const comparisonFrameRetentionNote = `provenance 引用的 ${comparisonFrameReferenceCount} 张独立逐帧 PNG 均保留并已逐项校验。`;
for (const variant of ['PR10', 'PR13', 'V3']) need(comparisonInputSemantics.get(`${variant}/webkit`) === comparisonInputSemantics.get(`${variant}/chromium`), `Comparison ${variant} input semantics differ unexpectedly between engines`);
const comparisonInputSummary = ['PR10', 'PR13', 'V3'].map((variant) => `${variant}: WebKit ${comparisonInputSemantics.get(`${variant}/webkit`) ?? '未提供'} / Chromium ${comparisonInputSemantics.get(`${variant}/chromium`) ?? '未提供'}`).join('；');

const levelSourceRel = `${WORKSPACE_REL}/source/pelican-bike/src/levels.mjs`;
const levelSourceBytes = await readBytes(levelSourceRel);
const levelSource = levelSourceBytes.toString('utf8');
const feelSourceRel = `${WORKSPACE_REL}/source/pelican-bike/src/feel.mjs`;
const feelSourceBytes = await readBytes(feelSourceRel);
const feelSource = feelSourceBytes.toString('utf8');
need(/if\s*\(\s*!run\s*\)\s*\{[\s\S]*?yaw\s*:\s*0[\s\S]*?return\s*;/u.test(feelSource), 'Cold-menu pose reset does not initialize yaw to a finite value');
need(/state\.yaw\s*=\s*smooth\(state\.yaw\s*\?\?\s*0\s*,/u.test(feelSource), 'Native pose update does not fail closed on an unset yaw');
const feelSourceSha = sha(feelSourceBytes);
const headGeometryRel = `${WORKSPACE_REL}/source/pelican-bike/src/pelican.js`;
const headGeometrySha = await hashRel(headGeometryRel);
const spacingMatch = levelSource.match(/for\s*\(\s*let\s+x\s*=\s*15\s*,\s*i\s*=\s*0\s*;\s*x\s*<\s*d\.distance\s*-\s*10\s*;\s*x\s*\+=\s*([\d.]+)/u);
need(spacingMatch, 'Fish cadence could not be read from current source');
const fishSpacingMeters = Number(spacingMatch[1]);
need(Number.isFinite(fishSpacingMeters) && fishSpacingMeters === 16, 'Current fish cadence differs from the requested 16 m evidence check');
const stageRegex = /\{id:(\d+),name:'([^']+)',subtitle:'([^']+)',mastery:\{jumps:(\d+)\},distance:(\d+),speed:([\d.]+),seconds:(\d+),goal:\{count:(\d+),gold:(\d+)\},hour:([\d.]+),weather:'([^']+)',reward:(\d+),rows:(\[.*?\])\}/gu;
const stages = [...levelSource.matchAll(stageRegex)].map((match) => ({
  id: Number(match[1]), name: match[2], subtitle: match[3], jumps: Number(match[4]), distance: Number(match[5]),
  speed: Number(match[6]), seconds: Number(match[7]), targetFish: Number(match[8]), targetGold: Number(match[9]),
  hour: Number(match[10]), weather: match[11], obstacleRows: (match[12].match(/\[/gu) ?? []).length - 1,
}));
need(stages.length === 5 && stages.every((stage, index) => stage.id === index + 1), 'Current level source does not define exactly five parseable stages');
const sourceSha = sha(levelSourceBytes);
const experienceContractResult = await readJson(`${RUN_REL}/product-experience-contract.json`);
need(experienceContractResult.value.targetGame === GAME && experienceContractResult.value.targetWorkspace === WORKSPACE, 'Product experience contract target mismatch');
need(experienceContractResult.value.features?.some((feature) => feature.id === 'replay-mastery-records'), 'Replay mastery is absent from the current product contract');
const continuationResult = await readJson(`${RUN_REL}/v3-continuation.json`);
const sourceRevision = text(continuationResult.value.sourceRevision);
need(sourceRevision.length > 0, 'Original source revision is missing from the continuation receipt');
const experienceAuditRel = `${RUN_REL}/evidence/v3-engineering/experience-audit-final${receipt.attempt}.json`;
const experienceAuditResult = await readJson(experienceAuditRel);
const experienceAudit = experienceAuditResult.value;
need(experienceAudit.schemaVersion === 2 && experienceAudit.targetGame === GAME && experienceAudit.workspace === WORKSPACE && experienceAudit.attempt === receipt.attempt && experienceAudit.buildHash === receipt.buildHash, 'Independent experience audit is stale or belongs to another build');
need(text(experienceAudit.auditStatus).length > 0 && experienceAudit.scopeOfVerdict?.finalApproval === false, 'Independent experience audit is missing its bounded/no-release verdict');
need(experienceAudit.iterationBaseline?.authorizedSourceRevision === sourceRevision, 'Independent experience audit source revision does not match the current continuation receipt');
need(Array.isArray(experienceAudit.sourceArtifacts) && experienceAudit.sourceArtifacts.length > 0, 'Independent experience audit has no source SHA bindings');
const auditSourceHashes = new Map();
const auditSourceRows = [];
for (const source of experienceAudit.sourceArtifacts) {
  need(isObject(source) && path.isAbsolute(text(source.path)) && SHA256.test(source.sha256 ?? '') && text(source.role), 'Independent experience audit source artifact is malformed');
  const absolute = path.resolve(source.path);
  const relative = path.relative(REPO, absolute).split(path.sep).join('/');
  need(relative && relative !== '..' && !relative.startsWith('../') && !path.isAbsolute(relative), `Independent audit source path escapes the target repository: ${source.path}`);
  const safeRelative = relSafe(relative);
  const actualHash = await hashRel(safeRelative);
  need(actualHash === source.sha256, `Independent audit source SHA mismatch: ${safeRelative}`);
  if (auditSourceHashes.has(safeRelative)) need(auditSourceHashes.get(safeRelative) === actualHash, `Independent audit repeats a source path with conflicting SHA: ${safeRelative}`);
  auditSourceHashes.set(safeRelative, actualHash);
  if (source.role === 'exact current H5 build' || /current V3 (five-stage routes|run loop|barrier bonus|hazard forecast|lane response|first-minute cues|renderer)/u.test(source.role) || /current attempt20 responsive compact layout/u.test(source.role)) {
    auditSourceRows.push([source.role, safeRelative, actualHash]);
  }
}
const auditH5Rel = `${RUN_REL}/attempts/attempt-${receipt.attempt}/index.html`;
need(auditSourceHashes.get(auditH5Rel) === receipt.buildHash, 'Independent experience audit does not bind the exact current attempt H5 SHA');
for (const relative of [
  `${WORKSPACE_REL}/source/pelican-bike/src/levels.mjs`,
  `${WORKSPACE_REL}/source/pelican-bike/src/adventure.mjs`,
  `${WORKSPACE_REL}/source/pelican-bike/src/engagement.mjs`,
  `${WORKSPACE_REL}/source/pelican-bike/src/safety.mjs`,
  `${WORKSPACE_REL}/source/pelican-bike/src/feel.mjs`,
  `${WORKSPACE_REL}/source/pelican-bike/src/coast-ui.mjs`,
  `${WORKSPACE_REL}/source/pelican-bike/src/main.js`,
]) need(auditSourceHashes.has(relative), `Independent experience audit omits current source SHA: ${relative}`);
const auditConcernIds = [
  'jump-benefit-and-safe-detour', 'first-minute-catch-avoid-success-reward', 'five-stage-operation-fishing-rain-night',
  'replay-three-stars-best-fish-routes-feedback', 'pacing-gaps-and-risk-reward',
];
need(Array.isArray(experienceAudit.concerns) && experienceAudit.concerns.length === auditConcernIds.length, 'Independent experience audit must cover all five required concerns');
const concernById = new Map(experienceAudit.concerns.map((concern) => [concern?.id, concern]));
need(auditConcernIds.every((id) => concernById.has(id)), 'Independent experience audit has a missing or renamed concern');
for (const id of auditConcernIds) {
  const concern = concernById.get(id);
  for (const field of ['changes', 'observed', 'inferred', 'unknowns']) need(Array.isArray(concern[field]) && concern[field].length > 0, `Independent audit ${id} must keep ${field} separate and non-empty`);
}
const auditStages = experienceAudit.stageComparison?.stages;
need(Array.isArray(auditStages) && auditStages.length === 5 && experienceAudit.stageComparison.fishCadenceMeters === fishSpacingMeters, 'Independent audit stage comparison is incomplete or differs from current fish cadence');
need(auditStages.every((stage, index) => stage.id === index + 1 && Array.isArray(stage.fishLanePattern) && stage.fishLanePattern.length === 8 && stage.fishLanePattern.every((lane) => Number.isInteger(lane) && lane >= 0 && lane <= 2) && text(stage.operation)), 'Independent audit does not bind five real fish-lane patterns and route decisions');
need(experienceAudit.firstMinuteMeasurements?.normalInputOnly === true && experienceAudit.firstMinuteMeasurements?.stateInjection === false && experienceAudit.firstMinuteMeasurements?.engines?.length === 2, 'Independent first-minute audit is not a two-engine normal-input observation');
for (const item of experienceAudit.firstMinuteMeasurements.engines) {
  need(['webkit', 'chromium'].includes(item.engine), `Independent first-minute audit has an unknown engine: ${item.engine}`);
  need(Number.isFinite(item.firstCatch?.gameSeconds) && item.firstCatch.gameSeconds < 3 && Number.isFinite(item.firstOrdinaryGold?.gameSeconds) && item.firstOrdinaryGold.gameSeconds < 10, `Independent first-minute audit lacks actual first-catch/gold thresholds for ${item.engine}`);
  need(Number.isFinite(item.firstSuccessfulFinish?.gameSeconds) && item.firstSuccessfulFinish.gameSeconds >= 30 && item.firstSuccessfulFinish.gameSeconds <= 60, `Independent first-minute audit lacks an actual 30–60 second completion for ${item.engine}`);
  need(Math.abs(item.firstCatch.gameSeconds - experienceMetrics[item.engine].catchSeconds) < 0.1 && Math.abs(item.firstOrdinaryGold.gameSeconds - experienceMetrics[item.engine].goldSeconds) < 0.1 && Math.abs(item.firstSuccessfulFinish.gameSeconds - experienceMetrics[item.engine].firstStageSeconds) < 0.1, `Independent first-minute audit disagrees with ${item.engine} natural event evidence`);
}
const auditedReplay = experienceAudit.replayMeasurements?.jumpRewardRuns;
function auditedStageStarTotal(entry, label) {
  need(Array.isArray(entry?.starsPerStage) && entry.starsPerStage.length === 5 && entry.starsPerStage.every((stars) => Number.isInteger(stars) && stars >= 0 && stars <= 3), `Independent audit ${label} does not contain five valid stage-star measurements`);
  const total = entry.starsPerStage.reduce((sum, stars) => sum + stars, 0);
  need(Number.isInteger(entry.totalStars) && entry.totalStars === total, `Independent audit ${label} total does not match its stage measurements`);
  return total;
}
const auditedJumpStarTotals = {
  chromium: auditedStageStarTotal(auditedReplay?.chromium, 'Chromium jump replay'),
  webkit: auditedStageStarTotal(auditedReplay?.webkit, 'WebKit jump replay'),
};
need(Math.abs(auditedJumpStarTotals.chromium - auditedJumpStarTotals.webkit) === 1, 'Independent audit must retain the observed one-star Chromium/WebKit replay difference');
const noJumpReplay = experienceAudit.replayMeasurements?.noJumpFiveStageCampaign;
const noJumpStarTotal = auditedStageStarTotal({ starsPerStage: noJumpReplay?.starsPerStage, totalStars: noJumpReplay?.totalStars }, 'no-jump five-stage replay');
need(Number.isInteger(noJumpReplay?.maxStars) && noJumpReplay.maxStars >= noJumpStarTotal && noJumpReplay.completedStages === 5 && noJumpReplay.replayWithoutFullPageReload === true, 'Independent audit no-jump campaign completion/replay measurements are incomplete');
const auditFindingRows = auditConcernIds.map((id, index) => {
  const concern = concernById.get(id);
  return { index: index + 1, ...concern };
});
const fishLaneRows = auditStages.map((stage) => [stage.id, stage.name, stage.fishLanePattern.map((lane) => ['左', '中', '右'][lane]).join(' → '), stage.operation, stage.observation ?? '—']);
const auditTimelineRows = (experienceAudit.firstMinuteMeasurements.timeline ?? []).map((item) => [fmt(item.gameSeconds, 3), item.event, item.evidence]);
const riskStarTotals = Object.fromEntries(riskEvidence.map((entry) => [entry.engine, entry.levels.reduce((sum, level) => sum + level.stars, 0)]));
const riskStarMaximum = Math.max(...riskEvidence.map((entry) => entry.levels.length * 3));
need(auditedJumpStarTotals.chromium === riskStarTotals.chromium && auditedJumpStarTotals.webkit === riskStarTotals.webkit, 'Independent audit replay stars do not match current natural-risk settlement evidence');
const researchResult = await readJson(`${RUN_REL}/open-source-research-v3.json`);
const research = researchResult.value;
need(research.targetGame === GAME && research.targetWorkspace === WORKSPACE && Array.isArray(research.candidates), 'Open-source reuse research target/schema mismatch');
const reusedCandidates = research.candidates.filter((candidate) => candidate.decision === 'REUSE');
need(reusedCandidates.length > 0, 'No approved low-cost reuse candidate is recorded');
const authorizedSource = reusedCandidates.find((candidate) => candidate.immutableRevision === sourceRevision);
const pinnedThree = reusedCandidates.find((candidate) => /Three\.js/u.test(candidate.name));
need(authorizedSource && pinnedThree, 'Approved source revision or pinned Three.js reuse record is missing');
const reuseSummary = `沿用用户授权源码 revision ${sourceRevision}（${authorizedSource.name}），复用已锁定的 Three.js ${pinnedThree.version ?? pinnedThree.immutableRevision} 和现有 H5/工厂工具；没有新建引擎、后端或服务。复用范围与平台限制以研究记录为准，原生平台和真实广告仍未验证。`;
const levelStats = new Map((summary.levels ?? []).map((level) => [level.level, level]));
need(levelStats.size === 5 && [1, 2, 3, 4, 5].every((level) => levelStats.has(level)), 'Current QA summary does not include all five campaign settlements');
const stageRows = stages.map((stage) => {
  const actual = levelStats.get(stage.id);
  return [stage.id, stage.name, `${stage.distance} m · ${stage.speed} m/s`, `${stage.targetFish} 鱼 / ${stage.targetGold} 金鱼`, `${stage.weather} · ${stage.jumps} 跳 mastery`, `${actual.fish ?? '—'} / ${actual.gold ?? '—'} · ${fmt(actual.elapsedSeconds, 1)}s · ${actual.result ?? '—'}`];
});

const allFullChecks = factoryChecks.fullRepositoryChecks;
const allowedStatuses = new Set(['PASS', 'FAIL', 'BLOCKED', 'PENDING', 'SKIPPED', 'WARN', 'UNKNOWN']);
const checkStatusOf = (item) => {
  const s = status(item?.status);
  return allowedStatuses.has(s) ? s : 'UNKNOWN';
};
const fullCounts = Object.fromEntries([...allowedStatuses].map((s) => [s, 0]));
for (const item of allFullChecks) fullCounts[checkStatusOf(item)] += 1;
const fullRepositoryStatus = fullCounts.FAIL > 0 ? 'FAIL'
  : fullCounts.PASS === allFullChecks.length ? 'PASS'
    : fullCounts.PENDING + fullCounts.BLOCKED > 0 ? 'INCOMPLETE' : 'UNKNOWN';
const fullCheckDisplayRow = (item) => {
  const evidence = fullCheckEvidence.find((row) => row.command === item.command);
  return [item.command ?? '—', checkStatusOf(item), item.summary ?? '—', evidence?.path ?? '—', evidence?.sha256 ?? '—'];
};
const fullRows = allFullChecks.map(fullCheckDisplayRow);
const knownUnrelatedFails = allFullChecks.filter((item) => checkStatusOf(item) === 'FAIL' && (
  item.unrelated === true || item.relatedToTarget === false || /unrelated|not\s+Pelican.*(?:game|test).*evidence|不是鹈鹕游戏测试证据/iu.test(text(`${item.classification ?? item.scope ?? ''} ${item.summary ?? ''}`))
));

const prResult = await readJson(`${RUN_REL}/github-pr-v3.json`);
const ciResult = await readJson(`${RUN_REL}/github-ci-v3.json`);

function normalizeCiState(rawStatus, rawConclusion) {
  const st = status(rawStatus);
  const conclusion = status(rawConclusion);
  if (['QUEUED', 'IN_PROGRESS', 'PENDING', 'REQUESTED', 'WAITING'].includes(st)) return '进行中';
  if (st === 'PASS' || st === 'COMPLETED' || st === 'SUCCESS') {
    if (conclusion === 'SUCCESS') return 'PASS';
    if (conclusion === 'SKIPPED') return 'SKIPPED';
    if (['FAILURE', 'CANCELLED', 'TIMED_OUT', 'ACTION_REQUIRED', 'STARTUP_FAILURE'].includes(conclusion)) return 'FAIL';
  }
  if (conclusion === 'SUCCESS' && ['COMPLETED', 'SUCCESS'].includes(st)) return 'PASS';
  if (conclusion === 'SKIPPED') return 'SKIPPED';
  if (['FAILURE', 'CANCELLED', 'TIMED_OUT', 'ACTION_REQUIRED', 'STARTUP_FAILURE'].includes(conclusion)) return 'FAIL';
  return '未确认';
}
const pr = prResult.value;
const ci = ciResult.value;
need(isObject(pr) && isObject(ci), 'Final v3 PR and dedicated CI receipts must be JSON objects');
const prHead = text(pr.headRefOid);
const ciRun = ci.run;
need(isObject(ciRun), 'Dedicated CI receipt is missing its run object');
const ciHead = text(ciRun.headSha);
const ciSourceReceiptRel = relSafe(ci.normalization?.sourceReceiptPath);
need(ciSourceReceiptRel === `evidence/ci-${ciHead.slice(0, 7)}/receipt.json` && SHA256.test(ci.normalization?.sourceReceiptSha256 ?? ''), 'Dedicated CI normalization does not bind the expected immutable source receipt');
const ciSourceReceiptResult = await readJson(`${RUN_REL}/${ciSourceReceiptRel}`);
const ciSourceReceipt = ciSourceReceiptResult.value;
need(ciSourceReceiptResult.sha256 === ci.normalization.sourceReceiptSha256, 'Dedicated CI source receipt SHA mismatch');
need(ciSourceReceipt.targetGame === GAME && ciSourceReceipt.workspace === WORKSPACE && ciSourceReceipt.buildHash === receipt.buildHash, 'Dedicated CI source receipt target/build identity mismatch');
need(ciSourceReceipt.run?.databaseId === ciRun.databaseId && ciSourceReceipt.run?.headSha === ciHead && normalizeCiState(ciSourceReceipt.run?.status, ciSourceReceipt.run?.conclusion) === 'PASS', 'Dedicated CI normalized run differs from its immutable source receipt');
const sourceCiEngines = new Map((ciSourceReceipt.engines ?? []).map((record) => [text(record.engine).toLowerCase(), record]));
need(sourceCiEngines.size === 2 && sourceCiEngines.has('webkit') && sourceCiEngines.has('chromium'), 'Dedicated CI source receipt must contain exactly one record per engine');
need(/^[0-9a-f]{40}$/iu.test(prHead) && /^[0-9a-f]{40}$/iu.test(ciHead) && prHead === ciHead, 'Dedicated Pelican V3 CI head does not match the captured PR head');
const ciRunId = String(ciRun.databaseId ?? '');
need(/^\d+$/u.test(ciRunId), `Dedicated CI receipt has an invalid run databaseId: ${ciRunId || 'missing'}`);
const ciRunUrl = text(ciRun.url);
let ciRunUrlParsed;
try { ciRunUrlParsed = new URL(ciRunUrl); } catch { fail('Dedicated CI run URL is invalid'); }
need(ciRunUrlParsed.protocol === 'https:' && ciRunUrlParsed.hostname === 'github.com' && new RegExp(`/actions/runs/${ciRunId}(?:/|$)`, 'u').test(ciRunUrlParsed.pathname), 'Dedicated CI run URL is missing or points at a different run');
need(normalizeCiState(ciRun.status, ciRun.conclusion) === 'PASS', 'Dedicated Pelican V3 workflow run is not completed successfully');
need(SHA256.test(ci.buildHash ?? '') && ci.buildHash === receipt.buildHash, 'Dedicated CI receipt does not bind the current delivered H5 build hash');
const statusChecks = Array.isArray(pr?.statusCheckRollup) ? pr.statusCheckRollup.filter(isObject) : [];
const engines = Array.isArray(ci.engines) ? ci.engines.filter(isObject) : [];
need(engines.length === 2, 'Dedicated CI receipt must contain exactly two engine records');
const expectedJobNames = { webkit: 'pelican-browser (webkit)', chromium: 'pelican-browser (chromium)' };
const dedicatedEngines = new Map();
for (const record of engines) {
  const engine = text(record.engine).toLowerCase();
  need(['webkit', 'chromium'].includes(engine) && !dedicatedEngines.has(engine), `Dedicated CI has an unknown or duplicate engine record: ${engine || 'missing'}`);
  dedicatedEngines.set(engine, record);
}
need(dedicatedEngines.has('webkit') && dedicatedEngines.has('chromium'), 'Dedicated CI must contain one WebKit and one Chromium engine record');
const ciRuleCountSummary = summarizeCiRuleCounts(unitTests, [...dedicatedEngines.values()]);
const dedicatedPrRows = new Map();
for (const engine of ['webkit', 'chromium']) {
  const matching = statusChecks.filter((row) => text(row.name) === expectedJobNames[engine]);
  need(matching.length === 1, `Captured PR must contain exactly one ${expectedJobNames[engine]} check`);
  dedicatedPrRows.set(engine, matching[0]);
}
const ciRows = [];
const ciArtifactRows = [];
const ciReportBindings = [];
const ciFacts = {};
function reportBindingPath(rawPath, label, engine) {
  const raw = relSafe(rawPath);
  const runPrefix = `${RUN_REL}/`;
  need(!raw.startsWith('runs/') || raw.startsWith(runPrefix), `${label} points into a different run or game`);
  const runRelative = raw.startsWith(runPrefix) ? raw.slice(runPrefix.length) : raw;
  const fullRelative = `${RUN_REL}/${runRelative}`;
  const expectedCiPrefix = `evidence/ci-${ciHead.slice(0, 7)}/${engine}/attempts/`;
  need(runRelative.startsWith(expectedCiPrefix), `${label} is outside the immutable ${engine} CI artifact snapshot`);
  const tail = runRelative.slice(expectedCiPrefix.length).split('/');
  need(tail.length === 3 && /^attempt-[1-9]\d*$/u.test(tail[0]) && [`qa-campaign-${engine}/report.json`, `experience-${engine}/report.json`].includes(tail.slice(1).join('/')), `${label} is not one of the exact ${engine} CI campaign/experience reports`);
  return { runRelative, fullRelative };
}
for (const engine of ['webkit', 'chromium']) {
  const record = dedicatedEngines.get(engine);
  const sourceRecord = sourceCiEngines.get(engine);
  const ciJob = record.job;
  const prJob = dedicatedPrRows.get(engine);
  need(isObject(ciJob), `CI ${engine} engine record is missing its job`);
  need(sourceRecord && record.job?.databaseId === sourceRecord.job?.databaseId && record.job?.name === sourceRecord.job?.name && record.job?.status === sourceRecord.job?.status && record.job?.conclusion === sourceRecord.job?.conclusion, `Normalized CI ${engine} job differs from its immutable source receipt`);
  need(record.rules?.passed === sourceRecord.rules?.passed && record.rules?.total === sourceRecord.rules?.total && record.rules?.failed === sourceRecord.rules?.failed, `Normalized CI ${engine} rules differ from their immutable source receipt`);
  need(record.campaign?.passedChecks === sourceRecord.campaign?.passedChecks && record.campaign?.totalChecks === sourceRecord.campaign?.totalChecks && record.campaign?.earnedStages === sourceRecord.campaign?.earnedStages?.length, `Normalized CI ${engine} campaign differs from its immutable source receipt`);
  need(record.experience?.passedChecks === sourceRecord.experience?.passedChecks && record.experience?.totalChecks === sourceRecord.experience?.totalChecks, `Normalized CI ${engine} experience differs from its immutable source receipt`);
  need(record.buildHash === sourceRecord.buildHash && JSON.stringify(record.reportBindings) === JSON.stringify(sourceRecord.reportBindings), `Normalized CI ${engine} build/report bindings differ from their immutable source receipt`);
  need(normalizeCiState(record.status, record.conclusion) === 'PASS', `CI ${engine} engine record is not PASS`);
  need(text(ciJob.name) === expectedJobNames[engine], `CI ${engine} job name is not the expected dedicated regression job`);
  need(normalizeCiState(ciJob.status, ciJob.conclusion) === 'PASS', `Pelican V3 ${engine} job is not a completed PASS`);
  const prState = normalizeCiState(prJob.status, prJob.conclusion);
  need(prState === 'PASS', `Captured PR ${engine} check is not a completed PASS`);
  const jobId = String(ciJob.databaseId ?? '');
  need(/^\d+$/u.test(jobId), `Pelican V3 ${engine} job has an invalid databaseId`);
  const url = text(ciJob.html_url);
  let parsedJobUrl;
  try { parsedJobUrl = new URL(url); } catch { fail(`Pelican V3 ${engine} engine job URL is invalid`); }
  need(parsedJobUrl.protocol === 'https:' && parsedJobUrl.hostname === 'github.com' && parsedJobUrl.pathname.includes(`/actions/runs/${ciRunId}/job/${jobId}`), `Pelican V3 ${engine} engine job lacks a direct URL for the current run`);
  const prUrl = text(prJob.detailsUrl ?? prJob.url);
  if (prUrl) {
    let parsedPrUrl;
    try { parsedPrUrl = new URL(prUrl); } catch { fail(`Captured PR ${engine} check URL is invalid`); }
    need(parsedPrUrl.protocol === 'https:' && parsedPrUrl.hostname === 'github.com' && parsedPrUrl.pathname.includes(`/actions/runs/${ciRunId}/job/${jobId}`), `Captured PR ${engine} check does not link to the matching run job`);
  }

  need(record.rules?.passed === ciRuleCountSummary.dedicatedCi.passed && record.rules?.total === ciRuleCountSummary.dedicatedCi.total, `Pelican V3 ${engine} CI rules do not match the immutable dedicated CI rule snapshot`);
  need(record.campaign?.passedChecks === 18 && record.campaign?.totalChecks === 18 && record.campaign?.earnedStages === 5, `Pelican V3 ${engine} CI campaign result is incomplete`);
  need(Array.isArray(record.campaign.reasons) && record.campaign.reasons.length === 5, `Pelican V3 ${engine} CI campaign does not provide five stage reasons`);
  const reasonValues = record.campaign.reasons.map((reason) => isObject(reason) ? text(reason.reason) : text(reason));
  need(reasonValues.every((reason) => reason === 'complete'), `Pelican V3 ${engine} CI has a non-complete campaign stage reason`);
  need(record.experience?.passedChecks === 22 && record.experience?.totalChecks === 22, `Pelican V3 ${engine} CI natural-experience result is incomplete`);
  need(SHA256.test(record.buildHash ?? '') && record.buildHash === receipt.buildHash, `Pelican V3 ${engine} CI record does not bind the current H5 build hash`);
  ciFacts[engine] = {
    earnedStages: record.campaign.earnedStages,
    campaignPassed: record.campaign.passedChecks,
    campaignTotal: record.campaign.totalChecks,
    experiencePassed: record.experience.passedChecks,
    experienceTotal: record.experience.totalChecks,
    rulesPassed: record.rules.passed,
    rulesTotal: record.rules.total,
  };

  const artifact = record.artifact;
  need(isObject(artifact) && text(artifact.name) && text(artifact.path) && SHA256.test(artifact.sha256 ?? ''), `Pelican V3 ${engine} CI artifact metadata is incomplete`);
  const artifactPath = text(artifact.path);
  if (!/^https:\/\//iu.test(artifactPath)) relSafe(artifactPath);
  else {
    let artifactUrl;
    try { artifactUrl = new URL(artifactPath); } catch { fail(`Pelican V3 ${engine} CI artifact URL is invalid`); }
    need(artifactUrl.protocol === 'https:' && artifactUrl.hostname === 'github.com', `Pelican V3 ${engine} CI artifact URL must be hosted on github.com`);
  }
  ciArtifactRows.push([engine, artifact.name, artifactPath, artifact.sha256]);

  need(Array.isArray(record.reportBindings) && record.reportBindings.length > 0, `Pelican V3 ${engine} CI has no report hash bindings`);
  const seenBindings = new Set();
  for (const binding of record.reportBindings) {
    need(isObject(binding) && SHA256.test(binding.sha256 ?? ''), `Pelican V3 ${engine} CI report binding is malformed`);
    const paths = reportBindingPath(binding.path, `Pelican V3 ${engine} CI report binding`, engine);
    need(!seenBindings.has(paths.runRelative), `Pelican V3 ${engine} CI has duplicate report binding: ${binding.path}`);
    seenBindings.add(paths.runRelative);
    const actualHash = await hashRel(paths.fullRelative);
    need(actualHash === binding.sha256, `Pelican V3 ${engine} CI report binding hash mismatch: ${binding.path}`);
    if (manifestByPath.has(paths.runRelative)) need(manifestByPath.get(paths.runRelative) === binding.sha256, `Pelican V3 ${engine} CI report binding disagrees with the evidence manifest: ${binding.path}`);
    ciReportBindings.push({ engine, path: paths.runRelative, sha256: binding.sha256 });
  }
  const safeUrl = parsedJobUrl.href;
  ciRows.push([text(ciJob.name), 'PASS', ciHead, `[打开本次 job](${safeUrl.replaceAll(')', '%29')})`]);
}
const ciOverall = 'PASS（仅 Pelican V3 WebKit + Chromium 专项 job）';
const dedicatedJobNames = new Set(Object.values(expectedJobNames));
const otherPrChecks = statusChecks.filter((job) => !dedicatedJobNames.has(text(job.name))).map((job) => ({
  name: text(job.name) || 'unnamed check', state: normalizeCiState(job.status, job.conclusion),
  url: text(job.detailsUrl ?? job.url),
}));
const otherCiChecks = [];
function ciOtherRow(item, source) {
  let linked = '未提供链接';
  try { const u = new URL(item.url); if (u.protocol === 'https:') linked = `[打开 check](${u.href.replaceAll(')', '%29')})`; } catch { /* no valid direct link */ }
  return [source, item.name, item.state, linked];
}
const otherPrRows = [
  ...otherPrChecks.map((item) => ciOtherRow(item, 'PR snapshot')),
  ...otherCiChecks.map((item) => ciOtherRow(item, 'CI run')),
];
const otherPrFailures = [...otherPrChecks, ...otherCiChecks].filter((item) => item.state === 'FAIL');
const ciStatsRows = ['webkit', 'chromium'].map((engine) => [
  engine, ciFacts[engine].earnedStages, `${ciFacts[engine].campaignPassed}/${ciFacts[engine].campaignTotal}`,
  `${ciFacts[engine].experiencePassed}/${ciFacts[engine].experienceTotal}`,
  `${ciFacts[engine].rulesPassed}/${ciFacts[engine].rulesTotal}`,
]);
const ciRuleCountNote = ciRuleCountSummary.countsMatch
  ? `专项 CI 两引擎的规则测试为 ${ciRuleCountSummary.dedicatedCi.passed}/${ciRuleCountSummary.dedicatedCi.total}，当前本地工厂测试为 ${ciRuleCountSummary.local.passed}/${ciRuleCountSummary.local.total}。`
  : `规则计数按各自证据快照分别列示：当前本地工厂测试 ${ciRuleCountSummary.local.passed}/${ciRuleCountSummary.local.total}；专项 CI 回执在源码 head \`${ciHead}\` 上记录 ${ciRuleCountSummary.dedicatedCi.passed}/${ciRuleCountSummary.dedicatedCi.total}。该 CI 数字不代表它运行了后来新增的本地规则测试。`;

const optionalLinkPaths = [
  'docs/lean-pilot/pelican-feel-v3-20261014/evidence-links-v3.json',
  `${candidateRel}/evidence-links-v3.json`,
  `${RUN_REL}/evidence-links-v3.json`,
  `${RUN_REL}/delivery/evidence-links-v3.json`,
];
let linksResult = null;
let linksPath = null;
for (const linkPath of optionalLinkPaths) { linksResult = await maybeJson(linkPath); if (linksResult) { linksPath = linkPath; break; } }
const publicLinks = [];
function scanUrls(node, prefix = '') {
  if (typeof node === 'string') {
    const raw = node.trim();
    if (/^https:\/\//iu.test(raw)) {
      try { const u = new URL(raw); publicLinks.push({ label: prefix || 'public link', url: u.href }); } catch { /* malformed strings are ignored */ }
    }
    return;
  }
  if (Array.isArray(node)) { node.forEach((item, index) => scanUrls(item, `${prefix}[${index}]`)); return; }
  if (isObject(node)) for (const [key, value] of Object.entries(node)) scanUrls(value, prefix ? `${prefix}.${key}` : key);
}
if (linksResult) {
  need(isObject(linksResult.value), 'evidence-links-v3.json must be a JSON object');
  scanUrls(linksResult.value);
  need(publicLinks.length > 0, 'evidence-links-v3.json has no concrete public HTTPS links');
}

const routeStatus = [
  ['默认浏览器旅程', 'PASS', 'startup → 五关 → 结算 → replay'],
  ['感知门禁', gates['artifacts/perceptual-qa-gate-v3.json'].passed ? 'PASS' : 'FAIL', '独立视觉/可感知证据'],
  ['Runtime 产品旅程', gates['artifacts/runtime-product-gates-v3.json'].passed ? 'PASS' : 'FAIL', '默认入口与 declared loop'],
  ['运行时 wiring', gates['artifacts/runtime-wiring-verification-v3.json'].passed ? 'PASS' : 'FAIL', '入口文件实际连线'],
  ['设备 / 原生 / 广告 / 真人发布门槛', 'BLOCKED', '见 readiness 和 blockers'],
];

const evidenceRows = [];
function addEvidence(label, rel, digest) { evidenceRows.push([label, rel, digest ?? '—']); }
addEvidence('构建 receipt', `${RUN_REL}/build-receipt.json`, receiptResult.sha256);
addEvidence('QA summary', `${RUN_REL}/qa-summary-v3.json`, summaryResult.sha256);
addEvidence('QA report', `${RUN_REL}/qa-report-v3.json`, qaResult.sha256);
addEvidence('Build report', `${RUN_REL}/build-report-v3.json`, buildReportResult.sha256);
addEvidence('QA evidence manifest', `${RUN_REL}/qa-evidence-manifest-v3.json`, manifestResult.sha256);
for (const [name] of gateSpecs) addEvidence(name, `${RUN_REL}/${name}`, await hashRel(`${RUN_REL}/${name}`));
addEvidence('Factory checks', factoryPath, factoryResult.sha256);
addEvidence('独立体验审计 attempt ' + receipt.attempt, experienceAuditRel, experienceAuditResult.sha256);
for (const [role, rel, digest] of auditSourceRows) addEvidence(`独立审计源码 · ${role}`, rel, digest);
addEvidence('Dedicated CI run receipt', `${RUN_REL}/github-ci-v3.json`, ciResult.sha256);
addEvidence('Captured PR checks receipt', `${RUN_REL}/github-pr-v3.json`, prResult.sha256);
for (const binding of ciReportBindings) addEvidence(`CI report binding ${binding.engine}`, `${RUN_REL}/${binding.path}`, binding.sha256);
addEvidence('当前工作区 H5', currentHtmlRel, currentHtmlHash);
addEvidence('Open-source / reuse research', `${RUN_REL}/open-source-research-v3.json`, researchResult.sha256);
addEvidence('关卡配置源码', levelSourceRel, sourceSha);
addEvidence('冷启动 yaw reset 源码', feelSourceRel, feelSourceSha);
addEvidence('头部/喙部源几何文件', headGeometryRel, headGeometrySha);
addEvidence('H5 候选 ZIP', `${candidateRel}/${zipName}`, zipHash);
addEvidence('下载清单', `${candidateRel}/download-manifest-v3.json`, downloadResult.sha256);
addEvidence('ZIP 包清单', `${candidateRel}/package-manifest-v3.json`, packageResult.sha256);
for (const engine of ['webkit', 'chromium']) {
  const expItem = summary.reports.find((r) => r.kind === 'experience' && r.engine === engine);
  const riskItem = summary.reports.find((r) => r.kind === 'risk' && r.engine === engine);
  const feelItem = summary.reports.find((r) => r.kind === 'feel-state' && r.engine === engine);
  addEvidence(`自然体验 ${engine}`, `${RUN_REL}/${expItem.path}`, expItem.sha256);
  addEvidence(`五关风险 ${engine}`, `${RUN_REL}/${riskItem.path}`, riskItem.sha256);
  addEvidence(`姿态观测 ${engine}`, `${RUN_REL}/${feelItem.path}`, feelItem.sha256);
  addEvidence(`动作对照 ${engine}`, `${currentAttempt}/feel-comparison-${engine}/report.json`, await hashRel(`${currentAttempt}/feel-comparison-${engine}/report.json`));
}
for (const source of comparisonSourceReportEvidence) addEvidence(`对照源报告 ${source.variant} / ${source.engine}`, source.path, source.sha256);
for (const provenance of comparisonProvenanceEvidence) addEvidence('对照帧 provenance', provenance.path, provenance.sha256);
for (const frame of comparisonFrameEvidence) addEvidence(`对照源帧 PNG ${frame.variant} / ${frame.engine}`, frame.path, frame.sha256);
for (const sheet of comparisonSheetEvidence) addEvidence(`对照图 ${sheet.role} / ${sheet.engine}`, sheet.path, sheet.sha256);
for (const video of comparisonVideoEvidence) addEvidence(`动作对照视频 ${video.variant} / ${video.engine}`, video.path, video.sha256);
if (linksResult) addEvidence('evidence-links-v3.json', linksPath, linksResult.sha256);

const fullCountText = [...allowedStatuses].filter((s) => fullCounts[s] > 0).map((s) => `${s} ${fullCounts[s]}`).join(' · ') || '0 项';
const unitState = status(unitTests.status) === 'PASS' && unitTests.passed === unitTests.total ? 'PASS' : status(unitTests.status);
const firstCatchLine = ['WebKit', `首鱼 ${fmt(experienceMetrics.webkit.catchSeconds)}s`, `首金 ${fmt(experienceMetrics.webkit.goldSeconds)}s`];
const chromiumCatchLine = ['Chromium', `首鱼 ${fmt(experienceMetrics.chromium.catchSeconds)}s`, `首金 ${fmt(experienceMetrics.chromium.goldSeconds)}s`];
const gameplayRows = [
  ['1 · 跳跃与安全绕行', '跳跃对 mastery/三星有贡献，但不是一星通关或金鱼奖励的强制条件。', `实际跳障奖励金鱼对象：WebKit ${experienceMetrics.webkit.jumpGoldObject} @ ${fmt(experienceMetrics.webkit.jumpSeconds, 2)}s；Chromium ${experienceMetrics.chromium.jumpGoldObject} @ ${fmt(experienceMetrics.chromium.jumpSeconds, 2)}s。无跳安全路线仍捕到 bonus 鱼：WebKit ${experienceMetrics.webkit.safeBonusObject}，Chromium ${experienceMetrics.chromium.safeBonusObject}（轨迹阶段分别为 ${experienceMetrics.webkit.safeRoutePhase}/${experienceMetrics.chromium.safeRoutePhase}）。${experienceMetrics.webkit.safeRouteCompleted && experienceMetrics.chromium.safeRouteCompleted ? '两引擎轨迹均完成。' : '至少一条安全路线轨迹仍在进行，不能作为完成局报告。'}`],
  ['2 · 前 30–60 秒', '首个可见收获、第一次金鱼与首局半分钟内可见进展。', `${firstCatchLine.join('：')}；30s 时 ${experienceMetrics.webkit.fishAtThirty} 鱼 / ${experienceMetrics.webkit.goldAtThirty} 金 / ${experienceMetrics.webkit.jumpsAtThirty} 次跳障，首关 ${fmt(experienceMetrics.webkit.firstStageSeconds, 1)}s 完成。${chromiumCatchLine.join('：')}；30s 时 ${experienceMetrics.chromium.fishAtThirty} 鱼 / ${experienceMetrics.chromium.goldAtThirty} 金 / ${experienceMetrics.chromium.jumpsAtThirty} 次跳障，首关 ${fmt(experienceMetrics.chromium.firstStageSeconds, 1)}s 完成。游戏计时来自实际事件；自动化运行墙钟不当作手机性能数据。`],
  ['3 · 五关差异（雨 / 夜）', '目标、路程、速度、跳跃 mastery、天气与本轮结算。', '由当前 levels.mjs 配置和当前 QA summary 逐关读取，见下表。'],
  ['4 · 重玩与 mastery', '挑战目标、三星结算、个人最佳与重开是否可见。', `实际三星 ${experienceMetrics.webkit.stars}★；个人最佳 ${experienceMetrics.webkit.best.fish} 鱼 / ${experienceMetrics.webkit.best.gold} 金 / ${experienceMetrics.webkit.best.jumps} 跳。两浏览器的路线卡保存并显示纪录；风险报告各覆盖五关并观察到 replay。`],
  ['5 · 节奏与风险回报', '奖励路径选择与关卡节奏是否形成升级。', `鱼点仍按 ${fishSpacingMeters} m 间隔生成，主循环 cadence 有重复感；第 4 关切到 rain，第 5 关 dusk 并加长路程、提速、提高目标。现有证据未显示独有的夜间玩法规则，主要是天气/时间表现与风险密度变化。`],
];
need(gameplayRows.length === EXPECTED_CONCERNS.length, 'The report must cover all five required gameplay concerns');

const weatherLabel = (value) => ({ clear: '晴', rain: '雨', dusk: '黄昏/夜色' }[value] ?? value);
const fiveLevelRows = stageRows.map((row, index) => [row[0], row[1], row[2], row[3], `${weatherLabel(stages[index].weather)} · ${stages[index].jumps} 跳`, row[5]]);
const riskRows = riskEvidence.flatMap((item) => item.levels.map((level) => [
  item.engine, level.level, level.name, level.targets, `${level.fish}/${level.gold}/${level.jumps}`, `${level.stars}★`, `${fmt(level.elapsed, 1)}s`, `${fmt(level.meanFPS, 1)} fps / p95 ${fmt(level.p95FrameMs, 0)} ms`,
]));
const riskCoverageRows = riskEvidence.map((item) => [item.engine, item.targetCount, `${item.levels.length}/5`, item.settlements.filter((s) => s.status === 'PASS').length, item.replayObserved ? '是' : '否']);
const jobTableRows = ciRows.length ? ciRows : [['—', ciOverall, ciHead || prHead || '—', '没有可链接的 CI job 回执']];
const fullFailRows = allFullChecks.filter((item) => checkStatusOf(item) === 'FAIL');
const omittedContext = fixEvidence.contextIntentionallyOmitted.map((item) => `\`${md(item)}\``).join('、') || '无记录';
const ciHeadText = ciHead || prHead || '未提供';
const urlRows = publicLinks.map((item) => {
  const safe = item.url.replaceAll(')', '%29');
  return [item.label, `[打开链接（可能需登录）](${safe})`];
});
const publicLinksText = linksResult
  ? `链接是否无需登录未独立验证；GitHub 草稿、PR 和 CI 产物链接可能需要登录及仓库访问权限。\n\n${markdownTable(['项目', '链接（访问限制待验证）'], urlRows)}\n\n链接来源：\`${md(linksPath)}\`。`
  : '未找到 evidence-links-v3.json；没有公开下载链接可引用，以下本地候选包仍须人工/平台验收。';
const auditConcernSections = auditFindingRows.map((concern) => `### ${concern.index}. \`${md(concern.id)}\`

**相对基线/本轮改动：** ${concern.changes.map(md).join('；')}

**观察到：** ${concern.observed.map(md).join('；')}

**推断：** ${concern.inferred.map(md).join('；')}

**未知：** ${concern.unknowns.map(md).join('；')}

**审计结论：** ${md(concern.acceptanceStatus ?? '未提供')}`).join('\n\n');
const auditSourceText = markdownTable(['当前源文件 / 构建角色', '仓库相对路径', 'SHA-256'], auditSourceRows);
const riskStarRows = riskEvidence.map((item) => [item.engine, item.levels.map((level) => `${level.stars}★`).join(' / '), `${riskStarTotals[item.engine]}/${item.levels.length * 3}`]);
const noJumpReplayText = `无跳五关路线完成 ${noJumpReplay.completedStages} 关、${noJumpStarTotal}/${noJumpReplay.maxStars} 星并观察到免整页刷新重玩。`;
const auditNightActionRationale = '设计取舍（推断）：暂不增加第二套夜间操作系统，避免额外操作/判定成本，并把注意力留给固定鱼道选择、危险提示可读性和连续骑行；现有审计没有证据证明玩家需要夜间专属动作。暮色远处道路可读性仍需实机复核。';

const report = `# 《${GAME}》V3 QA 报告

本报告由当前 run 的 receipt、QA gates、摘要、报告、manifest、CI 回执与工厂检查生成。目标：**${GAME}**；工作区：\`${WORKSPACE}\`；attempt：**${receipt.attempt}**；修复路线：**formal-fixer**。

当前构建 SHA-256：\`${receipt.buildHash}\`。修复代码 hash：\`${fixEvidence.codeHash ?? receipt.codeHash ?? '未提供'}\`。H5 可作为开发/真机试玩候选下载；**未达到生产发布条件**。

## 当前门禁

${markdownTable(['门禁', '状态', '证据范围'], routeStatus)}

候选包是 H5 单文件开发/试玩材料。WeChat、Douyin、TapTap 原生包、TapTap 实际广告、实体手机性能与后台恢复、独立玩家乐趣/留存和生产发布仍是 **BLOCKED**。桌面模拟和工程指标不替代这些验收。

## 低成本复用范围

${reuseSummary} Three.js 授权：${md(pinnedThree.licenseSpdx ?? '研究记录未提供')}; WebLite 决策：${md(pinnedThree.targetPlatformFit?.webLite?.verdict ?? '未提供')}; 许可/归属要求：${(pinnedThree.attributionDuties ?? []).map(md).join('；') || '研究记录未提供'}。

## 五项玩法体验

${markdownTable(['关注点', '结论', '本轮证据'], gameplayRows)}

## 独立体验审计与证据边界

独立审计文件：\`${experienceAuditRel}\`；SHA-256：\`${experienceAuditResult.sha256}\`；绑定 attempt **${experienceAudit.attempt}** 与 H5 build hash \`${experienceAudit.buildHash}\`。审计按“改动、观察、推断、未知”分别记录，不把模拟结果写成人类体验结论。

${auditConcernSections}

### 五关鱼道与当下操作选择

${markdownTable(['关', '名称', '固定鱼道（0/1/2 已映射为左/中/右）', '路线决策', '观察'], fishLaneRows)}

鱼路遇到不安全车道时由安全规则覆盖。${auditNightActionRationale}

### 首分钟观测时序

${markdownTable(['游戏秒', '事件', '来源'], auditTimelineRows)}

审计记录${noJumpReplayText}跳障路线当前自然风险结算为 WebKit **${riskStarTotals.webkit}/${riskStarMaximum}**、Chromium **${riskStarTotals.chromium}/${riskStarMaximum}**。审计原始测量分别为 Chromium ${auditedJumpStarTotals.chromium}/${riskStarMaximum}、WebKit ${auditedJumpStarTotals.webkit}/${riskStarMaximum}；两引擎有一星差异，不能合并成相同结果。

前轮单独 pivot 的动作仍被车身/当前取景遮挡，现有对照没有独立验证它；本节的有限帧、桌面视频和姿态遥测不能替代这项可见性验证。

审计的完整源码/构建 SHA 清单经逐项复核。下表列出当前 H5 与相关源码的关键绑定；历史基线和截图等其余源项仍保存在 audit JSON 中。

${auditSourceText}

### 五关配置与自然结算

${markdownTable(['关', '名称', '路程 / 速度', '目标鱼 / 金鱼', '天气 / mastery 跳数', '本轮鱼 / 金 / 用时 / 结果'], fiveLevelRows)}

天气只描述当前关卡配置和渲染主题。第 5 关目前没有独有的夜间操作规则；这属于后续体验设计空间。鱼点 ${fishSpacingMeters} m 间隔由当前关卡源码读取，作为重复节奏记录，不从截图推断。

节奏取舍：本轮保留16m的基础捕鱼节拍，用不同鱼道、混合障碍段及跳/绕路线改变决策。固定节拍有利于预判，是否会疲劳仍缺真人数据；随机鱼距或动态难度并不能据此被认定更有趣，因此本轮不引入这两种系统。规律节拍的机械感作为明确局限保留，不标成已经由玩家验证解决。

## 风险奖励与重玩

${markdownTable(['浏览器', '关卡', '名称', '目标障碍数', '自然结算鱼/金/跳', '存档星级', '用时', '桌面运行采样'], riskRows)}

${markdownTable(['浏览器', '目标障碍总数', '五关覆盖', '结算/存档 PASS 关数', '最终重玩'], riskCoverageRows)}

${markdownTable(['浏览器', '跳障路线五关星级', '合计'], riskStarRows)}

跳跃奖励与安全绕行都取自正常触控事件轨迹。奖励金鱼并非跳跃专属：自然绕行轨迹在没有 jump/barrier-jumped 事件时仍捕到 \`bonus=true\` 金鱼；对照轨迹则记录跳跃、路障清除和随后获得的奖励鱼对象 ID。因而跳跃是 mastery/三星挑战的一部分，报告不把 bonus fish 描述为只能通过跳跃获得。

## 头部与动作观测

头部问题的根因记录为：原演示的初始状态没有 \`yaw\`，开始骑行前原生头部 IK 因此得到非数值变换。当前 \`feel.mjs\` 的 \`syncRidePose\` 在冷菜单初始化完整的有限姿态（yaw/lean/steer 为0），骑行时在原生 IK 更新前复制实际运行姿态。观测接口直接复制真实关节，未用有限值替换坏数据。原头颈/喙几何和 .355 颈长、28度目光保留；最初放大几何的假设已撤回。两浏览器四种尺寸的头部相关自然流程均有证据；后视角中朝前的喙在部分帧仍被身体遮住，不能据此宣称喙部独立动画已经验收。当前两引擎的 native pose 报告共检查 **${nativePoseFrameCount}** 个姿态帧；前叉4×4矩阵、车身倾斜、头身角度与请求yaw均须为有限数才生成本报告。用户图像已绑定本run，但**原图对应的源代码revision未知**，不把它精确归到某个提交。

骑行沿用原蹬踏、围巾和头部动画；变道采用保留横向速度的二阶弹簧，快速反向输入不会直接把车体位置跳到下一道。车身倾斜、航向和车头关节接入实际姿态，镜头跟随实际横移并保留滞后回正。规则测试覆盖帧率变化和反向连续性；双浏览器正常90ms触摸序列保留六组画面及前后状态、实际碰撞结算与重开。这些证据验证动作连线和可见的整体运动；独立前叉仍受后视遮挡限制，主观“更自然”的偏好仍须真人试玩。

PR #10、#13 与V3使用各自原有镜头。对照使用相同屏幕、按压时长和输入顺序；PR #10是侧视/持续按住转向，PR #13/V3是后视/单车道步进，因此不能声称三者镜头或操作语义完全相同，也不据此排名手感。输入方式原始记录：${md(comparisonInputSummary)}。\`capture t+\` 是开始后的采集墙钟，不是游戏秒；录像早于该时钟开始。按录像长度与最后RAF样本估算的时间偏移仅为近似，录制尾段误差未经量化，first-touch并非严格同步。${md(comparisonFrameRetentionNote)} 视频、已校验原始帧和关节遥测仅证明桌面采样到的运动，不证明手机FPS或真人偏好。

## 工程检查与 CI

- Pelican 单测：**${unitTests.passed}/${unitTests.total}，${unitState}**。
- Pelican lint：**${md(factoryChecks.pelican.lint.status)}**；typecheck：**${md(factoryChecks.pelican.typecheck.status)}**。状态取自最终工厂检查文件。
- 全仓检查：**${fullRepositoryStatus}**，${allFullChecks.length} 项（${fullCountText}）。失败项逐项按原始命令和摘要列出；只有证据字段明确标记 unrelated 时才归类为无关失败；本轮全仓结果不是全绿。
- 专项 CI：**${ciOverall}**。测试代码提交：\`${ciHeadText}\`；run：**${ciRunId}**（[打开 workflow run](${ciRunUrl.replaceAll(')', '%29')})）。WebKit 与 Chromium CI 记录分别绑定当前 H5 hash \`${receipt.buildHash}\`；PR 快照只用于核对同一个 40 位 source head 和这两个专项 job 的状态。
- 该绿灯只说明上面的测试代码提交；后续报告/证据文档提交没有继承这次 CI 结果，也没有在这里标成已通过。
- 后续cd808源码的取消起跳测试失败、保持断言的输入时序修正和双浏览器自然复测，见 [CI取消分支复测补充](QA_CI_FOLLOWUP_ZH.md)。最终源码的CI状态与独立回执由PR #16及其Draft附件提供，不把历史绿灯沿用到后续提交。
- ${ciRuleCountNote}
- CI通过真实菜单触摸选择既有“省电”画质，使用DPR1、Xvfb/Mesa和 \`prefers-reduced-motion:reduce\`；减少动画由既有CSS响应。它证明这一CI变体，未修改速度、碰撞、鱼或跳跃规则。默认动画、DPR3的本地双浏览器证据另行保留；历史默认软件图形路径中提示透明度为0的失败仍保留，未宣称根因已经修复。

${markdownTable(['CI job', '实际状态', 'head SHA', '精确 job 链接'], jobTableRows)}

${markdownTable(['引擎', '达成关卡', 'Campaign checks', 'Experience checks', 'Pelican 规则测试'], ciStatsRows)}

${markdownTable(['引擎', 'CI artifact', 'artifact path', 'SHA-256'], ciArtifactRows)}

CI report bindings 已逐项与本 run 的本地文件 SHA-256 核验，并与 evidence manifest 中存在的条目交叉比对；具体相对路径列在下方证据表。

${otherPrRows.length ? `### 其他 PR/CI checks（不用于 Pelican V3 专项结论）\n\n${markdownTable(['来源', 'Check / job', '状态', '链接'], otherPrRows)}\n\n其他 checks/jobs 中 FAIL：**${otherPrFailures.length}** 项；这些状态单独保留，不替代 WebKit/Chromium 专项结果。` : 'PR 快照和专项 workflow 没有其他 check/job；专项结论只由上面的两个 Pelican V3 engine jobs 得出。'}

${fullFailRows.length ? `### 全仓失败项\n\n${markdownTable(['命令', '状态', '原始摘要', '证据路径', 'SHA-256'], fullFailRows.map(fullCheckDisplayRow))}\n\n明确标记为 unrelated 的失败：**${knownUnrelatedFails.length}** 项。未带 scope/classification 的失败保留原始失败状态，不擅自归因。` : '全仓检查没有 FAIL 项。'}

## 修复路线与审计范围

- 路线：**${md(fixEvidence.route)}**。本次是正式 Fixer 流程；判断依据：\`${md(fixEvidence.hypothesis)}\`。
- attempt：**${receipt.attempt}**；原始修复 thread：\`${md(receipt.threadId)}\`；代码 hash：\`${md(fixEvidence.codeHash)}\`；build hash：\`${receipt.buildHash}\`。
- 明确省略的上下文：${omittedContext}。
- 目标 workspace：\`${WORKSPACE}\`。

## 证据与下载

ZIP SHA-256：\`${zipHash}\`。H5 build SHA-256：\`${receipt.buildHash}\`。

${markdownTable(['材料', '仓库内相对路径', 'SHA-256'], evidenceRows)}

### 外部链接与访问权限

${publicLinksText}

## 未完成的发布条件

以下项目继续保持 BLOCKED：实体 iPhone/Android 与低端机性能、真实切后台/锁屏/来电恢复、原生菜单手指拖动（finger-pan）、TapTap 广告、WeChat/Douyin/TapTap 原生包、人类玩家体验与留存、生产发布。QA summary 的 blocker：

${(summary.blockers ?? []).map((item) => `- ${md(item)}`).join('\n') || '- 最终摘要未列出 blocker；但 readiness 仍要求设备、广告、原生包和生产保持 BLOCKED。'}

## 生成器覆盖清单

${EXPECTED_CONCERNS.map((item, index) => `${index + 1}. \`${item}\``).join('\n')}
`;

const outputFull = outputOverride
  ? await assertSafeExternalOutput(resolveReportOutput(REPO, EXPECTED_REPORT, outputOverride))
  : await assertNoSymlink(EXPECTED_REPORT, 'file').catch(async (error) => {
    if (/Required file is missing:/u.test(String(error.message))) {
      // The report itself may not exist yet; only its containing directory must exist.
      const directory = path.posix.dirname(EXPECTED_REPORT);
      await assertNoSymlink(directory, 'directory');
      return path.join(REPO, EXPECTED_REPORT);
    }
    throw error;
  });
await writeFile(outputFull, report, 'utf8');
console.log(JSON.stringify({
  targetGame: GAME,
  workspace: WORKSPACE,
  attempt: receipt.attempt,
  buildHash: receipt.buildHash,
  report: outputOverride ? outputFull : EXPECTED_REPORT,
  zipSha256: zipHash,
  ciStatus: ciOverall,
  fullRepositoryCheckCounts: fullCounts,
  unitTests: { passed: unitTests.passed, total: unitTests.total, status: unitState },
  concernCount: gameplayRows.length,
}, null, 2));
