from pathlib import Path
import json,hashlib,zipfile
repo=Path('/Users/kker/.codex/worktrees/pelican-feel-v3/妖怪夜市')
run=repo/'runs/pelican-coast-v2-20261014'
delivery=Path('/Users/kker/.codex/pelican-v3-continuation/delivery')
mp=repo/'docs/lean-pilot/pelican-feel-v3-20261014/evidence-media/media-manifest.json'
pp=run/'attempts/attempt-20/comparison-frames/provenance.json'
media=json.loads(mp.read_text()); provenance=json.loads(pp.read_text())
files={mp,pp,run/'build-receipt.json',run/'attempts/attempt-20/index.html'}
def walk(v):
 if isinstance(v,dict):
  if 'path' in v and 'sha256' in v:
   p=repo/v['path']
   assert p.is_file() and not p.is_symlink(),p
   assert hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256'],p
   files.add(p)
  for child in v.values():walk(child)
 elif isinstance(v,list):
  for child in v:walk(child)
walk(media['media']);walk(provenance['records'])
files.update(p for p in mp.parent.rglob('*') if p.is_file())
items=[{'path':str(p.relative_to(repo)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(files)]
manifest={'schemaVersion':1,'targetGame':'鹈鹕海岸冒险','workspace':'runs/pelican-coast-v2-20261014/workspace','attempt':20,'buildHash':'3fd08a0a3a4b4f4a9fa644d6984a896e0114411d21952adbc5dc47999e9408c1','fullFramePngCount':len(provenance['records']),'keyMediaCount':len(media['media']),'scope':'Bound recordings, screenshots, full-frame comparison PNGs and immutable source receipts; not physical-device or human enjoyment acceptance.','comparisonLimits':'capture t+ is post-start capture wallclock; source video PTS offset is approximate and tail is unquantified; PR10 continuous steering and PR13/V3 lane inputs/cameras differ; no strict speed/preference ranking. Native isolated front-fork pivot remains visually occluded in some rear views.','files':items}
out=delivery/'pelican-v3-key-recordings-and-comparisons.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=1,allowZip64=True) as z:
 for p in sorted(files):z.write(p,str(p.relative_to(repo)))
 z.writestr('KEY_EVIDENCE_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
 z.writestr('README_中文版.txt','鹈鹕海岸冒险 V3 第20轮关键录像与对比截图\n保留原仓库相对路径，按 KEY_EVIDENCE_MANIFEST.json 校验。\n包含32项关键媒体、120张实际全帧PNG及原始报告/录像来源；部分文件为同内容的不同交付路径。\ncapture t+ 是采集墙钟，不是游戏时间。视频与截图偏移近似，不能作严格速度/偏好排名；PR10连续转向与PR13/V3分道输入、原生镜头不同。\n实体手机、真人趣味性、真实广告未测。车头独立前叉部分后视角被遮挡，不能宣称单独视觉验收通过。\n')
raw=out.read_bytes()
outer={**manifest,'archive':{'name':out.name,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}}
(delivery/'key-evidence-bundle-manifest.json').write_text(json.dumps(outer,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'archive':outer['archive'],'files':len(items),'frames':len(provenance['records']),'media':len(media['media'])}))
