import hashlib
import io
import json
import os
from pathlib import Path
import re
import tarfile

REPO = Path('/Users/kker/.codex/worktrees/pelican-feel-v3/妖怪夜市')
RUN = REPO / 'runs/pelican-coast-v2-20261014'
OUT = Path('/Users/kker/.codex/pelican-v3-continuation/delivery')
LIMIT = 500 * 1024 * 1024

class Parts(io.RawIOBase):
    def __init__(self, label):
        self.label = label
        self.files = []
        self.whole = hashlib.sha256()
        self.part = None
        self.size = 0
        self.total = 0
        self.digest = None
    def writable(self): return True
    def open_part(self):
        p = OUT / (self.label + '.tar.part%03d' % len(self.files))
        if p.exists(): raise RuntimeError('Preserve existing archive: ' + str(p))
        self.part = p.open('wb')
        self.current = p
        self.size = 0
        self.digest = hashlib.sha256()
    def end_part(self):
        if self.part is None: return
        self.part.close()
        self.files.append({'name': self.current.name, 'sizeBytes': self.size, 'sha256': self.digest.hexdigest()})
        print(json.dumps({'part':self.current.name,'sizeBytes':self.size}), flush=True)
        self.part = None
    def write(self, b):
        view = memoryview(b)
        self.whole.update(view)
        self.total += len(view)
        original = len(view)
        while view:
            if self.part is None: self.open_part()
            take = min(len(view), LIMIT - self.size)
            chunk = view[:take]
            self.part.write(chunk)
            self.digest.update(chunk)
            self.size += take
            view = view[take:]
            if self.size == LIMIT: self.end_part()
        return original
    def flush(self):
        if self.part is not None: self.part.flush()

class HashedReader:
    def __init__(self, f): self.f=f; self.digest=hashlib.sha256()
    def read(self, n=-1):
        b=self.f.read(n); self.digest.update(b); return b

def archive(label, roots, classification):
    manifest_path = OUT / (label + '-manifest.json')
    if manifest_path.exists(): raise RuntimeError('Preserve existing manifest')
    files = []
    for root in roots:
        if root.is_symlink(): raise RuntimeError('Symlink root forbidden')
        if root.is_file(): files.append(root)
        elif root.is_dir():
            for base, dirs, names in os.walk(root, followlinks=False):
                dirs[:] = [name for name in dirs if name not in ['node_modules', '.git', '__pycache__']]
                for name in dirs:
                    if (Path(base)/name).is_symlink(): raise RuntimeError('Symlink directory forbidden')
                for name in names:
                    p=Path(base)/name
                    if p.is_symlink() or not p.is_file(): raise RuntimeError('Nonregular evidence forbidden')
                    if name == '.DS_Store': continue
                    files.append(p)
    files = sorted(set(files))
    dest = Parts(label)
    bindings = []
    first_content_path = {}
    with tarfile.open(fileobj=dest, mode='w|', format=tarfile.PAX_FORMAT) as archive_file:
        for p in files:
            p.relative_to(RUN)
            before=p.stat()
            info=tarfile.TarInfo(p.relative_to(REPO).as_posix())
            info.size=before.st_size; info.mtime=int(before.st_mtime); info.mode=0o644
            with p.open('rb') as f:
                digest=hashlib.file_digest(f, 'sha256').hexdigest()
            content_key=(info.size,digest)
            previous=first_content_path.get(content_key)
            if previous is not None:
                info.type=tarfile.LNKTYPE
                info.linkname=previous
                info.size=0
                archive_file.addfile(info)
            else:
                with p.open('rb') as f:
                    stream=HashedReader(f)
                    archive_file.addfile(info, stream)
                    if stream.digest.hexdigest()!=digest: raise RuntimeError('Evidence changed while archiving: '+str(p))
                first_content_path[content_key]=info.name
            after=p.stat()
            if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):
                raise RuntimeError('Evidence mutated while archiving: '+str(p))
            bindings.append({'path':info.name,'sizeBytes':before.st_size,'sha256':digest,'sameContentAs':previous})
        index={'schemaVersion':1,'targetGame':'鹈鹕海岸冒险','targetRunId':'pelican-coast-v2-20261014','workspace':str(RUN/'workspace'),'classification':classification,'excludedReproducibleOrHostDirectories':['node_modules','.git','__pycache__'],'deduplication':'byte-identical file contents stored once with standard TAR hard links; original paths and SHA-256 retained','files':bindings}
        data=(json.dumps(index,ensure_ascii=False,indent=2)+'\n').encode()
        info=tarfile.TarInfo('runs/pelican-coast-v2-20261014/archive-index-'+label+'.json')
        info.size=len(data); info.mode=0o644
        archive_file.addfile(info,io.BytesIO(data))
    dest.end_part()
    manifest={**index,'archive':{'format':'tar; concatenated parts in ascending numeric order','sizeBytes':dest.total,'sha256':dest.whole.hexdigest(),'parts':dest.files}}
    manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':'complete','manifest':str(manifest_path),'files':len(bindings),'parts':len(dest.files),'sha256':dest.whole.hexdigest()}),flush=True)

if __name__=='__main__':
    import sys
    mode=sys.argv[1]
    if mode=='history':
        roots=[p for p in (RUN/'attempts').iterdir() if re.fullmatch(r'attempt-(\d+)',p.name) and int(p.name.split('-')[1])<20]
        archive('pelican-v3-historical-attempts-01-19',roots,'HISTORICAL_AND_SUPERSEDED; includes failed repairs; never current20 acceptance evidence')
    elif mode=='final':
        roots=[p for p in RUN.iterdir() if p.name not in ['attempts']]
        roots.append(RUN/'attempts'/'attempt-20')
        archive('pelican-v3-current20-and-all-qa-evidence',roots,'CURRENT20_RAW_AND_DIAGNOSTIC_HISTORY; each report retains its original build and status; blockers preserved')
    else: raise RuntimeError('Unknown archive scope')
