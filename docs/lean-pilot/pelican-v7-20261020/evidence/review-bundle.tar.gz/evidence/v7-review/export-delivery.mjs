// Curated run-bound evidence, not a RELEASE-stage approval.
import {readFile,writeFile,mkdir,readdir,cp,mkdtemp} from 'node:fs/promises';
import {createHash} from 'node:crypto';import {execFileSync} from 'node:child_process';import path from 'node:path';
const root=process.cwd(),run=path.join(root,'runs/pelican-coast-v2-20261014');
const dest=path.join(root,'docs/lean-pilot/pelican-v7-20261020');
const sha=b=>createHash('sha256').update(b).digest('hex'),selected=new Set();
async function walk(p,select){for(const f of await readdir(path.join(run,p),{withFileTypes:true})){const q=path.posix.join(p,f.name);if(f.isDirectory())await walk(q,select);else if(select(q))selected.add(q);}}
await walk('evidence/v7-review',p=>/\.(json|log|tsv|mjs|txt)$/.test(p)&&!p.includes('/attempt-5-retained/'));
await walk('attempts',p=>p.endsWith('.json')||p.endsWith('/driver-source.mjs'));
for(const p of ['build-receipt.json','repair-state.json','baseline-receipt.json'])selected.add(p);
const cases=JSON.parse(await readFile(path.join(run,'evidence/v7-review/review-case-bindings-final.json')));
await walk('evidence/v7-review/video-frames',p=>p.endsWith('.png'));
await walk('evidence/v7-review/wardrobe-close-supplement',p=>p.endsWith('.png'));
for(const row of cases)for(const b of row.screenshots)selected.add(b.path);
for(const p of ['attempts/attempt-1/v7-journey-chromium-before/startup.png','attempts/attempt-1/v7-journey-chromium-before/round-5-skilled-settlement.png','attempts/attempt-2/v7-journey-chromium-after-quick/round-1-skilled-real-glide.png','attempts/attempt-5/v6-real-browser-chromium/v6-menu.png'])selected.add(p);
// Exact triage references and natural screenshot bindings must remain available.
for(const f of await readdir(path.join(run,'evidence/v7-review'))){if(!f.endsWith('triage.json'))continue;const t=JSON.parse(await readFile(path.join(run,'evidence/v7-review',f)));for(const b of t.reproduction.evidence)if(!b.path.startsWith('/')&& !b.path.startsWith('tools/'))selected.add(b.path);}
for(const p of ['game/index.html','game/LICENSE.three.txt','game/platform.json',...['main.js','coast-ui.mjs','adventure.mjs','levels.mjs','endless.mjs'].map(f=>'source/pelican-bike/src/'+f)])selected.add('workspace/'+p);
const staging=await mkdtemp('/tmp/pelican-v7-evidence-'),bindings=[];
for(const p of [...selected].sort()){const bytes=await readFile(path.join(run,p));await mkdir(path.dirname(path.join(staging,p)),{recursive:true});await writeFile(path.join(staging,p),bytes);bindings.push({path:p,sha256:sha(bytes),bytes:bytes.length});}
await mkdir(path.join(dest,'evidence'),{recursive:true});await mkdir(path.join(dest,'playtest'),{recursive:true});
for(const f of ['index.html','LICENSE.three.txt','platform.json'])await cp(path.join(run,'workspace/game',f),path.join(dest,'playtest',f));
const videos=[];
for(const [name,p] of [
 ['before-seven-rounds.webm','attempts/attempt-1/v7-journey-chromium-before/page@06d16bb521be176cf6896de04cdd5043.webm'],
 ['after-eight-rounds.webm','attempts/attempt-6/v7-journey-chromium-dispatch-retest/page@1ac1041cd9c72e33b83bb156fb43ac1c.webm'],
 ['after-eight-rounds-webkit.webm','attempts/attempt-6/v7-journey-webkit-after/page@ad9c181bc2536e4a51d5c9aa59db25b4.webm'],
 ['night-chromium.webm','attempts/attempt-6/risk-chromium/level-5.webm'],
 ['night-webkit.webm','attempts/attempt-6/risk-webkit/level-5.webm']
]){const b=await readFile(path.join(run,p));await writeFile(path.join(dest,'evidence',name),b);videos.push({path:name,source:p,sha256:sha(b),bytes:b.length,processing:'Unmodified original capture'});}
const manifest={targetGame:'鹈鹕海岸冒险 V7',targetRunId:'pelican-coast-v2-20261014',workspace:path.join(run,'workspace'),buildHash:JSON.parse(await readFile(path.join(run,'build-receipt.json'))).buildHash,releaseApproved:false,files:bindings,videos,scope:'Selected review screenshots, all attempt JSON/driver sources, current run-bound contracts and logs. Other raw captures remain in the local run; nothing omitted is claimed passed.'};
await writeFile(path.join(staging,'delivery-manifest.json'),JSON.stringify(manifest,null,2));
execFileSync('tar',['-czf',path.join(dest,'evidence/review-bundle.tar.gz'),'-C',staging,'.']);
await writeFile(path.join(dest,'evidence/index.json'),JSON.stringify({...manifest,archive:{path:'review-bundle.tar.gz',sha256:sha(await readFile(path.join(dest,'evidence/review-bundle.tar.gz')))}},null,2));
console.log(JSON.stringify({dest,files:bindings.length,videos:videos.length,buildHash:manifest.buildHash}));
