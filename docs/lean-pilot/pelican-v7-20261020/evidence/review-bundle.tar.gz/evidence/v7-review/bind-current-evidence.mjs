// Project-local projection of actual captures into EXISTING factory contracts.
// Does not drive browsers, edit gameplay, or approve perceptual quality.
import {readFile,writeFile,mkdir,stat} from 'node:fs/promises';
import path from 'node:path';import {createHash} from 'node:crypto';
import {tsImport} from 'tsx/esm/api';import {z} from 'zod';
const root=process.cwd(),run=path.join(root,'runs/pelican-coast-v2-20261014'),workspace=path.join(run,'workspace');
const out='evidence/v7-review',read=async p=>JSON.parse(await readFile(path.join(run,p)));
const sha=b=>createHash('sha256').update(b).digest('hex');
const bind=async p=>({path:p,sha256:sha(await readFile(path.join(run,p)))});
const write=async(p,v)=>writeFile(path.join(run,p),JSON.stringify(v,null,2)+'\n');
const build=await read('build-receipt.json'),base=`attempts/attempt-${build.attempt}`;
const {ProductExperienceContractSchema:C}=await tsImport(root+'/src/schemas/product-experience.ts',import.meta.url);
const {NaturalFlowEvidenceSchema:N}=await tsImport(root+'/src/schemas/natural-flow.ts',import.meta.url);
const {deriveRuntimeProductGate,verifyRuntimeWiredFiles}=await tsImport(root+'/src/core/runtime-product-gates.ts',import.meta.url);
const entrypoints=['game/index.html',...['main.js','coast-ui.mjs','adventure.mjs','levels.mjs','endless.mjs'].map(f=>'source/pelican-bike/src/'+f)];
const captures={chromium:'dispatch-retest',webkit:'after'};
const engines=['chromium','webkit'],viewport=(engine,w=390,h=844)=>({width:w,height:h,label:engine+'-'+w+'x'+h});
const feature=(id,objectType,stateBranch,playerAction,visibleSignal,expectedEventOrder,viewports)=>({id,sourceCheckIds:[id],objectType,stateBranch,playerAction,visibleSignal,naturalTrigger:'Fresh browser or legitimately earned campaign progression, normal trusted touch only',expectedEventOrder,requiredViewports:viewports,negativeAssertions:['No injected success, unlock, position, collision or reward','No hidden/occluded action-critical control; exact object and state must be visible'],sourceEvidence:[out+'/request.txt',out+'/triage.json'],blockingIf:['Exact branch is absent, unreadable or only a fixture','Natural input or visible feedback cannot be verified']});
const portrait=engines.map(e=>viewport(e));
const contract=C.parse({schemaVersion:2,artifactType:'product-experience-contract',targetGame:'鹈鹕海岸冒险 V7',targetRunId:'pelican-coast-v2-20261014',targetWorkspace:workspace,runtime:'web-lite',runtimeEntrypoints:entrypoints,sourceArtifact:{kind:'experience-contract',...await bind(out+'/request.txt')},features:[
 feature('v7-held-wing','pelican and elevated fish','L1 110m hold -> glide -> real air catch','Hold existing jump button, release, freely steer','Native airborne rider, green button, bounded wing meter, cyan elevated fish and compact catch signal',['start','glide-start','air-fish-caught','complete','replay'],portrait),
 feature('v7-mobile-journey','menu, controls and settlement','fresh default -> first real failure -> free replay','Start, observe actual first fish and barrier impact, tap replay','Primary start before optional wardrobe; reachable gameplay keys; causal death and free replay',['start','fish-caught','failed','replay'],engines.flatMap(e=>[viewport(e),viewport(e,320,568),viewport(e,844,390)])),
 feature('v7-wardrobe','optional cosmetics','closed -> expanded -> owned style -> closed','Expand disclosure and genuinely tap owned style','Real visible wallet and usable existing item row, not summary-only clipping',['open','owned-style-tap','close'],engines.flatMap(e=>[viewport(e,320,568),viewport(e,844,390)])),
 feature('v7-crossing-reward','L2 ordinary fish l2-f4','79m safe preparation line before112m barrier','Follow visible safe left fish and continue actual two-jump route','Fish on reachable left line; actual pickup and unchanged17-fish three stars',['start','early-left','fish-caught','complete'],portrait),
 feature('v7-rain-reward','L4 existing fish and jump prizes','335/367/607m preparation, landing, exit','Three actual jumps and real fishing, not a lowered threshold','Visible clean jump rewards and28-fish three-star settlement',['start','jump','gold-caught','complete'],portrait),
 feature('v7-night-forecast','oncoming cars and van','L5 opening38–43m escape branch','Read future arrival, steer before real vehicle','Amber upcoming versus red imminent traffic remains visible; no collision forgiveness',['start','forecast','trusted-escape','vehicle-avoided','complete'],portrait),
 feature('v7-endless-phrases','seeded endless hazards','first550m and first distance tier','Steer around actual encounter sequences, then voluntarily settle and replay','Varied car/barrier patterns, real record/tier, genuine earned settlement and replay',['start','steer','tier','retired','replay'],portrait),
]});
await write(out+'/product-experience-contract.json',contract);
await mkdir(path.join(run,out,'natural'),{recursive:true});
const traces=[],reports=[],matrix=[];
for(const engine of engines){
 const jp=`${base}/v7-journey-${engine}-${captures[engine]}/report.json`,rp=`${base}/risk-${engine}/report.json`;
 const j=await read(jp),r=await read(rp);reports.push(jp,rp);
 if(j.buildHash!==build.buildHash||r.buildHash!==build.buildHash)throw Error('Capture/build mismatch');
 // No projection can silently turn a failed source report into a passed trace.
 if(!j.passed||!r.passed)throw Error('Natural source report still blocked: '+engine);
 for(const f of contract.features){for(const v of f.requiredViewports.filter(v=>v.label.startsWith(engine))){
  const risk=f.id.includes('reward')||f.id==='v7-night-forecast',raw=risk?rp:jp,source=risk?r:j;
  let shots,actions;
  if(f.id==='v7-held-wing')shots=[`round-5-skilled-real-glide`,`round-5-skilled-settlement`];
  else if(f.id==='v7-mobile-journey')shots=v.width===390?['startup','round-1-no-input-settlement','round-5-skilled-real-glide']:[`menu-${v.width}`,`running-${v.width}`,`terminal-${v.width}`,`replay-${v.width}`];
  else if(f.id==='v7-wardrobe')shots=[`menu-${v.width}`,`wardrobe-${v.width}`];
  else if(f.id==='v7-crossing-reward')shots=['level-2-opening-forecast-escape','level-2-terminal-settlement'];
  else if(f.id==='v7-rain-reward')shots=['level-4-l4-o5-golden-bonus-fish-caught','level-4-l4-o10-golden-bonus-fish-caught','level-4-terminal-settlement'];
  else if(f.id==='v7-night-forecast')shots=['level-5-opening-forecast-escape','level-5-terminal-settlement'];
  else shots=['endless-varied-encounters','round-8-endless-settlement','endless-free-replay'];
  const folder=path.posix.dirname(raw);shots=shots.map(s=>folder+'/'+s+'.png');
  if(f.id==='v7-night-forecast')shots.splice(1,0,out+'/video-frames/'+(engine==='chromium'?'night-chromium-4p5.png':'night-webkit-5p8.png'));
  if(risk)actions=r.actions.map(a=>'trusted touch '+a.selector);
  else if(v.width!==390)actions=['native disclosure open','owned-style tap','disclosure close','tap start','real first fish and barrier failure','tap replay'];
  else actions=j.rounds.flatMap(round=>['tap start/replay',...round.actions.map(a=>'trusted '+a.action+' at HUD '+a.distance+'m')]);
  const observedAt=(await stat(path.join(run,raw))).mtime.toISOString();
  const trace=N.parse({schemaVersion:1,startedFromReset:true,actions,transitions:[{name:f.id,changed:true,evidence:raw}],completion:'settlement',replayObserved:true,forbiddenOperations:[],screenshots:shots,passed:true,blockers:[],runner:'Actual Playwright native touch capture; projection does not approve pixels',buildHash:build.buildHash,runtime:'web-lite',device:v,seed:'Authored campaign / runtime daily endless seed; no override',observedAt});
  const tp=`${out}/natural/${f.id}-${v.label}.json`;await write(tp,trace);const b=await bind(tp);
  const screenshotBindings=await Promise.all(shots.map(bind));
  traces.push({name:f.id+'-'+v.label,...b,raw,features:[f.id],viewport:v});
  matrix.push({featureId:f.id,viewport:v,trace:b,screenshots:screenshotBindings,raw,expectedEventOrder:f.expectedEventOrder,sourcePassed:source.passed});
 }}
}
reports.push(`${base}/v7-journey-chromium-after/report.json`,`${base}/v7-journey-chromium-serial-retest/report.json`,out+'/video-frames/manifest.json');
await write(out+'/review-case-bindings.json',matrix);
const contractHash=sha(JSON.stringify(contract));
// Same work-order shape as existing pelican-v2/bind-qa.mjs, not a new factory schema.
const Text=z.string().min(1),Binding=z.object({path:Text,sha256:z.string().regex(/^[a-f0-9]{64}$/u)}).strict();
const Order=z.object({schemaVersion:z.literal(1),role:z.literal('QAAgent'),targetGame:Text,workspace:Text,runRoot:Text,buildHash:Text,contract:Text,contractHash:Text,scope:z.array(Text),traces:z.array(z.object({name:Text,path:Text,sha256:Text,raw:Text,features:z.array(Text),viewport:z.object({width:z.number(),height:z.number(),label:Text}).strict()}).strict()),rawReports:z.array(Text),output:Text,acceptance:z.array(Text),forbidden:z.array(Text),sourceBindings:z.array(Binding)}).strict();
const order=Order.parse({schemaVersion:1,role:'QAAgent',targetGame:contract.targetGame,workspace,runRoot:run,buildHash:build.buildHash,contract:out+'/product-experience-contract.json',contractHash,scope:['Independent read-only pixel review of the exact current-build cases; existing QA role, no new gate or game edits','Read '+out+'/review-case-bindings.json for selected pixels, raw source and traces','Inspect actual screenshots with view_image; do not infer quality from passed flags','Review capture driver sources in report folders for normal-input provenance; raw snapshots only observe state','Review the preserved same-build Chromium after report too: round5 failed with ZERO gameplay inputs and multi-second driver observation gaps; serial-retest then failed because the last blind jump touched the already finished overlay and was falsely logged as gameplay; dispatch-retest separately records actual control deliveries and late terminal requests. Both failures preserved. Do not hide them or count unexercised strategies as valid skill outcomes','Use compact field queries, not whole-report dumps; read only this run and relevant Pelican driver source','Desktop native browsers only. Physical phones, humans, ads and unobserved later air routes are NOT_RUN'],traces,rawReports:reports,output:out+'/perceptual-qa-report.json',acceptance:['Return ONLY one PerceptualQaReportSchema-valid JSON object; no free-chat/progress prose and no file writes','Use existing src/schemas/product-experience.ts. Reviewer QAAgent; authorIndependent true because this reviewer did not implement source','Preserve exact feature, state, viewport, event order and sourceCheckIds. Actually inspect pixels and raw traces before marking a row passed','Missing, obstructed or contradictory exact-branch evidence must remain BLOCKED, not substituted by a sibling','Main thread will validate JSON and verifyPerceptualQaReview. Honest blockers are a valid result'],forbidden:['Do not write files, launch browsers, alter source/contracts/captures or spawn other agents','You are not alone in this worktree. Preserve all other work','Do not claim human enjoyment, real-device performance, platform publishability or advertising revenue'],sourceBindings:await Promise.all([...reports,out+'/review-case-bindings.json'].map(bind))});
await write(out+'/qa-review-workorder.json',order);
const wiring=await verifyRuntimeWiredFiles({runRoot:run,files:entrypoints.map(p=>'workspace/'+p)});
await write(out+'/runtime-wiring.json',wiring);
if(!wiring.passed)throw Error('Runtime wiring incomplete');
const natural=await read(traces.find(t=>t.name==='v7-held-wing-chromium-390x844').path);
const gate=deriveRuntimeProductGate({naturalFlow:natural,runtimeWiredFiles:wiring.checked,browserEvidence:reports,entrypoint:'workspace/game/index.html',defaultMode:'authored free-steering coast campaign',legacyBehavior:{status:'REMOVED_FROM_DEFAULT_PATH',evidence:['build.mjs patches immutable native main to createCoastAdventure and removes original debug API. Actual default-start traces enter campaign, not native demo/orbit.','Existing old save normalization is compatibility only; not a parallel gameplay default.']}});
await write(out+'/runtime-product-gate.json',gate);
console.log(JSON.stringify({workorder:path.join(run,out,'qa-review-workorder.json'),buildHash:build.buildHash,cases:matrix.length,wiring:wiring.passed,runtimeJourney:gate.passed}));
const dispatch=Order.parse({...order,traces:[],rawReports:[],scope:['Read-only QAAgent assignment. Repository root: '+root,'Load and follow the complete Zod-validated work order at '+path.join(run,out,'qa-review-workorder.json'),'The bound work order owns20 exact current-build pixel/normal-input cases; no source edits or scope expansion. Main thread owns acceptance. Return the final report JSON only.'],sourceBindings:[await bind(out+'/qa-review-workorder.json')]});
await write(out+'/qa-dispatch.json',dispatch);console.log(JSON.stringify(dispatch));
