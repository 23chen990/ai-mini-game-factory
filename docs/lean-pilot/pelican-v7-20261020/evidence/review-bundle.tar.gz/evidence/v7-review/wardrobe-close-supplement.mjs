import assert from 'node:assert/strict';
import {chromium,webkit} from '@playwright/test';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
const root=process.cwd(),run=path.join(root,'runs/pelican-coast-v2-20261014');
const {browserOptions}=await import(root+'/tools/lean-pilot/pelican-v2/browser-options.mjs');
const {serve}=await import(root+'/tools/lean-pilot/pelican-v2/serve.mjs');
const build=JSON.parse(await readFile(run+'/build-receipt.json'));
const dir=run+'/evidence/v7-review/wardrobe-close-supplement';await mkdir(dir,{recursive:true});
const hash=b=>createHash('sha256').update(b).digest('hex');
await writeFile(dir+'/driver-source.mjs',await readFile(new URL(import.meta.url)));
const report={targetGame:'鹈鹕海岸冒险 V7',workspace:run+'/workspace',buildHash:build.buildHash,normalInputOnly:true,stateInjection:false,cases:[],passed:false};
const server=await serve();
try{
 for(const engine of ['chromium','webkit']){
  const browser=await({chromium,webkit}[engine]).launch(browserOptions(engine));
  try{
   for(const viewport of [{width:320,height:568},{width:844,height:390}]){
    const context=await browser.newContext({viewport,hasTouch:true,isMobile:true,deviceScaleFactor:1});
    const page=await context.newPage();
    await page.addInitScript(()=>{
     window.__wardrobeInputs=[];
     document.addEventListener('pointerdown',e=>window.__wardrobeInputs.push({trusted:e.isTrusted,pointerType:e.pointerType,target:e.target.closest('[data-style]')?.getAttribute('data-style')??e.target.closest('summary')?.parentElement.id??e.target.id,at:performance.now()}),true);
    });
    await page.goto(`http://127.0.0.1:${server.address().port}/game/index.html`);
    await page.waitForSelector('#coast[data-loaded="true"]');
    const steps=[],screenshots=[];
    const capture=async name=>{
     const state=await page.evaluate(()=>({open:document.querySelector('#co-wardrobe').open,equipped:document.querySelector('[data-style="classic"] small').textContent,phase:document.querySelector('#coast').dataset.phase,at:performance.now()}));
     const file=path.join(dir,`${engine}-${viewport.width}-${name}.png`);await page.screenshot({path:file});
     steps.push({name,...state});screenshots.push({path:path.relative(run,file),sha256:hash(await readFile(file))});return state;
    };
    assert.equal((await capture('initial-closed')).open,false);
    await page.locator('#co-wardrobe summary').tap();assert.equal((await capture('open')).open,true);
    await page.locator('[data-style="classic"]').tap();assert.equal((await capture('owned-style')).equipped,'已穿戴');
    await page.locator('#co-wardrobe summary').tap();assert.equal((await capture('closed')).open,false);
    const inputs=await page.evaluate(()=>window.__wardrobeInputs);
    assert.equal(inputs.length,3);assert.ok(inputs.every(e=>e.trusted&&e.pointerType==='touch'));
    assert.deepEqual(inputs.map(e=>e.target),['co-wardrobe','classic','co-wardrobe']);
    report.cases.push({engine,viewport,steps,inputs,screenshots,passed:true});await context.close();
   }
  }finally{await browser.close();}
 }
 report.passed=report.cases.length===4&&report.cases.every(c=>c.passed);
}finally{
 await new Promise(resolve=>server.close(resolve));await writeFile(dir+'/report.json',JSON.stringify(report,null,2)+'\n');
}
console.log(JSON.stringify({passed:report.passed,cases:report.cases.length}));
